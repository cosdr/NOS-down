#include "fte.h"
#include "vga.h"
#include "keyboard.h"
#include "fat12.h"
#include "ramdisk.h"
#include "utils.h"

#define FTE_MAX_LINES 400
#define FTE_MAX_LINE  78

static char buf_lines[FTE_MAX_LINES][FTE_MAX_LINE + 1];
static int  line_count = 1;
static int  cx = 0, cy = 0;
static int  scroll = 0;
static int  dirty = 0;
static char cur_name[64];

static int load_file(const char* name) {
    static char tmp[8192];
    int n = -1;
    if (fat12_is_mounted()) n = fat12_read_file(name, tmp, sizeof(tmp) - 1);
    if (n < 0) {
        int fd = ramdisk_get_fd(name);
        if (fd >= 0) n = ramdisk_read(fd, tmp, sizeof(tmp) - 1);
    }
    if (n < 0) return -1;
    tmp[n] = 0;

    line_count = 1;
    for (int i = 0; i < FTE_MAX_LINES; i++) buf_lines[i][0] = 0;
    int pos = 0, lc = 0, lp = 0;
    while (tmp[pos] && lc < FTE_MAX_LINES) {
        if (tmp[pos] == '\n') { buf_lines[lc][lp] = 0; lc++; lp = 0; }
        else if (lp < FTE_MAX_LINE) buf_lines[lc][lp++] = tmp[pos];
        pos++;
    }
    if (lp > 0) buf_lines[lc][lp] = 0;
    line_count = lc + 1;
    if (line_count < 1) line_count = 1;
    return 0;
}

static void save_file(const char* name) {
    char save_buf[8192]; int pos = 0;
    for (int i = 0; i < line_count; i++) {
        int j = 0;
        while (buf_lines[i][j] && pos < 8191) save_buf[pos++] = buf_lines[i][j++];
        if (pos < 8191) save_buf[pos++] = '\n';
    }
    save_buf[pos] = 0;
    if (fat12_is_mounted()) fat12_write_file(name, save_buf, pos);
    int fd = ramdisk_create(name);
    if (fd >= 0) ramdisk_write(fd, save_buf, pos);
    dirty = 0;
}

static void draw_all(void) {
    uint8_t bg = vga_make_color(VGA_LIGHT_GREY, VGA_BLACK);
    uint8_t border = vga_make_color(VGA_LIGHT_CYAN, VGA_BLACK);
    uint8_t title_fg = vga_make_color(VGA_BLACK, VGA_LIGHT_CYAN);
    uint8_t status_fg = vga_make_color(VGA_BLACK, VGA_LIGHT_GREY);

    vga_clear(bg);
    for (int x = 0; x < 80; x++) vga_putcell(x, 0, ' ', title_fg, VGA_LIGHT_CYAN);
    vga_print("FTE v1.0", title_fg, 2, 0);
    vga_print(cur_name, title_fg, 10, 0);
    if (dirty) vga_print("[modified]", title_fg, 60, 0);

    for (int i = 0; i < 22; i++) {
        int li = scroll + i;
        if (li >= line_count) break;
        char num[6]; itoa(li + 1, num, 10);
        vga_print(num, vga_make_color(VGA_DARK_GREY, VGA_BLACK), 0, 1 + i);
        vga_putcell(4, 1 + i, '|', border, VGA_BLACK);
        vga_print(buf_lines[li], bg, 6, 1 + i);
    }

    for (int x = 0; x < 80; x++) vga_putcell(x, 24, ' ', status_fg, VGA_LIGHT_GREY);
    char sb[64]; int p = 0;
    const char* l1 = " F1 Save  F2 SaveAs  F3 Open  ESC Quit  ";
    while (*l1) sb[p++] = *l1++;
    vga_print(sb, status_fg, 0, 24);

    char pos[32];
    char row[8], col[8];
    itoa(cy + 1, row, 10); itoa(cx + 1, col, 10);
    int pp = 0;
    pos[pp++] = 'L'; pos[pp++] = ':';
    for (int i = 0; row[i]; i++) pos[pp++] = row[i];
    pos[pp++] = ' '; pos[pp++] = 'C'; pos[pp++] = ':';
    for (int i = 0; col[i]; i++) pos[pp++] = col[i];
    pos[pp] = 0;
    vga_print(pos, status_fg, 64, 24);

    int screen_y = 1 + (cy - scroll);
    if (screen_y >= 1 && screen_y < 23) vga_set_cursor(6 + cx, screen_y);
}

static int prompt(const char* label, char* out, int max) {
    uint8_t fg = vga_make_color(VGA_BLACK, VGA_LIGHT_CYAN);
    for (int x = 0; x < 80; x++) vga_putcell(x, 23, ' ', fg, VGA_LIGHT_CYAN);
    vga_print(label, fg, 1, 23);
    int p = 0;
    for (;;) {
        int k = keyboard_getchar();
        if (k == '\n') { out[p] = 0; return p; }
        if (k == -KEY_ESC) { out[0] = 0; return -1; }
        if (k == '\b' && p > 0) {
            p--;
            vga_putchar_at('\b', fg);
            vga_putchar_at(' ', fg);
            vga_putchar_at('\b', fg);
        } else if (k > 0 && k < 128 && p < max - 1) {
            out[p++] = (char)k;
            vga_putchar_at((char)k, fg);
        }
    }
}

void fte_run(const char* filename) {
    for (int i = 0; i < FTE_MAX_LINES; i++) buf_lines[i][0] = 0;
    strncpy(cur_name, filename, sizeof(cur_name) - 1);
    cur_name[sizeof(cur_name) - 1] = 0;

    if (load_file(cur_name) < 0) {
        line_count = 1;
        dirty = 0;
    }
    cx = 0; cy = 0; scroll = 0;

    int running = 1;
    while (running) {
        draw_all();
        int key = keyboard_getchar();

        if (key == -KEY_ESC) {
            if (dirty) {
                char ans[8];
                if (prompt("Save before quit? (y/n): ", ans, 4) >= 0 &&
                    (ans[0] == 'y' || ans[0] == 'Y')) {
                    save_file(cur_name);
                }
            }
            running = 0;
        }
        else if (key == -KEY_F1) {
            save_file(cur_name);
        }
        else if (key == -KEY_F2) {
            char nn[64];
            if (prompt("Save as: ", nn, sizeof(nn)) > 0) {
                strncpy(cur_name, nn, sizeof(cur_name) - 1);
                save_file(cur_name);
            }
        }
        else if (key == -KEY_F3) {
            char nn[64];
            if (prompt("Open: ", nn, sizeof(nn)) > 0) {
                if (dirty) {
                    char ans[4];
                    if (prompt("Discard unsaved? (y/n): ", ans, 4) < 0 || (ans[0] != 'y' && ans[0] != 'Y')) {
                        continue;
                    }
                }
                if (load_file(nn) == 0) {
                    strncpy(cur_name, nn, sizeof(cur_name) - 1);
                    cx = 0; cy = 0; scroll = 0;
                }
            }
        }
        else if (key == -KEY_UP && cy > 0) {
            cy--;
            if (cx > (int)strlen(buf_lines[cy])) cx = (int)strlen(buf_lines[cy]);
        }
        else if (key == -KEY_DOWN) {
            if (cy < line_count - 1) cy++;
            else if (line_count < FTE_MAX_LINES) { line_count++; buf_lines[cy + 1][0] = 0; cy++; }
            if (cx > (int)strlen(buf_lines[cy])) cx = (int)strlen(buf_lines[cy]);
        }
        else if (key == -KEY_LEFT && cx > 0) cx--;
        else if (key == -KEY_RIGHT && cx < (int)strlen(buf_lines[cy])) cx++;
        else if (key == KEY_HOME) cx = 0;
        else if (key == KEY_END)  cx = (int)strlen(buf_lines[cy]);
        else if (key == KEY_PGUP) {
            if (cy >= 20) cy -= 20; else cy = 0;
            cx = (int)strlen(buf_lines[cy]);
        }
        else if (key == KEY_PGDN) {
            cy += 20;
            if (cy >= line_count) cy = line_count - 1;
            cx = (int)strlen(buf_lines[cy]);
        }
        else if (key == KEY_DELETE) {
            int len = (int)strlen(buf_lines[cy]);
            if (cx < len) {
                for (int i = cx; i < len; i++) buf_lines[cy][i] = buf_lines[cy][i + 1];
                dirty = 1;
            }
        }
        else if (key == '\b') {
            if (cx > 0) {
                int len = (int)strlen(buf_lines[cy]);
                for (int i = cx - 1; i < len; i++) buf_lines[cy][i] = buf_lines[cy][i + 1];
                cx--;
                dirty = 1;
            } else if (cy > 0) {
                int prev_len = (int)strlen(buf_lines[cy - 1]);
                int cur_len  = (int)strlen(buf_lines[cy]);
                if (prev_len + cur_len < FTE_MAX_LINE) {
                    for (int i = 0; i <= cur_len; i++)
                        buf_lines[cy - 1][prev_len + i] = buf_lines[cy][i];
                    for (int i = cy; i < line_count - 1; i++)
                        strcpy(buf_lines[i], buf_lines[i + 1]);
                    line_count--;
                    cy--;
                    cx = prev_len;
                    dirty = 1;
                }
            }
        }
        else if (key == '\n') {
            if (line_count < FTE_MAX_LINES) {
                for (int i = line_count; i > cy + 1; i--) strcpy(buf_lines[i], buf_lines[i - 1]);
                int len = (int)strlen(buf_lines[cy]);
                int j = 0;
                for (int i = cx; i <= len; i++) buf_lines[cy + 1][j++] = buf_lines[cy][i];
                buf_lines[cy][cx] = 0;
                line_count++;
                cy++;
                cx = 0;
                dirty = 1;
            }
        }
        else if (key > 0 && key < 128) {
            int len = (int)strlen(buf_lines[cy]);
            if (len < FTE_MAX_LINE) {
                for (int i = len; i >= cx; i--) buf_lines[cy][i + 1] = buf_lines[cy][i];
                buf_lines[cy][cx] = (char)key;
                cx++;
                dirty = 1;
            }
        }
        if (cy < scroll) scroll = cy;
        if (cy >= scroll + 22) scroll = cy - 21;
    }
    vga_set_cursor(0, 0);
    vga_clear(vga_make_color(VGA_LIGHT_GREY, VGA_BLACK));
}
