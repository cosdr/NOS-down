#include "autoexec.h"
#include "vga.h"
#include "config.h"
#include "fat12.h"
#include "ramdisk.h"
#include "utils.h"

extern void shell_execute_line(const char* line);

static int is_var_char(char c) {
    return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
           (c >= '0' && c <= '9') || c == '_';
}
static void substitute(const char* in, char* out, int max) {
    config_t* cfg = config_get();
    int i = 0, j = 0;
    while (in[i] && j < max - 1) {
        if (in[i] == '$') {
            if (strncmp(&in[i + 1], "username", 8) == 0 && !is_var_char(in[i + 9])) {
                const char* u = cfg->username;
                while (*u && j < max - 1) out[j++] = *u++;
                i += 9; continue;
            }
            if (strncmp(&in[i + 1], "timezone", 8) == 0 && !is_var_char(in[i + 9])) {
                char tzb[8]; itoa(cfg->tz_offset, tzb, 10);
                const char* t = tzb;
                while (*t && j < max - 1) out[j++] = *t++;
                i += 9; continue;
            }
        }
        out[j++] = in[i++];
    }
    out[j] = 0;
}
static int read_file_anywhere(const char* name, char* buf, int max) {
    int n = -1;
    if (fat12_is_mounted()) n = fat12_read_file(name, buf, max - 1);
    if (n < 0) {
        int fd = ramdisk_get_fd(name);
        if (fd >= 0) n = ramdisk_read(fd, buf, max - 1);
    }
    if (n > 0) buf[n] = 0;
    return n;
}

void autoexec_run(const char* filename) {
    char buf[4096];
    int n = read_file_anywhere(filename, buf, sizeof(buf));
    if (n <= 0) return;
    uint8_t header_fg = vga_make_color(VGA_LIGHT_CYAN, VGA_BLACK);
    uint8_t cmd_fg    = vga_make_color(VGA_DARK_GREY, VGA_BLACK);
    vga_print_at("[AUTOEXEC.NE]\n", header_fg);
    int i = 0;
    char line[256];
    while (i < n) {
        int lp = 0;
        while (i < n && buf[i] != '\n' && lp < 255) line[lp++] = buf[i++];
        if (i < n && buf[i] == '\n') i++;
        line[lp] = 0;
        while (lp > 0 && (line[lp - 1] == '\r' || line[lp - 1] == ' ')) line[--lp] = 0;
        if (lp == 0) continue;
        if (line[0] == '#') continue;
        char expanded[256];
        substitute(line, expanded, sizeof(expanded));
        vga_print_at("> ", cmd_fg);
        vga_print_at(expanded, cmd_fg);
        vga_putchar_at('\n', cmd_fg);
        shell_execute_line(expanded);
    }
    vga_print_at("[AUTOEXEC.NE done]\n\n", header_fg);
}

void motd_show(void) {
    char buf[1024];
    int n = read_file_anywhere("MOTD.TXT", buf, sizeof(buf));
    if (n <= 0) return;
    int lines = 1;
    for (int i = 0; i < n; i++) if (buf[i] == ';') lines++;
    uint32_t pick = rng_next() % lines;
    int start = 0, cur = 0;
    for (int i = 0; i <= n; i++) {
        if (i == n || buf[i] == ';') {
            if (cur == (int)pick) break;
            cur++;
            start = i + 1;
        }
    }
    while (start < n && (buf[start] == ' ' || buf[start] == '\n' || buf[start] == '\r')) start++;
    int end = start;
    while (end < n && buf[end] != ';' && buf[end] != '\n') end++;
    uint8_t fg = vga_make_color(VGA_LIGHT_CYAN, VGA_BLACK);
    vga_print_at("MOTD: ", vga_make_color(VGA_LIGHT_GREEN, VGA_BLACK));
    for (int i = start; i < end; i++) vga_putchar_at(buf[i], fg);
    vga_putchar_at('\n', fg);
    vga_putchar_at('\n', fg);
}
