#include "sysmenu.h"
#include "vga.h"
#include "keyboard.h"
#include "power.h"
#include "pcspk.h"
#include "utils.h"

static const char* options[] = { "shutdown", "reboot", "shell" };
#define N_OPT ((int)(sizeof(options)/sizeof(options[0])))

void sysmenu_run(void) {
    int w = 34, h = 9;
    int x = (80 - w) / 2;
    int y = (25 - h) / 2;
    int sel = 2;
    static uint16_t saved[9 * 34];
    for (int j = 0; j < h; j++)
        for (int i = 0; i < w; i++) {
            int sx = x + i, sy = y + j;
            uint8_t attr = vga_getcell_color(sx, sy);
            char    c    = vga_getcell(sx, sy);
            saved[j * w + i] = (uint16_t)(((uint16_t)attr << 8) | (uint8_t)c);
        }
    uint8_t bg_grey  = VGA_LIGHT_GREY;
    uint8_t fg_black = vga_make_color(VGA_BLACK, bg_grey);
    while (1) {
        vga_fill_bg(x, y, w, h, ' ', VGA_BLACK, bg_grey);
        vga_draw_box(x, y, w, h, vga_make_color(VGA_BLACK, bg_grey));
        vga_print(" System Menu ", fg_black, x + 3, y);
        for (int i = 0; i < N_OPT; i++) {
            int row = y + 2 + i * 2;
            uint8_t fg = (i == sel) ? VGA_WHITE : VGA_BLACK;
            uint8_t bg = (i == sel) ? VGA_BLACK : bg_grey;
            for (int k = 0; k < w - 2; k++) vga_putcell(x + 1 + k, row, ' ', fg, bg);
            vga_putcell(x + 2, row, (i == sel) ? '>' : ' ', fg, bg);
            vga_print(options[i], vga_make_color(fg, bg), x + 4, row);
        }
        vga_print("Alt+Del: Menu  ESC: Close", vga_make_color(VGA_BLACK, bg_grey), x + 2, y + h - 1);
        int key = keyboard_getchar();
        if (key == -KEY_ESC || key == KEY_ALT_DEL) break;
        else if (key == -KEY_UP && sel > 0) sel--;
        else if (key == -KEY_DOWN && sel < N_OPT - 1) sel++;
        else if (key == '\n') {
            if (sel == 0) { pcspk_click(); power_shutdown(); }
            else if (sel == 1) { pcspk_click(); power_reboot(); }
            else break;
        }
    }
    for (int j = 0; j < h; j++)
        for (int i = 0; i < w; i++) {
            int sx = x + i, sy = y + j;
            uint16_t v = saved[j * w + i];
            vga_putchar((char)(v & 0xFF), (uint8_t)(v >> 8), sx, sy);
        }
}
