#ifndef PALETTE_H
#define PALETTE_H

#include "stdint.h"

typedef struct {
    const char* name;
    uint8_t rgb[16][3];
} theme_def_t;

void               palette_set_entry(int idx, uint8_t r, uint8_t g, uint8_t b);
void               palette_load(const uint8_t pal[16][3]);
void               palette_load_default(void);
int                palette_theme_count(void);
const theme_def_t* palette_theme(int idx);
const char*        palette_theme_name(int idx);
void               palette_apply_theme(int theme_id);
int                palette_find_theme(const char* name);

#endif
