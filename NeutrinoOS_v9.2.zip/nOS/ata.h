#ifndef ATA_H
#define ATA_H

#include "stdint.h"

int ata_init(void);
int ata_read_sectors(uint32_t lba, uint8_t count, uint8_t* buffer);
int ata_write_sectors(uint32_t lba, uint8_t count, const uint8_t* buffer);
int ata_is_ready(void);

#endif
