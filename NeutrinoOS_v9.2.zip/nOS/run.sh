#!/bin/bash
set -e
[ -f neutrino.iso ] || { echo "Run ./build.sh first."; exit 1; }
[ -f disk.img ] || { echo "disk.img missing. Run ./build.sh."; exit 1; }

echo "Starting NeutrinoOS v0.9.2 in QEMU..."
echo "  Arrows = move cursor"
echo "  [ = left click,  ] = right click"
echo "  Alt+Del = Start menu,  Tab = cycle windows,  Esc = close"
echo ""
qemu-system-i386 \
    -cdrom neutrino.iso \
    -drive file=disk.img,format=raw,if=ide,index=0,media=disk \
    -m 32M \
    -boot d
