#include "calc.h"
#include "vga.h"
#include "keyboard.h"
#include "utils.h"

void calc_run(void) {
    uint8_t border  = vga_make_color(VGA_BLUE, VGA_BLACK);
    uint8_t title   = vga_make_color(VGA_LIGHT_CYAN, VGA_BLACK);
    uint8_t input_fg = vga_make_color(VGA_WHITE, VGA_BLACK);
    uint8_t ok_fg   = vga_make_color(VGA_LIGHT_GREEN, VGA_BLACK);
    uint8_t err_fg  = vga_make_color(VGA_LIGHT_RED, VGA_BLACK);
    uint8_t hint_fg = vga_make_color(VGA_DARK_GREY, VGA_BLACK);
    char expr[64];
    while (1) {
        vga_clear(vga_make_color(VGA_LIGHT_GREY, VGA_BLACK));
        vga_draw_box(10, 5, 60, 14, border);
        vga_print("=== CALCULATOR ===", title, 30, 6);
        vga_print("Supported: + - * /  (integer)", hint_fg, 20, 8);
        vga_print("Type 'q' to quit", hint_fg, 20, 9);
        vga_print("> ", title, 15, 12);
        vga_set_cursor(17, 12);
        int pos = 0;
        while (1) {
            int k = keyboard_getchar();
            if (k == '\n') { expr[pos] = 0; break; }
            if (k == -KEY_ESC) { vga_clear(vga_make_color(VGA_LIGHT_GREY, VGA_BLACK)); return; }
            if (k == '\b' && pos > 0) {
                pos--;
                vga_putchar_at('\b', input_fg);
                vga_putchar_at(' ', input_fg);
                vga_putchar_at('\b', input_fg);
            } else if (k > 0 && k < 128 && pos < 63) {
                expr[pos++] = (char)k;
                vga_putchar_at((char)k, input_fg);
            }
        }
        if (pos == 0) continue;
        if (expr[0] == 'q' || expr[0] == 'Q') return;
        int a = 0, b = 0, i = 0;
        int neg_a = 0;
        if (expr[i] == '-') { neg_a = 1; i++; }
        while (expr[i] >= '0' && expr[i] <= '9') { a = a * 10 + (expr[i] - '0'); i++; }
        if (neg_a) a = -a;
        while (expr[i] == ' ') i++;
        char op = expr[i++];
        while (expr[i] == ' ') i++;
        int neg_b = 0;
        if (expr[i] == '-') { neg_b = 1; i++; }
        while (expr[i] >= '0' && expr[i] <= '9') { b = b * 10 + (expr[i] - '0'); i++; }
        if (neg_b) b = -b;
        int result = 0, valid = 1;
        switch (op) {
            case '+': result = a + b; break;
            case '-': result = a - b; break;
            case '*': result = a * b; break;
            case '/': if (b == 0) valid = 0; else result = a / b; break;
            default:  valid = 0;
        }
        vga_print("= ", ok_fg, 15, 14);
        if (!valid) vga_print("ERROR (invalid or div by zero)", err_fg, 17, 14);
        else { char rb[16]; itoa(result, rb, 10); vga_print(rb, ok_fg, 17, 14); }
        vga_print("Press any key for next...", hint_fg, 15, 16);
        keyboard_getchar();
    }
}
