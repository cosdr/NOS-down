#include "cpu.h"
#include "vga.h"
#include "keyboard.h"
#include "utils.h"

typedef struct { uint32_t eax, ebx, ecx, edx; } cpuid_result_t;

static void cpuid(uint32_t leaf, uint32_t subleaf, cpuid_result_t* out) {
    __asm__ volatile("cpuid"
        : "=a"(out->eax), "=b"(out->ebx), "=c"(out->ecx), "=d"(out->edx)
        : "a"(leaf), "c"(subleaf));
}
static void cpuid_to_str(uint32_t reg, char* buf) {
    buf[0] = (char)(reg & 0xFF); buf[1] = (char)((reg >> 8) & 0xFF);
    buf[2] = (char)((reg >> 16) & 0xFF); buf[3] = (char)((reg >> 24) & 0xFF);
    buf[4] = 0;
}
int cpu_get_vendor(char* out, int max) {
    if (max < 13) return 0;
    cpuid_result_t r; cpuid(0, 0, &r);
    cpuid_to_str(r.ebx, &out[0]);
    cpuid_to_str(r.edx, &out[4]);
    cpuid_to_str(r.ecx, &out[8]);
    out[12] = 0; return 12;
}
int cpu_get_brand(char* out, int max) {
    if (max < 49) return 0;
    cpuid_result_t r;
    cpuid(0x80000000, 0, &r);
    if (r.eax < 0x80000004) return 0;
    cpuid(0x80000002, 0, &r);
    cpuid_to_str(r.eax, &out[0]); cpuid_to_str(r.ebx, &out[4]);
    cpuid_to_str(r.ecx, &out[8]); cpuid_to_str(r.edx, &out[12]);
    cpuid(0x80000003, 0, &r);
    cpuid_to_str(r.eax, &out[16]); cpuid_to_str(r.ebx, &out[20]);
    cpuid_to_str(r.ecx, &out[24]); cpuid_to_str(r.edx, &out[28]);
    cpuid(0x80000004, 0, &r);
    cpuid_to_str(r.eax, &out[32]); cpuid_to_str(r.ebx, &out[36]);
    cpuid_to_str(r.ecx, &out[40]); cpuid_to_str(r.edx, &out[44]);
    out[48] = 0;
    char* p = out;
    while (*p == ' ') p++;
    if (p != out) { int i = 0; while (p[i]) { out[i] = p[i]; i++; } out[i] = 0; }
    return strlen(out);
}
void cpu_show(void) {
    uint8_t title_fg = vga_make_color(VGA_LIGHT_CYAN, VGA_BLACK);
    uint8_t label_fg = vga_make_color(VGA_LIGHT_BLUE, VGA_BLACK);
    uint8_t value_fg = vga_make_color(VGA_WHITE, VGA_BLACK);
    uint8_t ok_fg    = vga_make_color(VGA_LIGHT_GREEN, VGA_BLACK);
    uint8_t dim_fg   = vga_make_color(VGA_DARK_GREY, VGA_BLACK);
    vga_clear(vga_make_color(VGA_BLACK, VGA_BLACK));
    vga_draw_box(2, 1, 76, 22, vga_make_color(VGA_BLUE, VGA_BLACK));
    vga_print("=== CPU Information ===", title_fg, 4, 2);
    int line = 4;
    char buf[64];
    cpuid_result_t r;
    cpuid(0, 0, &r);
    char vendor[13];
    cpuid_to_str(r.ebx, &vendor[0]);
    cpuid_to_str(r.edx, &vendor[4]);
    cpuid_to_str(r.ecx, &vendor[8]);
    vendor[12] = 0;
    vga_print("Vendor", label_fg, 4, line); vga_print(": ", value_fg, 14, line); vga_print(vendor, value_fg, 16, line); line++;
    vga_print("Max CPUID", label_fg, 4, line); vga_print(": 0x", value_fg, 14, line);
    itoa((int)r.eax, buf, 16); vga_print(buf, value_fg, 18, line); line++;
    char brand[64];
    if (cpu_get_brand(brand, sizeof(brand)) > 0) {
        vga_print("Brand", label_fg, 4, line); vga_print(": ", value_fg, 14, line); vga_print(brand, value_fg, 16, line); line++;
    }
    cpuid(1, 0, &r);
    uint32_t eax = r.eax;
    uint32_t stepping = eax & 0xF, model = (eax >> 4) & 0xF, family = (eax >> 8) & 0xF;
    uint32_t ext_model = (eax >> 16) & 0xF, ext_family = (eax >> 20) & 0xFF;
    if (family == 0xF) family += ext_family;
    if (family == 0x6 || family == 0xF) model += (ext_model << 4);
    vga_print("Family", label_fg, 4, line); vga_print(": ", value_fg, 14, line);
    itoa((int)family, buf, 10); vga_print(buf, value_fg, 16, line); line++;
    vga_print("Model", label_fg, 4, line); vga_print(": ", value_fg, 14, line);
    itoa((int)model, buf, 10); vga_print(buf, value_fg, 16, line); line++;
    vga_print("Stepping", label_fg, 4, line); vga_print(": ", value_fg, 14, line);
    itoa((int)stepping, buf, 10); vga_print(buf, value_fg, 16, line); line++;
    vga_print("Features", label_fg, 4, line); vga_print(": ", value_fg, 14, line);
    int pos = 16;
    uint32_t edx = r.edx, ecx = r.ecx;
    if (edx & (1 << 0))  { vga_print("FPU ",  ok_fg, pos, line); pos += 4; }
    if (edx & (1 << 4))  { vga_print("TSC ",  ok_fg, pos, line); pos += 4; }
    if (edx & (1 << 5))  { vga_print("MSR ",  ok_fg, pos, line); pos += 4; }
    if (edx & (1 << 6))  { vga_print("PAE ",  ok_fg, pos, line); pos += 4; }
    if (edx & (1 << 9))  { vga_print("APIC ", ok_fg, pos, line); pos += 5; }
    if (edx & (1 << 15)) { vga_print("CMOV ", ok_fg, pos, line); pos += 5; }
    if (edx & (1 << 23)) { vga_print("MMX ",  ok_fg, pos, line); pos += 4; }
    if (edx & (1 << 25)) { vga_print("SSE ",  ok_fg, pos, line); pos += 4; }
    if (edx & (1 << 26)) { vga_print("SSE2 ", ok_fg, pos, line); pos += 5; }
    if (edx & (1 << 28)) { vga_print("HTT ",  ok_fg, pos, line); pos += 4; }
    if (ecx & (1 << 0))  { vga_print("SSE3 ", ok_fg, pos, line); pos += 5; }
    line += 2;
    vga_print("Press any key...", dim_fg, 4, 21);
    keyboard_getchar();
    vga_clear(vga_make_color(VGA_LIGHT_GREY, VGA_BLACK));
}
