#include "editor.h"
#include "vga.h"
#include "keyboard.h"
#include "fat12.h"
#include "ramdisk.h"
#include "utils.h"

#define ED_MAX_LINES 200
#define ED_MAX_LINE  76

static char lines[ED_MAX_LINES][ED_MAX_LINE + 1];
static int  line_count = 0;

void editor_run(const char* filename) {
    line_count = 1;
    for (int i = 0; i < ED_MAX_LINES; i++) lines[i][0] = 0;
    char buf[8192];
    int n = -1;
    if (fat12_is_mounted()) n = fat12_read_file(filename, buf, sizeof(buf) - 1);
    if (n < 0) {
        int fd = ramdisk_get_fd(filename);
        if (fd >= 0) n = ramdisk_read(fd, buf, sizeof(buf) - 1);
    }
    if (n > 0) {
        buf[n] = 0;
        int pos = 0, lc = 0, lp = 0;
        while (buf[pos] && lc < ED_MAX_LINES) {
            if (buf[pos] == '\n') { lines[lc][lp] = 0; lc++; lp = 0; }
            else if (lp < ED_MAX_LINE) lines[lc][lp++] = buf[pos];
            pos++;
        }
        if (lp > 0) lines[lc][lp] = 0;
        line_count = lc + 1;
        if (line_count < 1) line_count = 1;
    }
    int cx = 0, cy = 0, scroll = 0, dirty = 0, running = 1;
    while (running) {
        vga_clear(vga_make_color(VGA_LIGHT_GREY, VGA_BLACK));
        vga_draw_box(0, 0, 80, 24, vga_make_color(VGA_BLUE, VGA_BLACK));
        char title[64] = "EDIT: ";
        strcat(title, filename);
        if (dirty) strcat(title, " [*]");
        vga_print(title, vga_make_color(VGA_YELLOW, VGA_BLACK), 2, 0);
        for (int i = 0; i < 22; i++) {
            int li = scroll + i;
            if (li >= line_count) break;
            vga_print(lines[li], vga_make_color(VGA_LIGHT_GREY, VGA_BLACK), 2, 1 + i);
        }
        vga_print("F1=Save  ESC=Quit  Arrows=Move", vga_make_color(VGA_DARK_GREY, VGA_BLACK), 2, 24);
        int screen_y = 1 + (cy - scroll);
        if (screen_y >= 1 && screen_y < 23) vga_set_cursor(2 + cx, screen_y);
        int key = keyboard_getchar();
        if (key == -KEY_ESC) running = 0;
        else if (key == -KEY_F1) {
            char save_buf[8192];
            int pos = 0;
            for (int i = 0; i < line_count; i++) {
                int j = 0;
                while (lines[i][j] && pos < 8191) save_buf[pos++] = lines[i][j++];
                if (pos < 8191) save_buf[pos++] = '\n';
            }
            save_buf[pos] = 0;
            if (fat12_is_mounted()) fat12_write_file(filename, save_buf, pos);
            int fd = ramdisk_create(filename);
            if (fd >= 0) ramdisk_write(fd, save_buf, pos);
            dirty = 0;
        }
        else if (key == -KEY_UP && cy > 0) cy--;
        else if (key == -KEY_DOWN) {
            if (cy < line_count - 1) cy++;
            else if (line_count < ED_MAX_LINES) { line_count++; lines[cy + 1][0] = 0; cy++; }
        }
        else if (key == -KEY_LEFT && cx > 0) cx--;
        else if (key == -KEY_RIGHT) { if (lines[cy][cx]) cx++; }
        else if (key == '\b') {
            if (cx > 0) {
                int len = strlen(lines[cy]);
                for (int i = cx - 1; i < len; i++) lines[cy][i] = lines[cy][i + 1];
                cx--; dirty = 1;
            }
        }
        else if (key == '\n') {
            if (line_count < ED_MAX_LINES) {
                for (int i = line_count; i > cy + 1; i--) strcpy(lines[i], lines[i - 1]);
                int len = strlen(lines[cy]);
                int j = 0;
                for (int i = cx; i <= len; i++) lines[cy + 1][j++] = lines[cy][i];
                lines[cy][cx] = 0;
                line_count++; cy++; cx = 0; dirty = 1;
            }
        }
        else if (key > 0 && key < 128) {
            int len = strlen(lines[cy]);
            if (len < ED_MAX_LINE) {
                for (int i = len; i >= cx; i--) lines[cy][i + 1] = lines[cy][i];
                lines[cy][cx] = (char)key;
                cx++; dirty = 1;
            }
        }
        if (cy < scroll) scroll = cy;
        if (cy >= scroll + 22) scroll = cy - 21;
    }
    vga_set_cursor(0, 0);
    vga_clear(vga_make_color(VGA_LIGHT_GREY, VGA_BLACK));
}
