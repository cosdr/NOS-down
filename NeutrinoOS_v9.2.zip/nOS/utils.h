#ifndef UTILS_H
#define UTILS_H

#include "stdint.h"

void* memset(void* ptr, int value, int num);
void* memcpy(void* dest, const void* src, int num);
int   strlen(const char* str);
int   strcmp(const char* a, const char* b);
int   strcasecmp(const char* a, const char* b);
int   strncmp(const char* a, const char* b, int n);
int   strncasecmp(const char* a, const char* b, int n);
void  strcpy(char* dest, const char* src);
void  strncpy(char* dest, const char* src, int n);
void  strcat(char* dest, const char* src);
int   atoi(const char* str);
void  itoa(int value, char* str, int base);
void  itoa_pad(int value, char* str, int width);
void  delay(int cycles);
char  to_lower(char c);
char  to_upper(char c);
int   is_digit(char c);
int   strstr_idx(const char* haystack, const char* needle);
uint32_t rng_next(void);

void     outb(uint16_t port, uint8_t data);
uint8_t  inb(uint16_t port);
void     outw(uint16_t port, uint16_t data);
uint16_t inw(uint16_t port);
void     outl(uint16_t port, uint32_t data);
uint32_t inl(uint16_t port);

#endif
