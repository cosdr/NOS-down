#ifndef FAT12_H
#define FAT12_H

#include "stdint.h"

#define FAT12_MAX_FILES 128
#define FAT12_MAX_FILENAME 64
#define FAT12_MAX_FILESIZE 65536

typedef struct {
    char name[FAT12_MAX_FILENAME];
    uint32_t first_cluster;
    uint32_t size;
    int is_dir;
    int used;
} fat12_entry_t;

int  fat12_init(void);
int  fat12_is_mounted(void);
int  fat12_list(fat12_entry_t* out, int max_count);
int  fat12_find(const char* name);
int  fat12_read_file(const char* name, char* buffer, int max_size);
int  fat12_read_raw(const char* name, uint8_t* buffer, int max_size);
int  fat12_write_file(const char* name, const char* data, int size);
int  fat12_write_raw(const char* name, const uint8_t* data, int size);
int  fat12_delete_file(const char* name);
int  fat12_mkdir(const char* name);
int  fat12_format(void);
void fat12_usage(uint32_t* total_bytes, uint32_t* free_bytes, uint32_t* used_bytes);

#endif
