#include "clock.h"
#include "vga.h"
#include "keyboard.h"
#include "rtc.h"
#include "config.h"
#include "bigfont.h"
#include "utils.h"

void clock_run(void) {
    config_t* cfg = config_get();
    int fg = VGA_LIGHT_GREEN, bg = VGA_BLACK;
    int h24 = 1;
    int running = 1;
    int last_ss = -1;
    while (running) {
        rtc_time_t t;
        rtc_get_local(&t, cfg->tz_offset);
        int hh = t.hour, mm = t.minute, ss = t.second;
        int disp_h = hh;
        if (!h24) { disp_h = hh % 12; if (disp_h == 0) disp_h = 12; }
        if (ss != last_ss) {
            last_ss = ss;
            vga_clear(vga_make_color(VGA_LIGHT_GREY, VGA_BLACK));
            vga_draw_box(2, 1, 76, 22, vga_make_color(VGA_BLUE, VGA_BLACK));
            vga_print("=== CLOCK ===", vga_make_color(VGA_LIGHT_CYAN, VGA_BLACK), 34, 2);
            char buf[16];
            itoa_pad(disp_h, &buf[0], 2); buf[2] = ':';
            itoa_pad(mm,     &buf[3], 2); buf[5] = ':';
            itoa_pad(ss,     &buf[6], 2); buf[8] = 0;
            int width = bigfont_string_width(buf);
            bigfont_draw_string(buf, (80 - width) / 2, 9, (uint8_t)fg, (uint8_t)bg);
            char dbuf[16];
            itoa_pad(t.day,   &dbuf[0], 2); dbuf[2] = '.';
            itoa_pad(t.month, &dbuf[3], 2); dbuf[5] = '.';
            itoa(t.year,      &dbuf[6], 10);
            vga_print(dbuf, vga_make_color(VGA_YELLOW, VGA_BLACK), 35, 16);
            vga_print("F=fg B=bg H=12/24 ESC=exit",
                      vga_make_color(VGA_DARK_GREY, VGA_BLACK), 22, 22);
        }
        for (int tick = 0; tick < 60 && running; tick++) {
            int k = keyboard_poll();
            if (k != -1) {
                if (k == -KEY_ESC) running = 0;
                else if (k == 'f' || k == 'F') { fg = (fg + 1) % 16; last_ss = -1; }
                else if (k == 'b' || k == 'B') { bg = (bg + 1) % 16; last_ss = -1; }
                else if (k == 'h' || k == 'H') { h24 = !h24; last_ss = -1; }
            }
            for (volatile int d = 0; d < 100; d++)
                for (volatile int e = 0; e < 1000; e++) { }
        }
    }
    vga_clear(vga_make_color(VGA_LIGHT_GREY, VGA_BLACK));
}
