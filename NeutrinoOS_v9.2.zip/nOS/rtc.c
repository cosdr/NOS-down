#include "rtc.h"
#include "utils.h"

static int rtc_updating(void) { outb(0x70, 0x0A); return inb(0x71) & 0x80; }
static uint8_t rtc_read_reg(uint8_t reg) { outb(0x70, reg); return inb(0x71); }
static uint8_t bcd_to_bin(uint8_t bcd) { return (uint8_t)((bcd & 0x0F) + ((bcd >> 4) * 10)); }

void rtc_read(rtc_time_t* t) {
    while (rtc_updating());
    uint8_t sec  = rtc_read_reg(0x00);
    uint8_t min  = rtc_read_reg(0x02);
    uint8_t hour = rtc_read_reg(0x04);
    uint8_t day  = rtc_read_reg(0x07);
    uint8_t mon  = rtc_read_reg(0x08);
    uint8_t year = rtc_read_reg(0x09);
    uint8_t regB = rtc_read_reg(0x0B);
    if (!(regB & 0x04)) {
        sec  = bcd_to_bin(sec); min = bcd_to_bin(min);
        uint8_t pm = hour & 0x80;
        hour = bcd_to_bin(hour & 0x7F);
        if (!(regB & 0x02) && pm) hour = (uint8_t)((hour + 12) % 24);
        day = bcd_to_bin(day); mon = bcd_to_bin(mon); year = bcd_to_bin(year);
    } else {
        if (!(regB & 0x02) && (hour & 0x80)) hour = (uint8_t)(((hour & 0x7F) + 12) % 24);
    }
    t->second = sec; t->minute = min; t->hour = hour;
    t->day = day; t->month = mon; t->year = 2000 + year;
}
void rtc_write(rtc_time_t* t) {
    while (rtc_updating());
    uint8_t regB = rtc_read_reg(0x0B);
    int bcd = !(regB & 0x04);
    uint8_t sec, min, hour, day, mon, year;
    if (bcd) {
        sec  = (uint8_t)(((t->second/10)<<4) | (t->second%10));
        min  = (uint8_t)(((t->minute/10)<<4) | (t->minute%10));
        hour = (uint8_t)(((t->hour/10)<<4)   | (t->hour%10));
        day  = (uint8_t)(((t->day/10)<<4)    | (t->day%10));
        mon  = (uint8_t)(((t->month/10)<<4)  | (t->month%10));
        year = (uint8_t)((((t->year-2000)/10)<<4) | ((t->year-2000)%10));
    } else {
        sec = (uint8_t)t->second; min = (uint8_t)t->minute; hour = (uint8_t)t->hour;
        day = (uint8_t)t->day; mon = (uint8_t)t->month; year = (uint8_t)(t->year-2000);
    }
    outb(0x70, 0x80 | 0x00); outb(0x71, sec);
    outb(0x70, 0x80 | 0x02); outb(0x71, min);
    outb(0x70, 0x80 | 0x04); outb(0x71, hour);
    outb(0x70, 0x80 | 0x07); outb(0x71, day);
    outb(0x70, 0x80 | 0x08); outb(0x71, mon);
    outb(0x70, 0x80 | 0x09); outb(0x71, year);
    outb(0x70, 0x00);
}
void rtc_get_local(rtc_time_t* t, int tz_offset) {
    rtc_read(t);
    t->hour += tz_offset;
    int dim[] = {31,28,31,30,31,30,31,31,30,31,30,31};
    while (t->hour >= 24) {
        t->hour -= 24; t->day++;
        int max_day = dim[t->month - 1];
        if (t->month == 2 && ((t->year % 4 == 0 && t->year % 100 != 0) || (t->year % 400 == 0))) max_day = 29;
        if (t->day > max_day) { t->day = 1; t->month++; if (t->month > 12) { t->month = 1; t->year++; } }
    }
    while (t->hour < 0) {
        t->hour += 24; t->day--;
        if (t->day < 1) {
            t->month--;
            if (t->month < 1) { t->month = 12; t->year--; }
            int max_day = dim[t->month - 1];
            if (t->month == 2 && ((t->year % 4 == 0 && t->year % 100 != 0) || (t->year % 400 == 0))) max_day = 29;
            t->day = max_day;
        }
    }
}
void rtc_sleep_ms(int ms) {
    for (int i = 0; i < ms; i++)
        for (volatile int d = 0; d < 2000; d++) { }
}
