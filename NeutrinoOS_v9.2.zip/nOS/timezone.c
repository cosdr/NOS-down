#include "timezone.h"
#include "utils.h"

static const tz_entry_t tz_list[] = {
    { "Pacific/Midway",       -11 },
    { "Pacific/Honolulu",     -10 },
    { "America/Anchorage",     -9 },
    { "America/Los_Angeles",   -8 },
    { "America/Denver",        -7 },
    { "America/Chicago",       -6 },
    { "America/New_York",      -5 },
    { "America/Halifax",       -4 },
    { "America/Sao_Paulo",     -3 },
    { "Atlantic/Azores",       -1 },
    { "UTC",                    0 },
    { "Europe/London",          0 },
    { "Europe/Berlin",          1 },
    { "Europe/Paris",           1 },
    { "Europe/Athens",          2 },
    { "Europe/Moscow",          3 },
    { "Europe/Istanbul",        3 },
    { "Asia/Dubai",             4 },
    { "Asia/Karachi",           5 },
    { "Asia/Yekaterinburg",     5 },
    { "Asia/Omsk",              6 },
    { "Asia/Dhaka",             6 },
    { "Asia/Bangkok",           7 },
    { "Asia/Novosibirsk",       7 },
    { "Asia/Krasnoyarsk",       7 },
    { "Asia/Shanghai",          8 },
    { "Asia/Irkutsk",           8 },
    { "Asia/Tokyo",             9 },
    { "Asia/Yakutsk",           9 },
    { "Asia/Vladivostok",      10 },
    { "Australia/Sydney",      10 },
    { "Asia/Magadan",          11 },
    { "Asia/Kamchatka",        12 },
    { "Pacific/Auckland",      12 },
    { "Pacific/Kiritimati",    14 },
};
#define TZ_COUNT ((int)(sizeof(tz_list)/sizeof(tz_list[0])))

int tz_count(void) { return TZ_COUNT; }
const tz_entry_t* tz_get(int idx) {
    if (idx < 0 || idx >= TZ_COUNT) return &tz_list[0];
    return &tz_list[idx];
}
int tz_find_index(const char* name) {
    for (int i = 0; i < TZ_COUNT; i++)
        if (strcasecmp(tz_list[i].name, name) == 0) return i;
    return -1;
}
void tz_format_offset(int offset, char* out, int max) {
    int p = 0;
    if (max < 8) { if (max > 0) out[0] = 0; return; }
    out[p++] = 'U'; out[p++] = 'T'; out[p++] = 'C';
    if (offset >= 0) out[p++] = '+'; else { out[p++] = '-'; offset = -offset; }
    if (offset < 10) out[p++] = '0';
    char tmp[4]; itoa(offset, tmp, 10);
    int i = 0; while (tmp[i] && p < max - 1) out[p++] = tmp[i++];
    out[p] = 0;
}
static char display_buf[64];
const char* tz_display(int idx) {
    if (idx < 0 || idx >= TZ_COUNT) return "";
    const tz_entry_t* e = &tz_list[idx];
    int p = 0, i = 0;
    while (e->name[i] && p < 40) display_buf[p++] = e->name[i++];
    while (p < 44) display_buf[p++] = ' ';
    char off[8]; tz_format_offset(e->offset, off, sizeof(off));
    i = 0;
    while (off[i] && p < 62) display_buf[p++] = off[i++];
    display_buf[p] = 0;
    return display_buf;
}
