#ifndef MOUSE_H
#define MOUSE_H

#include "stdint.h"

/* Pseudo-mouse: cursor controlled by arrow keys, click with [ (LKM) and ] (PKM). */

#define MOUSE_BTN_NONE   0
#define MOUSE_BTN_LEFT   1
#define MOUSE_BTN_RIGHT  2

void mouse_init(void);
void mouse_move(int dx, int dy);
void mouse_set(int x, int y);
int  mouse_x(void);
int  mouse_y(void);

void mouse_press(int button);
int  mouse_consume_click(void);

void mouse_draw(void);

#endif
