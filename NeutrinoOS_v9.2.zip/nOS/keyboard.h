#ifndef KEYBOARD_H
#define KEYBOARD_H

#define KEY_ESC       1
#define KEY_BACKSPACE 14
#define KEY_TAB       15
#define KEY_ENTER     28
#define KEY_CTRL      29
#define KEY_LSHIFT    42
#define KEY_RSHIFT    54
#define KEY_ALT       56
#define KEY_SPACE     57
#define KEY_CAPS      58
#define KEY_F1        59
#define KEY_F2        60
#define KEY_F3        61
#define KEY_F4        62
#define KEY_F5        63
#define KEY_F6        64
#define KEY_F7        65
#define KEY_F8        66
#define KEY_F9        67
#define KEY_F10       68
#define KEY_UP        72
#define KEY_DOWN      80
#define KEY_LEFT      75
#define KEY_RIGHT     77

#define KEY_TAB_CODE   0x0F00
#define KEY_CTRL_U     0x1500
#define KEY_CTRL_BKSP  0x1600
#define KEY_SHIFT_TAB  0x1700
#define KEY_ALT_DEL    0x1800
#define KEY_PGUP       0x1900
#define KEY_PGDN       0x1A00
#define KEY_HOME       0x1B00
#define KEY_END        0x1C00
#define KEY_DELETE     0x1D00

void keyboard_init(void);
int  keyboard_getchar(void);
int  keyboard_poll(void);
int  keyboard_is_ctrl(void);
int  keyboard_is_shift(void);
int  keyboard_is_alt(void);
int  keyboard_has_pending(void);

#endif
