#include "bigfont.h"
#include "vga.h"
#include "utils.h"

static const uint8_t digit_bitmap[10][5] = {
    { 0b111, 0b101, 0b101, 0b101, 0b111 },
    { 0b010, 0b110, 0b010, 0b010, 0b111 },
    { 0b111, 0b001, 0b111, 0b100, 0b111 },
    { 0b111, 0b001, 0b111, 0b001, 0b111 },
    { 0b101, 0b101, 0b111, 0b001, 0b001 },
    { 0b111, 0b100, 0b111, 0b001, 0b111 },
    { 0b111, 0b100, 0b111, 0b101, 0b111 },
    { 0b111, 0b001, 0b010, 0b010, 0b010 },
    { 0b111, 0b101, 0b111, 0b101, 0b111 },
    { 0b111, 0b101, 0b111, 0b001, 0b111 },
};

void bigfont_draw_digit(int digit, int x, int y, uint8_t fg, uint8_t bg) {
    if (digit < 0 || digit > 9) return;
    for (int row = 0; row < 5; row++) {
        uint8_t bits = digit_bitmap[digit][row];
        for (int col = 0; col < 3; col++) {
            if (bits & (1 << (2 - col))) vga_putcell(x + col, y + row, CH_FULL_BLOCK, fg, bg);
            else vga_putcell(x + col, y + row, ' ', fg, bg);
        }
    }
}
int bigfont_string_width(const char* str) {
    int w = 0, first = 1;
    while (*str) {
        int gw = 0;
        if (*str >= '0' && *str <= '9') gw = 3;
        else if (*str == ':') gw = 1;
        else if (*str == ' ') gw = 1;
        w += first ? gw : gw + 1;
        first = 0;
        str++;
    }
    return w;
}
void bigfont_draw_string(const char* str, int x, int y, uint8_t fg, uint8_t bg) {
    int cx = x;
    while (*str) {
        if (*str >= '0' && *str <= '9') { bigfont_draw_digit(*str - '0', cx, y, fg, bg); cx += 4; }
        else if (*str == ':') {
            vga_putcell(cx, y + 1, CH_FULL_BLOCK, fg, bg);
            vga_putcell(cx, y + 3, CH_FULL_BLOCK, fg, bg);
            cx += 2;
        } else if (*str == ' ') cx += 2;
        str++;
    }
}
