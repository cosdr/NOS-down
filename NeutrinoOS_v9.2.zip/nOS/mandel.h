#ifndef MANDEL_H
#define MANDEL_H

void mandel_run(void);

#endif
