#include "mouse.h"
#include "vga.h"
#include "utils.h"

#define CURSOR_GLYPH  0x10   /* CP437 ► right-pointing triangle */
#define CURSOR_FG     VGA_LIGHT_GREEN
#define CURSOR_BG     VGA_BLACK

static int mx = 40, my = 12;
static int pending_click = MOUSE_BTN_NONE;

void mouse_init(void) {
    mx = 40;
    my = 12;
    pending_click = MOUSE_BTN_NONE;
}

int mouse_x(void) { return mx; }
int mouse_y(void) { return my; }

void mouse_set(int x, int y) {
    if (x < 0) x = 0;
    if (x >= VGA_WIDTH) x = VGA_WIDTH - 1;
    if (y < 0) y = 0;
    if (y >= VGA_HEIGHT) y = VGA_HEIGHT - 1;
    mx = x;
    my = y;
}

void mouse_move(int dx, int dy) {
    mouse_set(mx + dx, my + dy);
}

void mouse_press(int button) {
    pending_click = button;
}

int mouse_consume_click(void) {
    int b = pending_click;
    pending_click = MOUSE_BTN_NONE;
    return b;
}

void mouse_draw(void) {
    vga_putcell(mx, my, CURSOR_GLYPH, CURSOR_FG, CURSOR_BG);
}
