#include "sheet.h"
#include "vga.h"
#include "keyboard.h"
#include "fat12.h"
#include "ramdisk.h"
#include "utils.h"

#define SH_COLS 8
#define SH_ROWS 10
#define SH_CW   9
#define SH_X0   2
#define SH_Y0   3

static char cells[SH_ROWS][SH_COLS][16];
static int  cur_c = 0, cur_r = 0;
static int  edit_cursor = 0;

static void draw_sheet(void) {
    uint8_t border  = vga_make_color(VGA_LIGHT_CYAN, VGA_BLACK);
    uint8_t header  = vga_make_color(VGA_YELLOW, VGA_BLACK);
    uint8_t normal  = vga_make_color(VGA_LIGHT_GREY, VGA_BLACK);
    uint8_t sfg     = vga_make_color(VGA_BLACK, VGA_LIGHT_CYAN);

    vga_clear(vga_make_color(VGA_BLACK, VGA_BLACK));
    vga_print("=== MikroSheet ===", border, 30, 1);
    vga_print("Arrows=move  ENTER=edit  F1=Save CSV  ESC=quit",
              vga_make_color(VGA_DARK_GREY, VGA_BLACK), 14, 23);

    for (int c = 0; c < SH_COLS; c++) {
        char h[3]; h[0] = (char)('A' + c); h[1] = 0;
        vga_print(h, header, SH_X0 + c * SH_CW + 3, SH_Y0 - 1);
    }
    for (int r = 0; r < SH_ROWS; r++) {
        char rh[4]; itoa(r + 1, rh, 10);
        vga_print(rh, header, SH_X0 - 2, SH_Y0 + r);
    }
    for (int r = 0; r < SH_ROWS; r++) {
        for (int c = 0; c < SH_COLS; c++) {
            int x = SH_X0 + c * SH_CW;
            int y = SH_Y0 + r;
            uint8_t fg, bg;
            if (c == cur_c && r == cur_r) { fg = sfg & 0x0F; bg = (sfg >> 4) & 0x0F; }
            else { fg = normal & 0x0F; bg = (normal >> 4) & 0x0F; }

            for (int k = 0; k < SH_CW - 1; k++) vga_putcell(x + k, y, ' ', fg, bg);

            const char* s = cells[r][c];
            int k = 0;
            while (s[k] && k < SH_CW - 2) { vga_putcell(x + k, y, s[k], fg, bg); k++; }
        }
    }
}

static void edit_cell(void) {
    uint8_t input_fg = vga_make_color(VGA_BLACK, VGA_WHITE);
    int x = SH_X0 + cur_c * SH_CW;
    int y = SH_Y0 + cur_r;

    for (int k = 0; k < SH_CW - 1; k++) vga_putcell(x + k, y, ' ', VGA_BLACK, VGA_WHITE);
    vga_set_cursor(x, y);

    char tmp[16]; int p = 0;
    while (cells[cur_r][cur_c][p] && p < 15) {
        tmp[p] = cells[cur_r][cur_c][p];
        vga_putchar_at(tmp[p], input_fg);
        p++;
    }
    edit_cursor = p;

    for (;;) {
        vga_set_cursor(x + edit_cursor, y);
        int k = keyboard_getchar();
        if (k == '\n') { tmp[p] = 0; break; }
        if (k == -KEY_ESC) return;
        if (k == -KEY_LEFT && edit_cursor > 0) {
            edit_cursor--;
            vga_set_cursor(x + edit_cursor, y);
        }
        else if (k == -KEY_RIGHT && edit_cursor < p) {
            edit_cursor++;
            vga_set_cursor(x + edit_cursor, y);
        }
        else if (k == KEY_HOME) { edit_cursor = 0; }
        else if (k == KEY_END)  { edit_cursor = p; }
        else if (k == KEY_DELETE) {
            if (edit_cursor < p) {
                for (int i = edit_cursor; i < p - 1; i++) tmp[i] = tmp[i + 1];
                p--;
                for (int i = 0; i < SH_CW - 1; i++) vga_putcell(x + i, y, ' ', VGA_BLACK, VGA_WHITE);
                for (int i = 0; i < p; i++) vga_putchar_at(tmp[i], input_fg);
                vga_set_cursor(x + edit_cursor, y);
            }
        }
        else if (k == '\b' && edit_cursor > 0) {
            for (int i = edit_cursor - 1; i < p - 1; i++) tmp[i] = tmp[i + 1];
            p--;
            edit_cursor--;
            for (int i = 0; i < SH_CW - 1; i++) vga_putcell(x + i, y, ' ', VGA_BLACK, VGA_WHITE);
            for (int i = 0; i < p; i++) vga_putchar_at(tmp[i], input_fg);
            vga_set_cursor(x + edit_cursor, y);
        }
        else if (k > 0 && k < 128 && p < 15) {
            for (int i = p; i > edit_cursor; i--) tmp[i] = tmp[i - 1];
            tmp[edit_cursor] = (char)k;
            p++;
            edit_cursor++;
            for (int i = 0; i < SH_CW - 1; i++) vga_putcell(x + i, y, ' ', VGA_BLACK, VGA_WHITE);
            for (int i = 0; i < p; i++) vga_putchar_at(tmp[i], input_fg);
            vga_set_cursor(x + edit_cursor, y);
        }
    }
    int i = 0;
    while (i < 15 && tmp[i]) { cells[cur_r][cur_c][i] = tmp[i]; i++; }
    cells[cur_r][cur_c][i] = 0;
}

static void save_csv(void) {
    char buf[2048]; int pos = 0;
    const char* hdr = "A,B,C,D,E,F,G,H\n";
    while (*hdr && pos < 2000) buf[pos++] = *hdr++;
    for (int r = 0; r < SH_ROWS; r++) {
        int last = -1;
        for (int c = SH_COLS - 1; c >= 0; c--) if (cells[r][c][0]) { last = c; break; }
        if (last < 0) continue;
        for (int c = 0; c <= last; c++) {
            const char* s = cells[r][c];
            while (*s && pos < 2000) buf[pos++] = *s++;
            if (c < last && pos < 2000) buf[pos++] = ',';
        }
        if (pos < 2000) buf[pos++] = '\n';
    }
    buf[pos] = 0;
    if (fat12_is_mounted()) fat12_write_file("SHEET.CSV", buf, pos);
    int fd = ramdisk_create("SHEET.CSV");
    if (fd >= 0) ramdisk_write(fd, buf, pos);
}

void sheet_run(void) {
    for (int r = 0; r < SH_ROWS; r++)
        for (int c = 0; c < SH_COLS; c++)
            cells[r][c][0] = 0;

    char pre[2048];
    int n = -1;
    if (fat12_is_mounted()) n = fat12_read_file("SHEET.CSV", pre, sizeof(pre) - 1);
    if (n > 0) {
        pre[n] = 0;
        int i = 0;
        while (pre[i] && pre[i] != '\n') i++;
        if (pre[i] == '\n') i++;
        for (int r = 0; r < SH_ROWS && pre[i]; r++) {
            for (int c = 0; c < SH_COLS && pre[i] && pre[i] != '\n'; c++) {
                int k = 0;
                while (pre[i] && pre[i] != ',' && pre[i] != '\n' && k < 15)
                    cells[r][c][k++] = pre[i++];
                cells[r][c][k] = 0;
                if (pre[i] == ',') i++;
            }
            while (pre[i] && pre[i] != '\n') i++;
            if (pre[i] == '\n') i++;
        }
    }

    cur_c = 0; cur_r = 0;
    draw_sheet();
    while (1) {
        int key = keyboard_getchar();
        if (key == -KEY_ESC) break;
        else if (key == -KEY_UP    && cur_r > 0) cur_r--;
        else if (key == -KEY_DOWN  && cur_r < SH_ROWS - 1) cur_r++;
        else if (key == -KEY_LEFT  && cur_c > 0) cur_c--;
        else if (key == -KEY_RIGHT && cur_c < SH_COLS - 1) cur_c++;
        else if (key == '\n') edit_cell();
        else if (key == -KEY_F1) {
            save_csv();
            vga_print("Saved to SHEET.CSV", vga_make_color(VGA_LIGHT_GREEN, VGA_BLACK), 30, 22);
            for (volatile int d = 0; d < 5000000; d++) { }
        }
        draw_sheet();
    }
    vga_clear(vga_make_color(VGA_LIGHT_GREY, VGA_BLACK));
}
