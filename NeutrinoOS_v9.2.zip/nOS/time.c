#include "time.h"
#include "vga.h"
#include "keyboard.h"
#include "rtc.h"
#include "bigfont.h"
#include "config.h"
#include "theme.h"
#include "utils.h"

static void draw_clock(int hh, int mm, int ss, int tz) {
    uint8_t label_fg = vga_make_color(theme_fg(3), VGA_BLACK);
    uint8_t digit_fg = vga_make_color(theme_fg(2), VGA_BLACK);
    vga_clear(vga_make_color(VGA_LIGHT_GREY, VGA_BLACK));
    vga_draw_box(2, 1, 76, 22, vga_make_color(theme_fg(1), VGA_BLACK));
    vga_print("=== GRAPHICAL TIME ===", label_fg, 30, 2);
    vga_print("(RTC + timezone offset)", vga_make_color(VGA_DARK_GREY, VGA_BLACK), 28, 3);
    char buf[16];
    itoa_pad(hh, &buf[0], 2); buf[2] = ':';
    itoa_pad(mm, &buf[3], 2); buf[5] = ':';
    itoa_pad(ss, &buf[6], 2); buf[8] = 0;
    int width = bigfont_string_width(buf);
    bigfont_draw_string(buf, (80 - width) / 2, 9, digit_fg, VGA_BLACK);
    vga_print("Current time:", label_fg, 34, 16);
    vga_print(buf, vga_make_color(VGA_YELLOW, VGA_BLACK), 35, 17);
    char tzb[8];
    if (tz >= 0) { tzb[0] = '+'; itoa(tz, &tzb[1], 10); } else itoa(tz, tzb, 10);
    vga_print("Timezone: UTC", label_fg, 34, 19);
    vga_print(tzb, vga_make_color(VGA_YELLOW, VGA_BLACK), 46, 19);
    vga_print("Press any key...", vga_make_color(VGA_DARK_GREY, VGA_BLACK), 28, 21);
}
void time_show(void) {
    config_t* cfg = config_get();
    rtc_time_t t;
    rtc_get_local(&t, cfg->tz_offset);
    int last_ss = -1, last_hh = -1, last_mm = -1;
    while (1) {
        if (keyboard_poll() != -1) { vga_clear(vga_make_color(VGA_LIGHT_GREY, VGA_BLACK)); return; }
        rtc_get_local(&t, cfg->tz_offset);
        if (t.second != last_ss || t.minute != last_mm || t.hour != last_hh) {
            last_ss = t.second; last_mm = t.minute; last_hh = t.hour;
            draw_clock(t.hour, t.minute, t.second, cfg->tz_offset);
        }
        for (volatile int d = 0; d < 3000; d++) { }
    }
}
void date_show(void) {
    config_t* cfg = config_get();
    rtc_time_t t;
    rtc_get_local(&t, cfg->tz_offset);
    uint8_t title = vga_make_color(VGA_LIGHT_CYAN, VGA_BLACK);
    uint8_t value = vga_make_color(VGA_YELLOW, VGA_BLACK);
    uint8_t border = vga_make_color(VGA_BLUE, VGA_BLACK);
    vga_draw_box(20, 8, 40, 9, border);
    vga_print("=== DATE ===", title, 35, 10);
    char buf[16];
    itoa_pad(t.day,   &buf[0], 2); buf[2] = '/';
    itoa_pad(t.month, &buf[3], 2); buf[5] = '/';
    itoa(t.year,      &buf[6], 10);
    vga_print(buf, value, 34, 12);
    int d = t.day, m = t.month, y = t.year;
    if (m < 3) { m += 12; y--; }
    int k = y % 100, j = y / 100;
    int h = (d + 13*(m+1)/5 + k + k/4 + j/4 + 5*j) % 7;
    const char* days[] = {"Saturday","Sunday","Monday","Tuesday","Wednesday","Thursday","Friday"};
    vga_print(days[h], vga_make_color(VGA_LIGHT_GREEN, VGA_BLACK), 34, 14);
    vga_print("Press any key...", vga_make_color(VGA_DARK_GREY, VGA_BLACK), 30, 16);
    keyboard_getchar();
    vga_clear(vga_make_color(VGA_LIGHT_GREY, VGA_BLACK));
}
