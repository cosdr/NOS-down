#include "vga.h"
#include "utils.h"

static uint16_t* const VGA_MEMORY = (uint16_t*) 0xB8000;
static uint8_t*  const VGA_GFX    = (uint8_t*)  0xA0000;

static int cursor_x = 0, cursor_y = 0;
static uint8_t current_color = 0x07;
static int in_gfx = 0;

static const uint8_t gfx_font[128][8] = {
    [' '] = {0,0,0,0,0,0,0,0},
    ['!'] = {0x18,0x18,0x18,0x18,0x18,0x00,0x18,0x00},
    ['.'] = {0,0,0,0,0,0,0x18,0x18},
    [':'] = {0,0x18,0x18,0,0x18,0x18,0,0},
    ['-'] = {0,0,0,0x7E,0,0,0,0},
    ['+'] = {0,0x18,0x18,0x7E,0x18,0x18,0},
    ['='] = {0,0,0x7E,0,0x7E,0,0,0},
    ['/'] = {0x03,0x06,0x0C,0x18,0x30,0x60,0xC0,0},
    ['0'] = {0x3C,0x66,0x6E,0x76,0x66,0x66,0x3C,0},
    ['1'] = {0x18,0x38,0x18,0x18,0x18,0x18,0x7E,0},
    ['2'] = {0x3C,0x66,0x06,0x0C,0x18,0x30,0x7E,0},
    ['3'] = {0x3C,0x66,0x06,0x1C,0x06,0x66,0x3C,0},
    ['4'] = {0x0C,0x1C,0x3C,0x6C,0x7E,0x0C,0x0C,0},
    ['5'] = {0x7E,0x60,0x7C,0x06,0x06,0x66,0x3C,0},
    ['6'] = {0x1C,0x30,0x60,0x7C,0x66,0x66,0x3C,0},
    ['7'] = {0x7E,0x06,0x0C,0x18,0x30,0x30,0x30,0},
    ['8'] = {0x3C,0x66,0x66,0x3C,0x66,0x66,0x3C,0},
    ['9'] = {0x3C,0x66,0x66,0x3E,0x06,0x0C,0x38,0},
    ['A'] = {0x18,0x3C,0x66,0x66,0x7E,0x66,0x66,0},
    ['B'] = {0x7C,0x66,0x66,0x7C,0x66,0x66,0x7C,0},
    ['C'] = {0x3C,0x66,0x60,0x60,0x60,0x66,0x3C,0},
    ['D'] = {0x78,0x6C,0x66,0x66,0x66,0x6C,0x78,0},
    ['E'] = {0x7E,0x60,0x60,0x7C,0x60,0x60,0x7E,0},
    ['F'] = {0x7E,0x60,0x60,0x7C,0x60,0x60,0x60,0},
    ['G'] = {0x3C,0x66,0x60,0x6E,0x66,0x66,0x3E,0},
    ['H'] = {0x66,0x66,0x66,0x7E,0x66,0x66,0x66,0},
    ['I'] = {0x7E,0x18,0x18,0x18,0x18,0x18,0x7E,0},
    ['J'] = {0x06,0x06,0x06,0x06,0x66,0x66,0x3C,0},
    ['K'] = {0x66,0x6C,0x78,0x70,0x78,0x6C,0x66,0},
    ['L'] = {0x60,0x60,0x60,0x60,0x60,0x60,0x7E,0},
    ['M'] = {0x63,0x77,0x7F,0x6B,0x63,0x63,0x63,0},
    ['N'] = {0x66,0x76,0x7E,0x7E,0x6E,0x66,0x66,0},
    ['O'] = {0x3C,0x66,0x66,0x66,0x66,0x66,0x3C,0},
    ['P'] = {0x7C,0x66,0x66,0x7C,0x60,0x60,0x60,0},
    ['Q'] = {0x3C,0x66,0x66,0x66,0x6E,0x6C,0x36,0},
    ['R'] = {0x7C,0x66,0x66,0x7C,0x6C,0x66,0x66,0},
    ['S'] = {0x3C,0x66,0x60,0x3C,0x06,0x66,0x3C,0},
    ['T'] = {0x7E,0x18,0x18,0x18,0x18,0x18,0x18,0},
    ['U'] = {0x66,0x66,0x66,0x66,0x66,0x66,0x3C,0},
    ['V'] = {0x66,0x66,0x66,0x66,0x66,0x3C,0x18,0},
    ['W'] = {0x63,0x63,0x63,0x6B,0x7F,0x77,0x63,0},
    ['X'] = {0x66,0x66,0x3C,0x18,0x3C,0x66,0x66,0},
    ['Y'] = {0x66,0x66,0x66,0x3C,0x18,0x18,0x18,0},
    ['Z'] = {0x7E,0x06,0x0C,0x18,0x30,0x60,0x7E,0},
};

void vga_init(void) { cursor_x = 0; cursor_y = 0; current_color = vga_make_color(VGA_LIGHT_GREY, VGA_BLACK); in_gfx = 0; }
uint8_t vga_make_color(uint8_t fg, uint8_t bg) { return (uint8_t)((bg << 4) | (fg & 0x0F)); }
void vga_clear(uint8_t color) {
    uint16_t entry = (uint16_t)(((uint16_t)color << 8) | ' ');
    for (int i = 0; i < VGA_WIDTH * VGA_HEIGHT; i++) VGA_MEMORY[i] = entry;
    cursor_x = 0; cursor_y = 0; current_color = color;
}
int vga_get_cursor_x(void) { return cursor_x; }
int vga_get_cursor_y(void) { return cursor_y; }
void vga_putchar(char c, uint8_t color, int x, int y) {
    if (x < 0 || x >= VGA_WIDTH || y < 0 || y >= VGA_HEIGHT) return;
    VGA_MEMORY[y * VGA_WIDTH + x] = (uint16_t)(((uint16_t)color << 8) | (uint8_t)c);
}
void vga_putcell(int x, int y, char c, uint8_t fg, uint8_t bg) { vga_putchar(c, vga_make_color(fg, bg), x, y); }
char vga_getcell(int x, int y) {
    if (x < 0 || x >= VGA_WIDTH || y < 0 || y >= VGA_HEIGHT) return ' ';
    return (char)(VGA_MEMORY[y * VGA_WIDTH + x] & 0xFF);
}
uint8_t vga_getcell_color(int x, int y) {
    if (x < 0 || x >= VGA_WIDTH || y < 0 || y >= VGA_HEIGHT) return 0;
    return (uint8_t)(VGA_MEMORY[y * VGA_WIDTH + x] >> 8);
}
void vga_putchar_at(char c, uint8_t color) {
    if (c == '\n') { vga_newline(); return; }
    if (c == '\r') { cursor_x = 0; return; }
    if (c == '\b') { if (cursor_x > 0) cursor_x--; return; }
    if (c == '\t') { cursor_x = (cursor_x + 4) & ~3; if (cursor_x >= VGA_WIDTH) vga_newline(); return; }
    vga_putchar(c, color, cursor_x, cursor_y);
    cursor_x++;
    if (cursor_x >= VGA_WIDTH) vga_newline();
}
void vga_print(const char* str, uint8_t color, int x, int y) {
    int i = 0;
    while (str[i]) {
        if (x >= VGA_WIDTH) { x = 0; y++; }
        if (y >= VGA_HEIGHT) break;
        vga_putchar(str[i], color, x, y);
        x++; i++;
    }
}
void vga_print_at(const char* str, uint8_t color) { while (*str) { vga_putchar_at(*str, color); str++; } }
void vga_scroll(void) {
    for (int y = 1; y < VGA_HEIGHT; y++)
        for (int x = 0; x < VGA_WIDTH; x++)
            VGA_MEMORY[(y - 1) * VGA_WIDTH + x] = VGA_MEMORY[y * VGA_WIDTH + x];
    uint16_t blank = (uint16_t)(((uint16_t)current_color << 8) | ' ');
    for (int x = 0; x < VGA_WIDTH; x++)
        VGA_MEMORY[(VGA_HEIGHT - 1) * VGA_WIDTH + x] = blank;
}
void vga_newline(void) {
    cursor_x = 0; cursor_y++;
    if (cursor_y >= VGA_HEIGHT) { vga_scroll(); cursor_y = VGA_HEIGHT - 1; }
}
void vga_set_cursor(int x, int y) {
    if (x >= 0 && x < VGA_WIDTH) cursor_x = x;
    if (y >= 0 && y < VGA_HEIGHT) cursor_y = y;
}
void vga_get_cursor(int* x, int* y) { *x = cursor_x; *y = cursor_y; }
void vga_draw_box(int x, int y, int w, int h, uint8_t color) {
    vga_putchar(201, color, x, y);
    vga_putchar(187, color, x + w - 1, y);
    vga_putchar(200, color, x, y + h - 1);
    vga_putchar(188, color, x + w - 1, y + h - 1);
    for (int i = 1; i < w - 1; i++) {
        vga_putchar(205, color, x + i, y);
        vga_putchar(205, color, x + i, y + h - 1);
    }
    for (int i = 1; i < h - 1; i++) {
        vga_putchar(186, color, x, y + i);
        vga_putchar(186, color, x + w - 1, y + i);
    }
}
void vga_draw_box_single(int x, int y, int w, int h, uint8_t color) {
    vga_putchar(218, color, x, y);
    vga_putchar(191, color, x + w - 1, y);
    vga_putchar(192, color, x, y + h - 1);
    vga_putchar(217, color, x + w - 1, y + h - 1);
    for (int i = 1; i < w - 1; i++) {
        vga_putchar(196, color, x + i, y);
        vga_putchar(196, color, x + i, y + h - 1);
    }
    for (int i = 1; i < h - 1; i++) {
        vga_putchar(179, color, x, y + i);
        vga_putchar(179, color, x + w - 1, y + i);
    }
}
void vga_draw_shadow(int x, int y, int w, int h, uint8_t color) {
    for (int i = 0; i < w; i++) vga_putchar(219, color, x + i + 1, y + h);
    for (int i = 0; i < h; i++) vga_putchar(219, color, x + w, y + i + 1);
}
void vga_fill(int x, int y, int w, int h, char ch, uint8_t color) {
    for (int j = 0; j < h; j++)
        for (int i = 0; i < w; i++)
            vga_putchar(ch, color, x + i, y + j);
}
void vga_fill_bg(int x, int y, int w, int h, char ch, uint8_t fg, uint8_t bg) {
    uint8_t color = vga_make_color(fg, bg);
    for (int j = 0; j < h; j++)
        for (int i = 0; i < w; i++)
            vga_putchar(ch, color, x + i, y + j);
}

static const uint8_t mode13_regs[] = {
    0x63, 0x00,0x03,0x01,0x0F,0x00,0x0E,
    0x5F,0x4F,0x50,0x82,0x54,0x80,0xBF,0x1F,0x00,0x41,0x00,0x00,0x00,0x00,0x00,0x00,0x9C,0x0E,0x8F,0x28,0x40,0x96,0xB9,0xA3,0xFF,
    0x00,0x00,0x00,0x00,0x00,0x40,0x05,0x0F,0xFF,
    0x00,0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x0A,0x0B,0x0C,0x0D,0x0E,0x0F,0x41,0x00,0x0F,0x00,0x00
};
static const uint8_t text_regs[] = {
    0x67, 0x03,0x00,0x03,0x00,0x02,
    0x5F,0x4F,0x50,0x82,0x55,0x81,0xBF,0x1F,0x00,0x4F,0x0D,0x0E,0x00,0x00,0x00,0x00,0x9C,0x0E,0x8F,0x28,0x1F,0x96,0xB9,0xA3,0xFF,
    0x00,0x00,0x10,0x0E,0x00,0x00,0x00,0x00,0xFF,
    0x00,0x01,0x02,0x03,0x04,0x05,0x14,0x07,0x38,0x39,0x3A,0x3B,0x3C,0x3D,0x3E,0x3F,0x0C,0x00,0x0F,0x08,0x00
};

static void write_regs(const uint8_t* regs) {
    outb(0x3C2, *regs++);
    for (int i = 0; i < 5; i++) { outb(0x3C4, (uint8_t)i); outb(0x3C5, *regs++); }
    outb(0x3D4, 0x11); outb(0x3D5, inb(0x3D5) & 0x7F);
    for (int i = 0; i < 25; i++) { outb(0x3D4, (uint8_t)i); outb(0x3D5, *regs++); }
    for (int i = 0; i < 9; i++) { outb(0x3CE, (uint8_t)i); outb(0x3CF, *regs++); }
    for (int i = 0; i < 21; i++) { (void)inb(0x3DA); outb(0x3C0, (uint8_t)i); outb(0x3C0, *regs++); }
    (void)inb(0x3DA);
    outb(0x3C0, 0x20);
}

int gfx_enter_mode13(void) { write_regs(mode13_regs); in_gfx = 1; return 0; }
void gfx_leave_mode13(void) { write_regs(text_regs); in_gfx = 0; vga_clear(vga_make_color(VGA_LIGHT_GREY, VGA_BLACK)); }
int gfx_in_mode13(void) { return in_gfx; }

void gfx_putpixel(int x, int y, uint8_t color) {
    if (x < 0 || x >= 320 || y < 0 || y >= 200) return;
    VGA_GFX[y * 320 + x] = color;
}
uint8_t gfx_getpixel(int x, int y) {
    if (x < 0 || x >= 320 || y < 0 || y >= 200) return 0;
    return VGA_GFX[y * 320 + x];
}
void gfx_clear(uint8_t color) { for (int i = 0; i < 320 * 200; i++) VGA_GFX[i] = color; }
void gfx_hline(int x, int y, int len, uint8_t color) { for (int i = 0; i < len; i++) gfx_putpixel(x + i, y, color); }
void gfx_vline(int x, int y, int len, uint8_t color) { for (int i = 0; i < len; i++) gfx_putpixel(x, y + i, color); }
void gfx_rect(int x, int y, int w, int h, uint8_t color) {
    gfx_hline(x, y, w, color); gfx_hline(x, y + h - 1, w, color);
    gfx_vline(x, y, h, color); gfx_vline(x + w - 1, y, h, color);
}
void gfx_fillrect(int x, int y, int w, int h, uint8_t color) {
    for (int j = 0; j < h; j++) for (int i = 0; i < w; i++) gfx_putpixel(x + i, y + j, color);
}
void gfx_line(int x0, int y0, int x1, int y1, uint8_t color) {
    int dx = x1 - x0, dy = y1 - y0;
    int sx = dx > 0 ? 1 : -1, sy = dy > 0 ? 1 : -1;
    if (dx < 0) dx = -dx;
    if (dy < 0) dy = -dy;
    int err = dx - dy;
    while (1) {
        gfx_putpixel(x0, y0, color);
        if (x0 == x1 && y0 == y1) break;
        int e2 = 2 * err;
        if (e2 > -dy) { err -= dy; x0 += sx; }
        if (e2 < dx)  { err += dx; y0 += sy; }
    }
}
void gfx_drawchar(int x, int y, char c, uint8_t color) {
    if ((unsigned char)c >= 128) return;
    const uint8_t* glyph = gfx_font[(unsigned char)c];
    for (int row = 0; row < 8; row++) {
        uint8_t bits = glyph[row];
        for (int col = 0; col < 8; col++) if (bits & (0x80 >> col)) gfx_putpixel(x + col, y + row, color);
    }
}
void gfx_drawtext(int x, int y, const char* s, uint8_t color) {
    while (*s) { gfx_drawchar(x, y, *s, color); x += 8; s++; }
}
