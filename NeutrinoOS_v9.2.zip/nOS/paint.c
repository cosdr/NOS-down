#include "paint.h"
#include "vga.h"
#include "keyboard.h"
#include "ramdisk.h"
#include "utils.h"

#define PAINT_WIDTH  64
#define PAINT_HEIGHT 20
#define PAINT_X0     8
#define PAINT_Y0     2

static char canvas[PAINT_HEIGHT][PAINT_WIDTH];
static uint8_t canvas_color[PAINT_HEIGHT][PAINT_WIDTH];
static int cur_x = 0, cur_y = 0;
static int brush_idx = 4, color_idx = 14;

static const char brushes[] = { ' ', CH_LIGHT_SHADE, CH_MED_SHADE, CH_DARK_SHADE,
                                CH_FULL_BLOCK, CH_UPPER_HALF, CH_LOWER_HALF, CH_LEFT_HALF };
static const uint8_t qwerty_colors[10] = {
    VGA_WHITE, VGA_YELLOW, VGA_LIGHT_GREEN, VGA_LIGHT_CYAN, VGA_LIGHT_BLUE,
    VGA_LIGHT_MAGENTA, VGA_LIGHT_RED, VGA_BROWN, VGA_GREEN, VGA_DARK_GREY
};
static const char* color_names[16] = {
    "BLK","BLU","GRN","CYN","RED","MAG","BRN","LGY","DGY","LBL","LGR","LCY","LRD","LMG","YEL","WHT"
};
static void redraw_canvas(void) {
    for (int y = 0; y < PAINT_HEIGHT; y++)
        for (int x = 0; x < PAINT_WIDTH; x++)
            vga_putcell(PAINT_X0 + x, PAINT_Y0 + y, canvas[y][x], canvas_color[y][x], VGA_BLACK);
}
static void redraw_ui(void) {
    uint8_t ui_fg   = vga_make_color(VGA_LIGHT_CYAN, VGA_BLACK);
    uint8_t hint_fg = vga_make_color(VGA_DARK_GREY, VGA_BLACK);
    vga_fill(PAINT_X0, PAINT_Y0 + PAINT_HEIGHT + 1, PAINT_WIDTH, 2, ' ', ui_fg);
    vga_print("Brush:[", ui_fg, PAINT_X0, PAINT_Y0 + PAINT_HEIGHT + 1);
    vga_putcell(PAINT_X0 + 7, PAINT_Y0 + PAINT_HEIGHT + 1, brushes[brush_idx], ui_fg, VGA_BLACK);
    vga_print("] Colour:", ui_fg, PAINT_X0 + 9, PAINT_Y0 + PAINT_HEIGHT + 1);
    uint8_t c = vga_make_color((uint8_t)color_idx, VGA_BLACK);
    vga_print(color_names[color_idx], c, PAINT_X0 + 23, PAINT_Y0 + PAINT_HEIGHT + 1);
    vga_print("Arrows SPC BKSP 1-8 QWERTY C S ESC", hint_fg, PAINT_X0, PAINT_Y0 + PAINT_HEIGHT + 2);
}
void paint_run(void) {
    for (int y = 0; y < PAINT_HEIGHT; y++)
        for (int x = 0; x < PAINT_WIDTH; x++) { canvas[y][x] = ' '; canvas_color[y][x] = VGA_WHITE; }
    cur_x = 0; cur_y = 0;
    vga_clear(vga_make_color(VGA_LIGHT_GREY, VGA_BLACK));
    vga_draw_box(PAINT_X0 - 1, PAINT_Y0 - 1, PAINT_WIDTH + 2, PAINT_HEIGHT + 2, vga_make_color(VGA_BLUE, VGA_BLACK));
    redraw_canvas();
    redraw_ui();
    while (1) {
        vga_putcell(PAINT_X0 + cur_x, PAINT_Y0 + cur_y, canvas[cur_y][cur_x], VGA_YELLOW, VGA_DARK_GREY);
        int key = keyboard_getchar();
        if (key == -KEY_ESC) break;
        else if (key == -KEY_UP && cur_y > 0) cur_y--;
        else if (key == -KEY_DOWN && cur_y < PAINT_HEIGHT - 1) cur_y++;
        else if (key == -KEY_LEFT && cur_x > 0) cur_x--;
        else if (key == -KEY_RIGHT && cur_x < PAINT_WIDTH - 1) cur_x++;
        else if (key == ' ') { canvas[cur_y][cur_x] = brushes[brush_idx]; canvas_color[cur_y][cur_x] = (uint8_t)color_idx; }
        else if (key == '\b') canvas[cur_y][cur_x] = ' ';
        else if (key >= '1' && key <= '8') { brush_idx = key - '1'; redraw_ui(); }
        else if (key == 'q' || key == 'Q') { color_idx = qwerty_colors[0]; redraw_ui(); }
        else if (key == 'w' || key == 'W') { color_idx = qwerty_colors[1]; redraw_ui(); }
        else if (key == 'e' || key == 'E') { color_idx = qwerty_colors[2]; redraw_ui(); }
        else if (key == 'r' || key == 'R') { color_idx = qwerty_colors[3]; redraw_ui(); }
        else if (key == 't' || key == 'T') { color_idx = qwerty_colors[4]; redraw_ui(); }
        else if (key == 'y' || key == 'Y') { color_idx = qwerty_colors[5]; redraw_ui(); }
        else if (key == 'u' || key == 'U') { color_idx = qwerty_colors[6]; redraw_ui(); }
        else if (key == 'i' || key == 'I') { color_idx = qwerty_colors[7]; redraw_ui(); }
        else if (key == 'o' || key == 'O') { color_idx = qwerty_colors[8]; redraw_ui(); }
        else if (key == 'p' || key == 'P') { color_idx = qwerty_colors[9]; redraw_ui(); }
        else if (key == 'c' || key == 'C') {
            for (int y = 0; y < PAINT_HEIGHT; y++)
                for (int x = 0; x < PAINT_WIDTH; x++) canvas[y][x] = ' ';
        }
        else if (key == 's' || key == 'S') {
            char buf[2048]; int pos = 0;
            for (int y = 0; y < PAINT_HEIGHT; y++) {
                for (int x = 0; x < PAINT_WIDTH; x++) buf[pos++] = canvas[y][x];
                buf[pos++] = '\n';
            }
            buf[pos] = 0;
            int fd = ramdisk_create("PAINT.TXT");
            if (fd >= 0) ramdisk_write(fd, buf, pos);
        }
        redraw_canvas();
    }
    vga_clear(vga_make_color(VGA_LIGHT_GREY, VGA_BLACK));
}
