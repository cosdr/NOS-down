#include "settings.h"
#include "vga.h"
#include "keyboard.h"
#include "config.h"
#include "screensaver.h"
#include "palette.h"
#include "pcspk.h"
#include "utils.h"

static int read_field(int x, int y, int max_w, char* out, int max, int mask) {
    uint8_t fg = vga_make_color(VGA_BLACK, VGA_LIGHT_GREY);
    for (int i = 0; i < max_w; i++) vga_putchar('_', fg, x + i, y);
    int pos = 0, cx = x;
    for (;;) {
        vga_putchar(219, fg, cx, y);
        int k = keyboard_getchar();
        vga_putchar('_', fg, cx, y);
        if (k == '\n') { out[pos] = 0; return pos; }
        if (k == -KEY_ESC) { out[0] = 0; return -1; }
        if (k == '\b' && pos > 0) { pos--; cx--; vga_putchar('_', fg, cx, y); }
        else if (k > 0 && k < 128 && pos < max - 1 && cx < x + max_w - 1) {
            out[pos++] = (char)k;
            vga_putchar(mask ? '*' : (char)k, fg, cx, y);
            cx++;
        }
    }
}

static void draw_menu(int sel) {
    uint8_t title_fg  = vga_make_color(VGA_LIGHT_CYAN, VGA_BLACK);
    uint8_t normal_fg = vga_make_color(VGA_LIGHT_GREY, VGA_BLACK);
    uint8_t sel_fg    = vga_make_color(VGA_BLACK, VGA_LIGHT_CYAN);
    uint8_t hint_fg   = vga_make_color(VGA_DARK_GREY, VGA_BLACK);

    vga_clear(vga_make_color(VGA_BLACK, VGA_BLACK));
    vga_draw_box(2, 1, 76, 22, vga_make_color(VGA_BLUE, VGA_BLACK));
    vga_print("=== SETTINGS ===", title_fg, 32, 2);
    vga_print("UP/DOWN select   ENTER edit   ESC exit", hint_fg, 21, 3);

    const char* items[] = {
        "Username",
        "Password",
        "Superuser ($root) password",
        "Autologin on boot",
        "Shell prompt template",
        "Screensaver default",
        "Screensaver idle delay",
        "Video mode",
        "Theme",
        "Slow boot",
    };
    for (int i = 0; i < 10; i++) {
        int row = 5 + i;
        if (i == sel) for (int x = 3; x < 77; x++) vga_putcell(x, row, ' ', VGA_BLACK, VGA_LIGHT_CYAN);
        uint8_t c = (i == sel) ? sel_fg : normal_fg;
        vga_print(items[i], c, 4, row);
    }
}
static void edit_username(void) {
    config_t* cfg = config_get();
    uint8_t fg = vga_make_color(VGA_LIGHT_CYAN, VGA_BLACK);
    vga_print("New username:", fg, 4, 18);
    read_field(20, 18, 40, cfg->username, sizeof(cfg->username), 0);
    config_save_user();
}
static void edit_password(void) {
    config_t* cfg = config_get();
    uint8_t fg = vga_make_color(VGA_LIGHT_CYAN, VGA_BLACK);
    vga_print("New password:", fg, 4, 18);
    read_field(20, 18, 40, cfg->password, sizeof(cfg->password), 1);
    config_save_user();
}
static void edit_su(void) {
    config_t* cfg = config_get();
    uint8_t fg = vga_make_color(VGA_LIGHT_CYAN, VGA_BLACK);
    vga_print("New root password:", fg, 4, 18);
    read_field(25, 18, 35, cfg->su_password, sizeof(cfg->su_password), 1);
    config_save_user();
}
static void toggle_autologin(void) {
    config_t* cfg = config_get();
    cfg->autologin = !cfg->autologin;
    config_save_autologin();
}
static void edit_prompt(void) {
    config_t* cfg = config_get();
    uint8_t fg = vga_make_color(VGA_LIGHT_CYAN, VGA_BLACK);
    vga_print("Prompt template (%u=user, %h=host):", fg, 4, 17);
    vga_print("Example: %u@neutrino> ", fg, 4, 18);
    read_field(4, 19, 70, cfg->prompt, sizeof(cfg->prompt), 0);
    config_save_prompt();
}
static void edit_saver(void) {
    config_t* cfg = config_get();
    uint8_t fg = vga_make_color(VGA_LIGHT_CYAN, VGA_BLACK);
    vga_print("Screensaver: 0=off  1=starfield  2=matrix  3=bounce  4=pipes",
              fg, 4, 18);
    char t[4];
    read_field(4, 19, 3, t, sizeof(t), 0);
    cfg->screensaver = atoi(t);
    config_save_screensaver();
}
static void edit_saver_delay(void) {
    config_t* cfg = config_get();
    uint8_t fg = vga_make_color(VGA_LIGHT_CYAN, VGA_BLACK);
    vga_print("Idle seconds before screensaver:", fg, 4, 18);
    char t[8];
    read_field(37, 18, 6, t, sizeof(t), 0);
    cfg->saver_delay = atoi(t);
    config_save_screensaver();
}
static void edit_videomode(void) {
    config_t* cfg = config_get();
    uint8_t fg = vga_make_color(VGA_LIGHT_CYAN, VGA_BLACK);
    vga_print("0 = VGA AmTREND (C) 16",  fg, 4, 17);
    vga_print("1 = VGA NVID (R) 256",    fg, 4, 18);
    vga_print("2 = VGA MikSoft (C) 128", fg, 4, 19);
    char t[4];
    read_field(4, 21, 3, t, sizeof(t), 0);
    cfg->videomode = atoi(t);
    config_save_videomode();
}
static void edit_theme(void) {
    config_t* cfg = config_get();
    uint8_t fg = vga_make_color(VGA_LIGHT_CYAN, VGA_BLACK);
    for (int i = 0; i < palette_theme_count(); i++) {
        char line[32]; int p = 0;
        itoa(i, &line[p], 10); p += strlen(&line[p]);
        line[p++] = ' '; line[p++] = '='; line[p++] = ' ';
        const char* nm = palette_theme_name(i);
        while (*nm && p < 31) line[p++] = *nm++;
        line[p] = 0;
        vga_print(line, fg, 4, 15 + i);
    }
    char t[4];
    read_field(4, 22, 3, t, sizeof(t), 0);
    int id = atoi(t);
    if (id >= 0 && id < palette_theme_count()) {
        cfg->theme_id = id;
        palette_apply_theme(id);
        config_save_theme();
    }
}
static void toggle_slowboot(void) {
    config_t* cfg = config_get();
    cfg->slowboot = !cfg->slowboot;
    config_save_slowboot();
}
void settings_run(void) {
    int sel = 0;
    while (1) {
        draw_menu(sel);
        int key = keyboard_getchar();
        if (key == -KEY_ESC) break;
        else if (key == -KEY_UP   && sel > 0) sel--;
        else if (key == -KEY_DOWN && sel < 9) sel++;
        else if (key == '\n') {
            switch (sel) {
                case 0: edit_username(); break;
                case 1: edit_password(); break;
                case 2: edit_su(); break;
                case 3: toggle_autologin(); break;
                case 4: edit_prompt(); break;
                case 5: edit_saver(); break;
                case 6: edit_saver_delay(); break;
                case 7: edit_videomode(); break;
                case 8: edit_theme(); break;
                case 9: toggle_slowboot(); break;
            }
            pcspk_click();
        }
    }
    vga_clear(vga_make_color(VGA_LIGHT_GREY, VGA_BLACK));
}
