#ifndef SHELL_H
#define SHELL_H

void shell_run(void);
void shell_execute_line(const char* line);

#endif
