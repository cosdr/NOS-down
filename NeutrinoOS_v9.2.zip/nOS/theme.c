#include "theme.h"
#include "vga.h"
#include "keyboard.h"
#include "config.h"
#include "palette.h"
#include "pcspk.h"
#include "utils.h"

void theme_run(void) {
    config_t* cfg = config_get();
    int saved = cfg->theme_id;
    int sel = cfg->theme_id;
    int n = palette_theme_count();
    while (1) {
        vga_clear(vga_make_color(VGA_LIGHT_GREY, VGA_BLACK));
        vga_draw_box(2, 1, 76, 22, vga_make_color(VGA_BLUE, VGA_BLACK));
        vga_print("=== THEME SELECTOR ===", vga_make_color(VGA_LIGHT_CYAN, VGA_BLACK), 28, 2);
        vga_print("UP/DOWN select  ENTER apply  ESC cancel",
                  vga_make_color(VGA_DARK_GREY, VGA_BLACK), 20, 3);
        for (int i = 0; i < n && i < 16; i++) {
            int row = 6 + i;
            int is_sel = (i == sel);
            uint8_t bg = is_sel ? VGA_BLUE : VGA_BLACK;
            uint8_t fg = is_sel ? VGA_WHITE : VGA_LIGHT_GREY;
            vga_putcell(4, row, is_sel ? '>' : ' ', fg, bg);
            char idxb[8]; itoa(i, idxb, 10);
            vga_print(idxb, fg, 6, row);
            vga_print(":", fg, 8, row);
            vga_print(palette_theme_name(i), fg, 10, row);
            for (int k = 0; k < 8; k++) vga_putcell(40 + k * 2, row, CH_FULL_BLOCK, (uint8_t)(k * 2), 0);
        }
        vga_print("Current:", vga_make_color(VGA_YELLOW, VGA_BLACK), 4, 22);
        vga_print(palette_theme_name(cfg->theme_id), vga_make_color(VGA_WHITE, VGA_BLACK), 13, 22);
        int key = keyboard_getchar();
        if (key == -KEY_UP && sel > 0) sel--;
        else if (key == -KEY_DOWN && sel < n - 1) sel++;
        else if (key == '\n') { cfg->theme_id = sel; palette_apply_theme(sel); config_save_theme(); pcspk_click(); break; }
        else if (key == -KEY_ESC) { cfg->theme_id = saved; palette_apply_theme(saved); break; }
    }
    vga_clear(vga_make_color(VGA_LIGHT_GREY, VGA_BLACK));
}
uint8_t theme_fg(int palette_idx) {
    config_t* cfg = config_get();
    if (palette_idx < 0 || palette_idx >= 16) return VGA_LIGHT_GREY;
    return cfg->theme[palette_idx];
}
uint8_t theme_bg(int palette_idx) {
    config_t* cfg = config_get();
    if (palette_idx < 0 || palette_idx >= 16) return VGA_BLACK;
    return cfg->theme[palette_idx];
}
