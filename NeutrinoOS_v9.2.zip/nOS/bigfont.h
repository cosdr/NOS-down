#ifndef BIGFONT_H
#define BIGFONT_H

#include "stdint.h"

void bigfont_draw_digit(int digit, int x, int y, uint8_t fg, uint8_t bg);
void bigfont_draw_string(const char* str, int x, int y, uint8_t fg, uint8_t bg);
int  bigfont_string_width(const char* str);

#endif
