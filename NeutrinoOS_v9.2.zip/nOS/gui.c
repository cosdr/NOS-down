/* NeutrinoOS v0.9.2 — Win95-style GUI with pseudo-mouse
 * Arrows move cursor, [ = left click, ] = right click
 * Alt+Del toggles Start menu
 */
#include "gui.h"
#include "vga.h"
#include "keyboard.h"
#include "mouse.h"
#include "wm.h"
#include "rtc.h"
#include "config.h"
#include "pcspk.h"
#include "power.h"
#include "utils.h"
#include "fte.h"
#include "wrd.h"
#include "chart.h"
#include "sheet.h"
#include "mandel.h"
#include "paint.h"
#include "settings.h"
#include "theme.h"
#include "fetch.h"

/* ---------- Layout ---------- */
#define DESKTOP_BG   VGA_CYAN
#define DESKTOP_FG   VGA_BLACK
#define TASKBAR_Y    24

#define MENU_X 0
#define MENU_Y 14
#define MENU_W 22
#define MENU_H 10
#define SUBMENU_W 24

/* ---------- Menu data ---------- */
static const char* menu_items[MENU_H] = {
    "Programs",
    "Settings",
    "Find",
    "Help",
    "Run...",
    "About",
    "",
    "Shut Down",
    0, 0
};
#define MENU_COUNT 8

static const char* prog_items[] = {
    "FTE Editor",
    "WRD Processor",
    "Calculator",
    "Chart",
    "MikroSheet",
    "Mandelbrot",
    "Clock",
    "Paint",
};
#define PROG_COUNT 8

static const char* settings_items[] = {
    "Settings",
    "Theme",
    "System Info",
    "About",
};
#define SETTINGS_COUNT 4

/* ---------- State ---------- */
static int menu_open = 0;
static int menu_sel = 0;
static int submenu_open = 0;
static int submenu_sel = 0;
static int submenu_kind = 0;   /* 1 = programs, 2 = settings */
static int calc_window = -1;
static int about_window = -1;
static int clock_window = -1;

/* Calculator state */
static int  calc_acc = 0;
static int  calc_cur = 0;
static char calc_op = 0;
static int  calc_fresh = 1;
static char calc_display[24] = "0";

static void calc_clear(void) {
    calc_acc = 0; calc_cur = 0; calc_op = 0; calc_fresh = 1;
    calc_display[0] = '0'; calc_display[1] = 0;
}

static void calc_digit(int d) {
    if (calc_fresh) { calc_cur = 0; calc_fresh = 0; }
    if (calc_cur < 100000000)
        calc_cur = calc_cur * 10 + d;
    itoa(calc_cur, calc_display, 10);
}

static void calc_apply(void) {
    if (calc_op == '+')      calc_acc += calc_cur;
    else if (calc_op == '-') calc_acc -= calc_cur;
    else if (calc_op == '*') calc_acc *= calc_cur;
    else if (calc_op == '/') calc_acc = (calc_cur != 0) ? (calc_acc / calc_cur) : 0;
    else                     calc_acc = calc_cur;
    calc_cur = 0;
    itoa(calc_acc, calc_display, 10);
    calc_fresh = 1;
    calc_op = 0;
}

static void calc_setop(char op) {
    calc_apply();
    calc_op = op;
    calc_fresh = 1;
}

/* ---------- Window content drawers ---------- */
static void draw_about(int id, int x, int y, int w, int h) {
    uint8_t fg = vga_make_color(VGA_BLACK, VGA_LIGHT_GREY);
    uint8_t hi = vga_make_color(VGA_LIGHT_CYAN, VGA_LIGHT_GREY);
    vga_print("NeutrinoOS v0.9.2", hi, x + 2, y + 1);
    vga_print("Mikelsoft Corporation INC.", fg, x + 2, y + 2);
    vga_print("", fg, x + 2, y + 3);
    vga_print("\"Light as a neutrino,", fg, x + 2, y + 4);
    vga_print(" fast as light.\"", fg, x + 2, y + 5);
    vga_print("", fg, x + 2, y + 6);
    vga_print("Kernel: C + NASM", fg, x + 2, y + 7);
    vga_print("GUI: Win95-style v0.9.2", fg, x + 2, y + 8);
    vga_print("Pseudo-mouse: [ = LKM  ] = PKM", fg, x + 2, y + 9);
    if (h > 11) vga_print("Click [X] to close", fg, x + 2, y + 11);
    (void)id; (void)w;
}

static void draw_calc(int id, int x, int y, int w, int h) {
    uint8_t disp_fg = vga_make_color(VGA_LIGHT_GREEN, VGA_BLACK);
    uint8_t btn_fg  = vga_make_color(VGA_BLACK, VGA_WHITE);
    uint8_t hint    = vga_make_color(VGA_DARK_GREY, VGA_LIGHT_GREY);

    /* Display */
    for (int i = 0; i < w; i++) vga_putcell(x + i, y, ' ', disp_fg, VGA_BLACK);
    int dl = strlen(calc_display);
    vga_print(calc_display, disp_fg, x + w - dl - 1, y);

    /* Button grid 4x4 */
    const char* btns[4][4] = {
        {"7", "8", "9", "/"},
        {"4", "5", "6", "*"},
        {"1", "2", "3", "-"},
        {"0", "C", "=", "+"},
    };
    for (int r = 0; r < 4; r++) {
        for (int c = 0; c < 4; c++) {
            int bx = x + c * 5;
            int by = y + 2 + r * 2;
            if (bx + 4 > x + w) continue;
            if (by >= y + h) continue;
            for (int i = 0; i < 4; i++)
                vga_putcell(bx + i, by, ' ', btn_fg, VGA_WHITE);
            vga_putcell(bx + 1, by, btns[r][c][0], btn_fg, VGA_WHITE);
        }
    }
    if (h > 11)
        vga_print("Use [ to click or type", hint, x + 1, y + h - 1);
    (void)id;
}

static void draw_clock_w(int id, int x, int y, int w, int h) {
    config_t* cfg = config_get();
    rtc_time_t t;
    rtc_get_local(&t, cfg->tz_offset);

    uint8_t hi  = vga_make_color(VGA_LIGHT_CYAN, VGA_LIGHT_GREY);
    uint8_t dim = vga_make_color(VGA_BLACK, VGA_LIGHT_GREY);

    char buf[16];
    int p = 0;
    itoa_pad(t.hour, &buf[p], 2); p += 2;
    buf[p++] = ':';
    itoa_pad(t.minute, &buf[p], 2); p += 2;
    buf[p++] = ':';
    itoa_pad(t.second, &buf[p], 2); p += 2;
    buf[p] = 0;
    for (int i = 0; i < w; i++) vga_putcell(x + i, y + 1, ' ', hi, VGA_LIGHT_GREY);
    int cx = x + (w - p) / 2;
    vga_print(buf, hi, cx, y + 1);

    char dbuf[16];
    int q = 0;
    itoa_pad(t.day, &dbuf[q], 2); q += 2;
    dbuf[q++] = '.';
    itoa_pad(t.month, &dbuf[q], 2); q += 2;
    dbuf[q++] = '.';
    itoa(t.year, &dbuf[q], 10);
    vga_print(dbuf, dim, x + (w - strlen(dbuf)) / 2, y + 3);
    (void)id; (void)h;
}

/* ---------- Menu rendering ---------- */
static void draw_menu_row(int x, int y, int w, const char* text, int selected) {
    uint8_t fg = selected ? vga_make_color(VGA_WHITE, VGA_BLUE)
                          : vga_make_color(VGA_BLACK, VGA_LIGHT_GREY);
    uint8_t bg = selected ? VGA_BLUE : VGA_LIGHT_GREY;
    for (int i = 1; i < w - 1; i++) vga_putcell(x + i, y, ' ', fg, bg);
    vga_print(text, fg, x + 2, y);
    if (strcmp(text, "Programs") == 0 || strcmp(text, "Settings") == 0)
        vga_putcell(x + w - 2, y, '>', fg, bg);
}

static void draw_start_menu(void) {
    uint8_t fg     = vga_make_color(VGA_BLACK, VGA_LIGHT_GREY);
    uint8_t border = vga_make_color(VGA_WHITE, VGA_LIGHT_GREY);
    uint8_t side   = vga_make_color(VGA_WHITE, VGA_BLUE);

    /* Background */
    for (int j = 0; j < MENU_H; j++)
        for (int i = 0; i < MENU_W; i++)
            vga_putcell(MENU_X + i, MENU_Y + j, ' ', fg, VGA_LIGHT_GREY);

    /* Sidebar */
    for (int j = 1; j < MENU_H - 1; j++) {
        vga_putcell(MENU_X + 1, MENU_Y + j, ' ', side, VGA_BLUE);
        vga_putcell(MENU_X + 2, MENU_Y + j, ' ', side, VGA_BLUE);
    }

    /* Border */
    vga_draw_box_single(MENU_X, MENU_Y, MENU_W, MENU_H, border);

    /* Items */
    for (int i = 0; i < MENU_COUNT; i++) {
        if (menu_items[i][0] == 0) {
            for (int k = 3; k < MENU_W - 1; k++)
                vga_putcell(MENU_X + k, MENU_Y + 1 + i, 0xC4,
                            vga_make_color(VGA_DARK_GREY, VGA_LIGHT_GREY), VGA_LIGHT_GREY);
            continue;
        }
        draw_menu_row(MENU_X + 2, MENU_Y + 1 + i, MENU_W - 2,
                      menu_items[i], i == menu_sel);
    }

    /* Submenu */
    if (submenu_open) {
        const char** items = (submenu_kind == 1) ? prog_items : settings_items;
        int count = (submenu_kind == 1) ? PROG_COUNT : SETTINGS_COUNT;
        int sx = MENU_X + MENU_W - 1;
        int sy = MENU_Y + 1 + menu_sel;
        int sh = count + 2;
        if (sy + sh > 24) sy = 24 - sh;
        if (sy < 0) sy = 0;
        for (int j = 0; j < sh; j++)
            for (int i = 0; i < SUBMENU_W; i++)
                if (sx + i < VGA_WIDTH)
                    vga_putcell(sx + i, sy + j, ' ', fg, VGA_LIGHT_GREY);
        vga_draw_box_single(sx, sy, SUBMENU_W, sh, border);
        for (int i = 0; i < count; i++) {
            if (sy + 1 + i >= 24) break;
            draw_menu_row(sx + 1, sy + 1 + i, SUBMENU_W - 1,
                          items[i], i == submenu_sel);
        }
    }
}

static void draw_taskbar(void) {
    uint8_t fg     = vga_make_color(VGA_BLACK, VGA_LIGHT_GREY);
    uint8_t btn_fg = vga_make_color(VGA_BLACK, VGA_WHITE);

    for (int x = 0; x < VGA_WIDTH; x++)
        vga_putcell(x, TASKBAR_Y, ' ', fg, VGA_LIGHT_GREY);

    /* Start button */
    uint8_t sb = menu_open ? vga_make_color(VGA_BLACK, VGA_DARK_GREY) : btn_fg;
    vga_print(" Start ", sb, 1, TASKBAR_Y);

    /* Window buttons */
    int bx = 9;
    for (int i = 0; i < WM_MAX_WINDOWS; i++) {
        wm_window_t* w = wm_get(i);
        if (!w || !w->used) continue;
        char buf[24]; int p = 0;
        buf[p++] = ' ';
        int tlen = strlen(w->title);
        if (tlen > 10) tlen = 10;
        for (int j = 0; j < tlen; j++) buf[p++] = w->title[j];
        buf[p++] = ' '; buf[p] = 0;
        uint8_t c = (wm_focused() == i) ? vga_make_color(VGA_WHITE, VGA_BLUE) : btn_fg;
        if (bx + p < 70) {
            vga_print(buf, c, bx, TASKBAR_Y);
            bx += p + 1;
        }
    }

    /* Clock */
    config_t* cfg = config_get();
    rtc_time_t t;
    rtc_get_local(&t, cfg->tz_offset);
    char tb[8];
    itoa_pad(t.hour, tb, 2); tb[2] = ':';
    itoa_pad(t.minute, &tb[3], 2); tb[5] = 0;
    vga_print(tb, fg, 74, TASKBAR_Y);
}

/* ---------- Actions ---------- */
static void launch_fullscreen(int idx) {
    vga_clear(vga_make_color(VGA_LIGHT_GREY, VGA_BLACK));
    switch (idx) {
        case 0: fte_run("UNTITLED.TXT"); break;
        case 1: wrd_run("DOC1.TXT");     break;
        case 3: chart_run();             break;
        case 4: sheet_run();             break;
        case 5: mandel_run();            break;
        case 7: paint_run();             break;
    }
    vga_clear(vga_make_color(VGA_LIGHT_GREY, VGA_BLACK));
}

static void open_calc_window(void) {
    if (calc_window >= 0) { wm_focus(calc_window); return; }
    calc_clear();
    calc_window = wm_create(30, 6, 22, 13, "Calculator", draw_calc);
}

static void open_about_window(void) {
    if (about_window >= 0) { wm_focus(about_window); return; }
    about_window = wm_create(24, 5, 34, 14, "About NeutrinoOS", draw_about);
}

static void open_clock_window(void) {
    if (clock_window >= 0) { wm_focus(clock_window); return; }
    clock_window = wm_create(56, 3, 18, 7, "Clock", draw_clock_w);
}

static void menu_activate(int idx) {
    switch (idx) {
        case 0:
            submenu_open = 1; submenu_kind = 1; submenu_sel = 0;
            break;
        case 1:
            submenu_open = 1; submenu_kind = 2; submenu_sel = 0;
            break;
        case 5:
            open_about_window();
            menu_open = 0; submenu_open = 0;
            break;
        case 7:
            pcspk_click();
            menu_open = 0; submenu_open = 0;
            power_shutdown();
            break;
        default:
            menu_open = 0; submenu_open = 0;
            break;
    }
}

static void program_activate(int idx) {
    switch (idx) {
        case 2: open_calc_window();  break;
        case 6: open_clock_window(); break;
        case 0: case 1: case 3: case 4: case 5: case 7:
            launch_fullscreen(idx);
            break;
    }
    submenu_open = 0;
    menu_open = 0;
}

static void settings_activate(int idx) {
    switch (idx) {
        case 0: vga_clear(vga_make_color(VGA_LIGHT_GREY, VGA_BLACK)); settings_run(); break;
        case 1: vga_clear(vga_make_color(VGA_LIGHT_GREY, VGA_BLACK)); theme_run();    break;
        case 2: vga_clear(vga_make_color(VGA_LIGHT_GREY, VGA_BLACK)); fetch_show();   break;
        case 3: open_about_window(); break;
    }
    submenu_open = 0;
    menu_open = 0;
}

/* ---------- Click dispatch ---------- */
static void handle_calc_click(int wid, int bx, int by) {
    wm_window_t* w = wm_get(wid);
    if (!w) return;
    int cx_rel = bx - w->x - 1;
    int cy_rel = by - w->y - 1;
    if (cy_rel >= 2 && cy_rel <= 9 && ((cy_rel - 2) % 2) == 0) {
        int r = (cy_rel - 2) / 2;
        int c = cx_rel / 5;
        if (c >= 0 && c < 4 && r >= 0 && r < 4) {
            const char keys[4][4] = {
                {'7','8','9','/'},
                {'4','5','6','*'},
                {'1','2','3','-'},
                {'0','C','=','+'},
            };
            char k = keys[r][c];
            if (k >= '0' && k <= '9')  calc_digit(k - '0');
            else if (k == 'C')         calc_clear();
            else if (k == '=')         calc_setop(0);
            else                       calc_setop(k);
        }
    }
}

static void close_window(int wid) {
    if (wid == calc_window)  calc_window  = -1;
    if (wid == about_window) about_window = -1;
    if (wid == clock_window) clock_window = -1;
    wm_destroy(wid);
}

static void handle_click(int bx, int by, int button) {
    if (button != 0) return;   /* Right click reserved */

    /* 1. Menu handling */
    if (menu_open) {
        if (submenu_open) {
            int sx = MENU_X + MENU_W - 1;
            int sy = MENU_Y + 1 + menu_sel;
            int count = (submenu_kind == 1) ? PROG_COUNT : SETTINGS_COUNT;
            int sh = count + 2;
            if (sy + sh > 24) sy = 24 - sh;
            if (bx >= sx && bx < sx + SUBMENU_W && by >= sy && by < sy + sh) {
                int item = by - sy - 1;
                if (item >= 0 && item < count) {
                    if (submenu_kind == 1) program_activate(item);
                    else                   settings_activate(item);
                }
                return;
            }
        }
        if (bx >= MENU_X && bx < MENU_X + MENU_W &&
            by >= MENU_Y && by < MENU_Y + MENU_H) {
            int item = by - MENU_Y - 1;
            if (item >= 0 && item < MENU_COUNT && menu_items[item][0] != 0) {
                menu_sel = item;
                menu_activate(item);
            }
            return;
        }
        /* Outside menu — close it, unless click hit the Start button */
        if (!(by == TASKBAR_Y && bx < 8)) {
            menu_open = 0;
            submenu_open = 0;
        }
    }

    /* 2. Taskbar */
    if (by == TASKBAR_Y) {
        if (bx < 8) {
            menu_open = !menu_open;
            menu_sel = 0;
            submenu_open = 0;
            return;
        }
        int wx = 9;
        for (int i = 0; i < WM_MAX_WINDOWS; i++) {
            wm_window_t* w = wm_get(i);
            if (!w || !w->used) continue;
            char buf[24]; int p = 0;
            buf[p++] = ' ';
            int tlen = strlen(w->title);
            if (tlen > 10) tlen = 10;
            for (int j = 0; j < tlen; j++) buf[p++] = w->title[j];
            buf[p++] = ' '; buf[p] = 0;
            if (bx >= wx && bx < wx + p) {
                wm_focus(i);
                return;
            }
            wx += p + 1;
        }
        return;
    }

    /* 3. Windows */
    int wid = wm_hit(bx, by);
    if (wid >= 0) {
        wm_focus(wid);
        wm_window_t* w = wm_get(wid);
        if (!w) return;

        /* Close button */
        if (by == w->y && bx >= w->x + w->w - 4 && bx <= w->x + w->w - 2) {
            close_window(wid);
            return;
        }

        /* In-window widgets */
        if (wid == calc_window) handle_calc_click(wid, bx, by);
        return;
    }
}

/* ---------- Main loop ---------- */
void gui_run(void) {
    mouse_init();
    wm_init();
    menu_open = 0;
    menu_sel = 0;
    submenu_open = 0;
    submenu_sel = 0;
    submenu_kind = 0;
    calc_window = -1;
    about_window = -1;
    clock_window = -1;
    calc_clear();

    vga_set_cursor(0, 0);

    while (1) {
        /* Draw everything */
        vga_clear(vga_make_color(DESKTOP_FG, DESKTOP_BG));
        wm_draw_all();
        draw_taskbar();
        if (menu_open) draw_start_menu();
        mouse_draw();

        /* Input */
        int key = keyboard_getchar();

        /* Cursor movement */
        if (key == -KEY_UP)    { mouse_move(0, -1); continue; }
        if (key == -KEY_DOWN)  { mouse_move(0,  1); continue; }
        if (key == -KEY_LEFT)  { mouse_move(-1, 0); continue; }
        if (key == -KEY_RIGHT) { mouse_move( 1, 0); continue; }

        /* Mouse buttons */
        if (key == '[') { handle_click(mouse_x(), mouse_y(), 0); continue; }
        if (key == ']') { handle_click(mouse_x(), mouse_y(), 1); continue; }

        /* Escape */
        if (key == -KEY_ESC) {
            if (submenu_open) { submenu_open = 0; continue; }
            if (menu_open)    { menu_open    = 0; continue; }
            int wid = wm_focused();
            if (wid >= 0) close_window(wid);
            continue;
        }

        /* Alt+Del = Start menu */
        if (key == KEY_ALT_DEL) {
            menu_open = !menu_open;
            menu_sel = 0;
            submenu_open = 0;
            continue;
        }

        /* Tab = cycle windows */
        if (key == KEY_TAB_CODE) {
            int fid = wm_focused();
            for (int i = 1; i <= WM_MAX_WINDOWS; i++) {
                int next = (fid + i) % WM_MAX_WINDOWS;
                wm_window_t* w = wm_get(next);
                if (w && w->used) { wm_focus(next); break; }
            }
            continue;
        }

        /* Keyboard input into focused Calculator */
        if (wm_focused() == calc_window && calc_window >= 0) {
            if (key >= '0' && key <= '9')  calc_digit(key - '0');
            else if (key == '+')           calc_setop('+');
            else if (key == '-')           calc_setop('-');
            else if (key == '*')           calc_setop('*');
            else if (key == '/')           calc_setop('/');
            else if (key == '\n')          calc_setop(0);
            else if (key == 'c' || key == 'C') calc_clear();
            continue;
        }
    }
}
