#ifndef TIME_H
#define TIME_H

void time_show(void);
void date_show(void);

#endif
