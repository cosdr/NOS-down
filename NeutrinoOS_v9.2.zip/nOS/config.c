#include "config.h"
#include "fat12.h"
#include "ramdisk.h"
#include "utils.h"

static config_t cfg;

static int cfg_read(const char* name, char* buf, int max_size) {
    if (fat12_is_mounted()) {
        int n = fat12_read_file(name, buf, max_size - 1);
        if (n >= 0) { buf[n] = 0; return n; }
    }
    int fd = ramdisk_get_fd(name);
    if (fd >= 0) {
        int sz = ramdisk_read(fd, buf, max_size - 1);
        if (sz >= 0) buf[sz] = 0;
        return sz;
    }
    return -1;
}
static void cfg_write(const char* name, const char* data, int size) {
    if (fat12_is_mounted()) { fat12_write_file(name, data, size); return; }
    int fd = ramdisk_create(name);
    if (fd >= 0) ramdisk_write(fd, data, size);
}
static void read_line_trimmed(const char* src, char* dst, int max) {
    int i = 0;
    while (src[i] && src[i] != '\n' && src[i] != '\r' && i < max - 1) { dst[i] = src[i]; i++; }
    dst[i] = 0;
    while (i > 0 && (dst[i-1] == ' ' || dst[i-1] == '\t')) dst[--i] = 0;
}

void config_load(void) {
    cfg.installed  = 0;
    cfg.tz_offset  = 3;
    strcpy(cfg.tz_name, "Europe/Moscow");
    strcpy(cfg.username, "user");
    strcpy(cfg.password, "1234");
    strcpy(cfg.su_password, "root");
    cfg.theme_id    = 0;
    cfg.videomode   = 0;
    cfg.autologin   = 1;
    cfg.screensaver = 0;
    cfg.saver_delay = 60;
    cfg.slowboot    = 0;
    strcpy(cfg.prompt, "%u@neutrino> ");
    for (int i = 0; i < THEME_COLORS; i++) cfg.theme[i] = (uint8_t)i;

    char buf[1024];
    if (cfg_read("FIRST_B.CFG", buf, sizeof(buf)) > 0) cfg.installed = atoi(buf);
    if (cfg_read("THEME.CFG", buf, sizeof(buf)) > 0) cfg.theme_id = atoi(buf);
    if (cfg_read("VIDEOMODE.CFG", buf, sizeof(buf)) > 0) cfg.videomode = atoi(buf);
    if (cfg_read("AUTOLOGIN.CFG", buf, sizeof(buf)) > 0) cfg.autologin = atoi(buf);
    if (cfg_read("SLOWBOOT.CFG", buf, sizeof(buf)) > 0) cfg.slowboot = atoi(buf);
    if (cfg_read("SCREENSAVER.CFG", buf, sizeof(buf)) > 0) {
        int i = 0;
        while (buf[i] && buf[i] != '\n' && buf[i] != '\r') i++;
        char sb[8]; int k = 0;
        for (int j = 0; j < i && k < 7; j++) sb[k++] = buf[j];
        sb[k] = 0;
        cfg.screensaver = atoi(sb);
        if (buf[i]) {
            i++; while (buf[i] == '\n' || buf[i] == '\r') i++;
            cfg.saver_delay = atoi(&buf[i]);
        }
    }
    if (cfg_read("PROMPT.CFG", buf, sizeof(buf)) > 0) read_line_trimmed(buf, cfg.prompt, sizeof(cfg.prompt));
    if (cfg_read("TIMEZONE.CFG", buf, sizeof(buf)) > 0) {
        int i = 0;
        while (buf[i] && buf[i] != '\n' && buf[i] != '\r') i++;
        char offbuf[16]; int k = 0;
        for (int j = 0; j < i && k < 15; j++) offbuf[k++] = buf[j];
        offbuf[k] = 0;
        int val = atoi(offbuf);
        if (val >= -12 && val <= 12) cfg.tz_offset = val;
        if (buf[i]) {
            i++; while (buf[i] == '\n' || buf[i] == '\r') i++;
            read_line_trimmed(&buf[i], cfg.tz_name, sizeof(cfg.tz_name));
        }
    }
    if (cfg_read("USER.CFG", buf, sizeof(buf)) > 0) read_line_trimmed(buf, cfg.username, sizeof(cfg.username));
    if (cfg_read("PASSWORD.CFG", buf, sizeof(buf)) > 0) read_line_trimmed(buf, cfg.password, sizeof(cfg.password));
    if (cfg_read("SUPASS.CFG", buf, sizeof(buf)) > 0) read_line_trimmed(buf, cfg.su_password, sizeof(cfg.su_password));
}

void config_save_theme(void) { char b[16]; itoa(cfg.theme_id, b, 10); int p = strlen(b); b[p++] = '\n'; b[p] = 0; cfg_write("THEME.CFG", b, p); }
void config_save_videomode(void) { char b[16]; itoa(cfg.videomode, b, 10); int p = strlen(b); b[p++] = '\n'; b[p] = 0; cfg_write("VIDEOMODE.CFG", b, p); }
void config_save_autologin(void) { char b[16]; itoa(cfg.autologin, b, 10); int p = strlen(b); b[p++] = '\n'; b[p] = 0; cfg_write("AUTOLOGIN.CFG", b, p); }
void config_save_slowboot(void) { char b[16]; itoa(cfg.slowboot, b, 10); int p = strlen(b); b[p++] = '\n'; b[p] = 0; cfg_write("SLOWBOOT.CFG", b, p); }
void config_save_timezone(void) {
    char b[64]; int p = 0;
    itoa(cfg.tz_offset, b, 10);
    while (b[p]) p++;
    b[p++] = '\n';
    int i = 0; while (cfg.tz_name[i] && p < 60) b[p++] = cfg.tz_name[i++];
    b[p++] = '\n'; b[p] = 0;
    cfg_write("TIMEZONE.CFG", b, p);
}
void config_save_user(void) {
    cfg_write("USER.CFG",     cfg.username,    strlen(cfg.username));
    cfg_write("PASSWORD.CFG", cfg.password,    strlen(cfg.password));
    cfg_write("SUPASS.CFG",   cfg.su_password, strlen(cfg.su_password));
}
void config_save_first_boot(void) { char b[8]; itoa(cfg.installed, b, 10); int p = strlen(b); b[p++] = '\n'; b[p] = 0; cfg_write("FIRST_B.CFG", b, p); }
void config_save_screensaver(void) {
    char b[32]; int p = 0;
    itoa(cfg.screensaver, b, 10);
    while (b[p]) p++;
    b[p++] = '\n';
    itoa(cfg.saver_delay, &b[p], 10);
    p += strlen(&b[p]);
    b[p++] = '\n'; b[p] = 0;
    cfg_write("SCREENSAVER.CFG", b, p);
}
void config_save_prompt(void) { cfg_write("PROMPT.CFG", cfg.prompt, strlen(cfg.prompt)); }
void config_save(void) {
    config_save_theme();
    config_save_timezone();
    config_save_user();
    config_save_first_boot();
    config_save_videomode();
    config_save_autologin();
    config_save_screensaver();
    config_save_slowboot();
    config_save_prompt();
}
config_t* config_get(void) { return &cfg; }
