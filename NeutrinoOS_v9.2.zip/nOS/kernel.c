#include "stdint.h"
#include "vga.h"
#include "keyboard.h"
#include "ramdisk.h"
#include "fat12.h"
#include "shell.h"
#include "fetch.h"
#include "config.h"
#include "installer.h"
#include "autoexec.h"
#include "pcspk.h"
#include "palette.h"
#include "diag.h"
#include "login.h"
#include "idt.h"
#include "bsod.h"
#include "mouse.h"
#include "utils.h"

static int debug_mode = 0;

static void boot_log(const char* msg) {
    if (debug_mode) {
        vga_print_at("[BOOT] ", vga_make_color(VGA_LIGHT_CYAN, VGA_BLACK));
        vga_print_at(msg, vga_make_color(VGA_LIGHT_GREY, VGA_BLACK));
        vga_print_at("\n", vga_make_color(VGA_LIGHT_GREY, VGA_BLACK));
    }
}

static void progress(int pct, const char* label, int slow) {
    if (debug_mode) { boot_log(label); return; }
    int width = 48, x = 16, y = 12;
    int filled = width * pct / 100;
    uint8_t bar_fg = vga_make_color(VGA_LIGHT_GREEN, VGA_BLACK);
    uint8_t bar_bg = vga_make_color(VGA_DARK_GREY, VGA_BLACK);
    uint8_t lbl_fg = vga_make_color(VGA_LIGHT_CYAN, VGA_BLACK);
    uint8_t box_fg = vga_make_color(VGA_BLUE, VGA_BLACK);
    vga_draw_box(x - 2, y - 3, width + 4, 6, box_fg);
    vga_fill(x, y - 2, width, 1, ' ', vga_make_color(VGA_BLACK, VGA_BLACK));
    vga_print(label, lbl_fg, x, y - 2);
    for (int i = 0; i < width; i++)
        vga_putchar(CH_FULL_BLOCK, i < filled ? bar_fg : bar_bg, x + i, y);
    char pbuf[8]; itoa(pct, pbuf, 10);
    vga_print(pbuf, lbl_fg, x + width + 1, y);
    vga_print("%", lbl_fg, x + width + 1 + strlen(pbuf), y);
    volatile int d = 0;
    volatile int lim = slow ? 60000000 : 4000000;
    while (d < lim) d++;
}

static void check_debug_trigger(void) {
    for (int i = 0; i < 900; i++) {
        int k = keyboard_poll();
        if (k == 'D') { debug_mode = 1; return; }
        for (volatile int d = 0; d < 30000; d++) { }
    }
}

void kernel_main(uint32_t magic, uint32_t mb_info) {
    vga_init();
    vga_clear(vga_make_color(VGA_LIGHT_GREY, VGA_BLACK));

    if (magic == 0x2BADB002 && mb_info) {
        uint32_t* mb = (uint32_t*)mb_info;
        uint32_t flags = mb[0];
        if (flags & (1 << 0)) {
            uint32_t mem_lower = mb[1], mem_upper = mb[2];
            int total_kb = (int)(mem_lower + mem_upper);
            fetch_set_ram(total_kb / 1024);
        }
    }
    fetch_set_version("v0.9.2");

    vga_print_at("NeutrinoOS v0.9.2\n", vga_make_color(VGA_LIGHT_GREEN, VGA_BLACK));
    vga_print_at("(Shift+D during boot for debug logs)\n", vga_make_color(VGA_DARK_GREY, VGA_BLACK));

    keyboard_init();
    mouse_init();
    check_debug_trigger();

    if (!debug_mode && fat12_is_mounted()) {
        int idx = fat12_find("DEBUG.FLG");
        if (idx >= 0) debug_mode = 1;
    }

    if (debug_mode) {
        vga_print_at("Debug mode enabled.\n", vga_make_color(VGA_YELLOW, VGA_BLACK));
    } else {
        vga_clear(vga_make_color(VGA_LIGHT_GREY, VGA_BLACK));
        vga_draw_box(10, 1, 60, 3, vga_make_color(VGA_BLUE, VGA_BLACK));
        vga_print("NeutrinoOS v0.9.2", vga_make_color(VGA_LIGHT_GREEN, VGA_BLACK), 33, 2);
    }

    boot_log("Initializing exception-only IDT...");
    progress(5, "IDT init (exceptions only)", 0);
    idt_init();

    progress(15, "Ramdisk init", 0);
    boot_log("ramdisk_init()");
    ramdisk_init();

    progress(30, "ATA probe", 0);
    boot_log("fat12_init()");
    int disk_ok = (fat12_init() == 0);
    boot_log(disk_ok ? "FAT12 mounted" : "No disk. Ramdisk only.");
    progress(45, disk_ok ? "FAT12 mounted" : "No disk. Ramdisk only.", 0);

    progress(60, "Loading config", 0);
    boot_log("config_load()");
    config_load();
    config_t* cfg = config_get();
    boot_log("Applying theme");
    palette_apply_theme(cfg->theme_id);

    int slow = cfg->slowboot ? 1 : 0;

    int fd = ramdisk_create("README.TXT");
    if (fd >= 0) ramdisk_write(fd, "NeutrinoOS v0.9.2. Type HELP for commands.", 43);
    fd = ramdisk_create("HELLO.TXT");
    if (fd >= 0) ramdisk_write(fd, "Hello from NeutrinoOS v0.9.2!", 29);

    progress(70, "Checking filesystem", slow);
    boot_log("diag_check_files()");
    diag_check_files();

    if (!cfg->installed) {
        boot_log("First boot — launching installer");
        progress(78, "First boot install", slow);
        installer_run();
    }

    boot_log("login_run()");
    progress(85, "Authentication", slow);
    login_run();

    boot_log("motd_show()");
    progress(90, "MOTD", slow);
    motd_show();

    progress(95, "AUTOEXEC.NE", slow);
    if (cfg->installed) {
        boot_log("Running AUTOEXEC.NE");
        autoexec_run("AUTOEXEC.NE");
    }

    progress(100, "Ready", slow);
    boot_log("Boot complete.");
    for (volatile int d = 0; d < 4000000; d++) { }

    shell_run();
    for (;;) __asm__ volatile("hlt");
}
