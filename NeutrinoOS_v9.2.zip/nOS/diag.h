#ifndef DIAG_H
#define DIAG_H

void diag_check_files(void);

#endif
