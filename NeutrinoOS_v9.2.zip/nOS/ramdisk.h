#ifndef RAMDISK_H
#define RAMDISK_H

#include "stdint.h"

#define RAMDISK_MAX_FILES 64
#define RAMDISK_MAX_FILENAME 32
#define RAMDISK_MAX_FILESIZE 8192

typedef struct {
    char name[RAMDISK_MAX_FILENAME];
    char data[RAMDISK_MAX_FILESIZE];
    int size;
    int used;
} ramdisk_file_t;

void ramdisk_init(void);
int  ramdisk_create(const char* name);
int  ramdisk_write(int fd, const char* data, int size);
int  ramdisk_read(int fd, char* buffer, int max_size);
int  ramdisk_list(char* buffer, int max_size);
int  ramdisk_delete(const char* name);
int  ramdisk_exists(const char* name);
int  ramdisk_get_fd(const char* name);
int  ramdisk_count(void);
const char* ramdisk_get_name(int index);
const ramdisk_file_t* ramdisk_get_entry(int index);

#endif
