#include "wm.h"
#include "vga.h"
#include "utils.h"

static wm_window_t windows[WM_MAX_WINDOWS];
static int z_top = 0;
static int focused_id = -1;

void wm_init(void) {
    for (int i = 0; i < WM_MAX_WINDOWS; i++) windows[i].used = 0;
    z_top = 0;
    focused_id = -1;
}

int wm_create(int x, int y, int w, int h, const char* title, wm_draw_fn draw) {
    if (x < 0) x = 0;
    if (y < 0) y = 0;
    if (w < 6 || h < 4) return -1;
    if (x + w > VGA_WIDTH)  w = VGA_WIDTH - x;
    if (y + h > 24)         h = 24 - y;          /* taskbar at 24 */
    if (w < 6 || h < 4) return -1;

    for (int i = 0; i < WM_MAX_WINDOWS; i++) {
        if (!windows[i].used) {
            windows[i].used      = 1;
            windows[i].x         = x;
            windows[i].y         = y;
            windows[i].w         = w;
            windows[i].h         = h;
            windows[i].z         = z_top++;
            windows[i].minimized = 0;
            windows[i].draw_content = draw;
            strncpy(windows[i].title, title, WM_MAX_TITLE - 1);
            windows[i].title[WM_MAX_TITLE - 1] = 0;
            focused_id = i;
            return i;
        }
    }
    return -1;
}

void wm_destroy(int id) {
    if (id < 0 || id >= WM_MAX_WINDOWS) return;
    if (!windows[id].used) return;
    windows[id].used = 0;

    if (focused_id == id) {
        int best_z = -1;
        focused_id = -1;
        for (int i = 0; i < WM_MAX_WINDOWS; i++) {
            if (windows[i].used && !windows[i].minimized && windows[i].z > best_z) {
                best_z = windows[i].z;
                focused_id = i;
            }
        }
    }
}

void wm_focus(int id) {
    if (id < 0 || id >= WM_MAX_WINDOWS) return;
    if (!windows[id].used) return;
    windows[id].z = z_top++;
    windows[id].minimized = 0;
    focused_id = id;
}

int wm_focused(void) { return focused_id; }

int wm_hit(int x, int y) {
    int best_z = -1, best_id = -1;
    for (int i = 0; i < WM_MAX_WINDOWS; i++) {
        if (!windows[i].used || windows[i].minimized) continue;
        if (x >= windows[i].x && x < windows[i].x + windows[i].w &&
            y >= windows[i].y && y < windows[i].y + windows[i].h) {
            if (windows[i].z > best_z) { best_z = windows[i].z; best_id = i; }
        }
    }
    return best_id;
}

static void draw_frame(int id) {
    wm_window_t* w = &windows[id];
    int x = w->x, y = w->y, ww = w->w, hh = w->h;
    int focused = (focused_id == id);

    uint8_t title_fg   = focused ? vga_make_color(VGA_WHITE, VGA_BLUE)
                                 : vga_make_color(VGA_LIGHT_GREY, VGA_DARK_GREY);
    uint8_t title_bg   = focused ? VGA_BLUE : VGA_DARK_GREY;
    uint8_t border_col = focused ? VGA_LIGHT_GREY : VGA_DARK_GREY;
    uint8_t border     = vga_make_color(border_col, VGA_BLACK);

    /* Shadow (bottom-right) */
    uint8_t shadow = vga_make_color(VGA_DARK_GREY, VGA_BLACK);
    for (int i = 1; i <= ww && x + i < VGA_WIDTH; i++)
        vga_putcell(x + i, y + hh, ' ', shadow, VGA_BLACK);
    for (int j = 1; j <= hh && y + j < 24; j++)
        vga_putcell(x + ww, y + j, ' ', shadow, VGA_BLACK);

    /* Title bar */
    for (int i = 0; i < ww; i++)
        vga_putcell(x + i, y, ' ', title_fg, title_bg);

    int max_title = ww - 8;
    int tlen = strlen(w->title);
    if (tlen > max_title) tlen = max_title;
    for (int i = 0; i < tlen && i < WM_MAX_TITLE; i++)
        vga_putcell(x + 2 + i, y, w->title[i], title_fg, title_bg);

    /* Close button [X] at right */
    vga_putcell(x + ww - 4, y, '[', title_fg, title_bg);
    vga_putcell(x + ww - 3, y, 'X', title_fg, title_bg);
    vga_putcell(x + ww - 2, y, ']', title_fg, title_bg);

    /* Left / right borders */
    for (int j = 1; j < hh - 1; j++) {
        vga_putcell(x,          y + j, 0xB3, border, VGA_BLACK);
        vga_putcell(x + ww - 1, y + j, 0xB3, border, VGA_BLACK);
    }

    /* Bottom border */
    for (int i = 1; i < ww - 1; i++)
        vga_putcell(x + i, y + hh - 1, 0xC4, border, VGA_BLACK);
    vga_putcell(x,          y + hh - 1, 0xC0, border, VGA_BLACK);
    vga_putcell(x + ww - 1, y + hh - 1, 0xD9, border, VGA_BLACK);

    /* Content background (light grey) */
    uint8_t cbg = vga_make_color(VGA_BLACK, VGA_LIGHT_GREY);
    for (int j = 1; j < hh - 1; j++)
        for (int i = 1; i < ww - 1; i++)
            vga_putcell(x + i, y + j, ' ', cbg, VGA_LIGHT_GREY);
}

void wm_draw_all(void) {
    /* Draw in z-order from lowest to highest */
    for (int z = 0; z < z_top; z++) {
        int id = -1;
        for (int i = 0; i < WM_MAX_WINDOWS; i++) {
            if (windows[i].used && !windows[i].minimized && windows[i].z == z) {
                id = i;
                break;
            }
        }
        if (id < 0) continue;
        draw_frame(id);
        if (windows[id].draw_content)
            windows[id].draw_content(id,
                                     windows[id].x + 1,
                                     windows[id].y + 1,
                                     windows[id].w - 2,
                                     windows[id].h - 2);
    }
}

wm_window_t* wm_get(int id) {
    if (id < 0 || id >= WM_MAX_WINDOWS) return 0;
    return &windows[id];
}
