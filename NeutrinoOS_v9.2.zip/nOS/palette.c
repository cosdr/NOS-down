#include "palette.h"
#include "utils.h"

static const uint8_t default_palette[16][3] = {
    { 0,  0,  0},  { 0,  0, 42},  { 0, 42,  0},  { 0, 42, 42},
    {42,  0,  0},  {42,  0, 42},  {42, 21,  0},  {42, 42, 42},
    {21, 21, 21},  {21, 21, 63},  {21, 63, 21},  {21, 63, 63},
    {63, 21, 21},  {63, 21, 63},  {63, 63, 21},  {63, 63, 63}
};

static const theme_def_t predefined_themes[] = {
    { "Classic", {
        { 0,  0,  0}, { 0,  0, 42}, { 0, 42,  0}, { 0, 42, 42},
        {42,  0,  0}, {42,  0, 42}, {42, 21,  0}, {42, 42, 42},
        {21, 21, 21}, {21, 21, 63}, {21, 63, 21}, {21, 63, 63},
        {63, 21, 21}, {63, 21, 63}, {63, 63, 21}, {63, 63, 63}}},
    { "Ubuntu", {
        { 12,  2,  9}, { 13, 25, 41}, { 19, 38,  1}, {  1, 38, 38},
        { 51,  0,  0}, { 29, 20, 30}, { 49, 40,  0}, { 52, 53, 51},
        { 21, 21, 20}, { 28, 39, 51}, { 34, 56, 13}, { 13, 56, 56},
        { 59, 10, 10}, { 43, 31, 42}, { 63, 58, 19}, { 59, 59, 59}}},
    { "Deep Sea", {
        {  0,  2,  5}, {  0, 10, 20}, {  0, 20, 15}, {  0, 22, 25},
        { 25,  5,  5}, { 20,  5, 20}, { 30, 20,  5}, { 35, 40, 45},
        { 10, 12, 15}, { 15, 30, 50}, { 10, 45, 30}, { 15, 50, 50},
        { 50, 20, 20}, { 50, 25, 45}, { 55, 48, 20}, { 55, 58, 60}}},
    { "BW", {
        {  0,  0,  0}, {  4,  4,  4}, {  8,  8,  8}, { 12, 12, 12},
        { 16, 16, 16}, { 20, 20, 20}, { 24, 24, 24}, { 28, 28, 28},
        { 32, 32, 32}, { 36, 36, 36}, { 40, 40, 40}, { 44, 44, 44},
        { 48, 48, 48}, { 52, 52, 52}, { 56, 56, 56}, { 63, 63, 63}}},
    { "Matrix", {
        {  0,  0,  0}, {  0,  5,  0}, {  0, 10,  0}, {  0, 15,  0},
        {  0, 20,  0}, {  0, 25,  0}, {  0, 30,  0}, {  0, 35,  0},
        {  0, 40,  0}, {  0, 45,  0}, {  0, 50,  0}, {  0, 55,  0},
        {  0, 58,  0}, {  0, 61,  0}, {  0, 63,  0}, { 20, 63, 20}}},
    { "Yantar", {
        {  0,  0,  0}, {  5,  2,  0}, { 10,  5,  0}, { 15,  7,  0},
        { 20, 10,  0}, { 25, 12,  0}, { 30, 15,  0}, { 35, 17,  0},
        { 40, 20,  0}, { 45, 22,  0}, { 50, 25,  0}, { 55, 27,  0},
        { 58, 30,  0}, { 61, 32,  0}, { 63, 35,  0}, { 63, 45, 15}}}
};

#define NUM_THEMES ((int)(sizeof(predefined_themes)/sizeof(predefined_themes[0])))

void palette_set_entry(int idx, uint8_t r, uint8_t g, uint8_t b) {
    outb(0x3C8, (uint8_t)idx);
    outb(0x3C9, (uint8_t)(r & 0x3F));
    outb(0x3C9, (uint8_t)(g & 0x3F));
    outb(0x3C9, (uint8_t)(b & 0x3F));
}
void palette_load(const uint8_t pal[16][3]) {
    for (int i = 0; i < 16; i++) palette_set_entry(i, pal[i][0], pal[i][1], pal[i][2]);
}
void palette_load_default(void) { palette_load(default_palette); }
int palette_theme_count(void) { return NUM_THEMES; }
const theme_def_t* palette_theme(int idx) {
    if (idx < 0 || idx >= NUM_THEMES) return &predefined_themes[0];
    return &predefined_themes[idx];
}
const char* palette_theme_name(int idx) { return palette_theme(idx)->name; }
void palette_apply_theme(int theme_id) { palette_load(palette_theme(theme_id)->rgb); }
int palette_find_theme(const char* name) {
    for (int i = 0; i < NUM_THEMES; i++)
        if (strcasecmp(predefined_themes[i].name, name) == 0) return i;
    return -1;
}
