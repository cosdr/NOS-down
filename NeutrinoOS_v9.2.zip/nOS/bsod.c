#include "bsod.h"
#include "vga.h"
#include "keyboard.h"
#include "power.h"
#include "palette.h"
#include "utils.h"

void bsod(const char* title, const char* message) {
    __asm__ volatile("cli");
    palette_load_default();
    vga_clear(vga_make_color(VGA_WHITE, VGA_BLUE));

    uint8_t title_fg = vga_make_color(VGA_WHITE, VGA_BLUE);
    uint8_t dim_fg   = vga_make_color(VGA_LIGHT_GREY, VGA_BLUE);

    for (int i = 0; i < 80; i++) vga_putchar(219, title_fg, i, 0);
    vga_print("NeutrinoOS", title_fg, 2, 2);
    vga_print("KERNEL PANIC", title_fg, 2, 4);

    vga_print("A fatal error has occurred. The system has been halted", dim_fg, 2, 7);
    vga_print("to prevent further damage to your computer.", dim_fg, 2, 8);

    vga_print(title, title_fg, 2, 11);
    vga_print(message, dim_fg, 2, 12);

    vga_print("Technical information:", title_fg, 2, 15);
    vga_print("  > System halted to avoid data corruption", dim_fg, 2, 16);
    vga_print("  > All unsaved data will be lost", dim_fg, 2, 17);
    vga_print("  > Restart the machine to continue", dim_fg, 2, 18);

    vga_print("Press ENTER to reboot, ESC to stay halted.", title_fg, 2, 22);

    for (;;) {
        int k = keyboard_getchar();
        if (k == '\n') power_reboot();
        if (k == -KEY_ESC) {
            vga_print("System halted. You may now turn off the machine.", dim_fg, 2, 24);
            for (;;) __asm__ volatile("hlt");
        }
    }
}
