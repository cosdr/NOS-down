#include "gfxtest.h"
#include "vga.h"
#include "keyboard.h"
#include "utils.h"

void gfxtest_run(void) {
    gfx_enter_mode13();

    for (int band = 0; band < 32; band++) {
        uint8_t c = (uint8_t)(band * 8);
        gfx_fillrect(0, band * 2, 320, 2, c);
    }
    for (int i = 0; i < 16; i++) {
        gfx_fillrect(10 + i * 18, 70, 16, 16, (uint8_t)(i * 16));
    }
    for (int i = 0; i < 100; i += 2) {
        gfx_line(10, 190 - i / 2, 310, 100 + i, (uint8_t)(i + 100));
    }
    gfx_fillrect(120, 110, 80, 60, 4);
    gfx_rect(120, 110, 80, 60, 15);

    gfx_drawtext(10, 10, "NEUTRINOOS GFX TEST", 15);
    gfx_drawtext(10, 22, "MODE 13H 320X200X256", 14);
    gfx_drawtext(10, 40, "PRESS ANY KEY TO RETURN", 11);

    keyboard_getchar();
    gfx_leave_mode13();
    vga_clear(vga_make_color(VGA_LIGHT_GREY, VGA_BLACK));
}
