#ifndef GFXTEST_H
#define GFXTEST_H

void gfxtest_run(void);

#endif
