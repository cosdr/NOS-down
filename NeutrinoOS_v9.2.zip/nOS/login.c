#include "login.h"
#include "vga.h"
#include "keyboard.h"
#include "config.h"
#include "palette.h"
#include "power.h"
#include "pcspk.h"
#include "utils.h"

static int read_field(int x, int y, int max_w, char* out, int max, int mask) {
    uint8_t fg = vga_make_color(VGA_BLACK, VGA_LIGHT_GREY);
    for (int i = 0; i < max_w; i++) vga_putchar('_', fg, x + i, y);
    int pos = 0, cx = x;
    for (;;) {
        vga_putchar(219, fg, cx, y);
        int k = keyboard_getchar();
        vga_putchar('_', fg, cx, y);
        if (k == '\n') { out[pos] = 0; return pos; }
        if (k == -KEY_ESC) { out[0] = 0; return -1; }
        if (k == '\b' && pos > 0) { pos--; cx--; vga_putchar('_', fg, cx, y); }
        else if (k > 0 && k < 128 && pos < max - 1 && cx < x + max_w - 1) {
            out[pos++] = (char)k;
            vga_putchar(mask ? '*' : (char)k, fg, cx, y);
            cx++;
        }
    }
}

int login_run(void) {
    config_t* cfg = config_get();
    if (cfg->autologin && cfg->password[0]) return 1;
    int attempts = 0;
    while (1) {
        vga_clear(vga_make_color(VGA_BLACK, VGA_LIGHT_MAGENTA));
        int w = 60, h = 4;
        int hx = (80 - w) / 2, hy = 2;
        vga_fill_bg(hx, hy, w, h, ' ', VGA_BLACK, VGA_LIGHT_GREY);
        vga_draw_box(hx, hy, w, h, vga_make_color(VGA_BLACK, VGA_LIGHT_GREY));
        vga_print("NeutrinoOS v0.9.2", vga_make_color(VGA_BLACK, VGA_LIGHT_GREY), hx + 4, hy + 1);
        vga_print("Mikelsoft Corporation INC.", vga_make_color(VGA_BLACK, VGA_LIGHT_GREY), hx + 4, hy + 2);
        int px = 10, py = 8, pw = 60, ph = 10;
        vga_fill_bg(px, py, pw, ph, ' ', VGA_BLACK, VGA_LIGHT_GREY);
        vga_draw_box(px, py, pw, ph, vga_make_color(VGA_BLACK, VGA_LIGHT_GREY));
        uint8_t fg = vga_make_color(VGA_BLACK, VGA_LIGHT_GREY);
        vga_print("Username :", fg, px + 3, py + 2);
        vga_print("Password :", fg, px + 3, py + 5);
        char user[32], pass[32];
        int r = read_field(px + 14, py + 2, pw - 17, user, sizeof(user), 0);
        if (r < 0) { power_reboot(); }
        r = read_field(px + 14, py + 5, pw - 17, pass, sizeof(pass), 1);
        if (r < 0) { power_reboot(); }
        if (strcmp(user, cfg->username) == 0 && strcmp(pass, cfg->password) == 0) {
            pcspk_click();
            vga_clear(vga_make_color(VGA_LIGHT_GREY, VGA_BLACK));
            return 1;
        }
        attempts++;
        vga_print("Login failed. Press any key...", vga_make_color(VGA_WHITE, VGA_LIGHT_RED), px + 3, py + 8);
        keyboard_getchar();
        if (attempts >= 3) {
            vga_print("Too many attempts. Waiting 5s...",
                      vga_make_color(VGA_WHITE, VGA_LIGHT_RED), px + 3, py + 8);
            for (volatile int d = 0; d < 40000000; d++) { }
            attempts = 0;
        }
    }
}
