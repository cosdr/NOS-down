#ifndef CPU_H
#define CPU_H

void cpu_show(void);
int  cpu_get_brand(char* out, int max);
int  cpu_get_vendor(char* out, int max);

#endif
