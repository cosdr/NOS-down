#include "shell.h"
#include "vga.h"
#include "keyboard.h"
#include "ramdisk.h"
#include "fat12.h"
#include "ata.h"
#include "paint.h"
#include "installer.h"
#include "fetch.h"
#include "cpu.h"
#include "time.h"
#include "theme.h"
#include "config.h"
#include "palette.h"
#include "timezone.h"
#include "power.h"
#include "sysmenu.h"
#include "calc.h"
#include "calendar.h"
#include "clock.h"
#include "clocka.h"
#include "mandel.h"
#include "games.h"
#include "screensaver.h"
#include "gui.h"
#include "editor.h"
#include "fte.h"
#include "wrd.h"
#include "gfxtest.h"
#include "autoexec.h"
#include "pcspk.h"
#include "chart.h"
#include "sheet.h"
#include "settings.h"
#include "bsod.h"
#include "utils.h"

#define MAX_CMD_LEN 128
#define HISTORY_SIZE 10

static const char* cmd_list[] = {
    "DIR","LS","CD","MKDIR","RMDIR","CAT","HEAD","TAIL","GREP","TREE",
    "CREATE","READ","DEL","RM","ECHO","CLEAR","CLS","PAINT","TIME","DATE",
    "INSTALL","FETCH","CPU","THEME","SAVE","LOAD","DISK","ABOUT","HELP",
    "CALC","CALENDAR","CLOCK","CLOCKA","MANDEL","GUI","EDIT","FTE","WRD",
    "SNAKE","TETRIS","PONG","MINE","HANGMAN",
    "SAVER","BEEP","MELODY","AUTOEXEC",
    "DF","LOGON","REBOOT","SHUTDOWN","FORMAT","TZ",
    "CHART","SHEET","SETTINGS","PANIC","MOTD","BANNER","INFO",
    "GFXTEST",
    NULL
};

static char history[HISTORY_SIZE][MAX_CMD_LEN];
static int  history_count = 0;

static void history_push(const char* cmd) {
    if (!cmd || !*cmd) return;
    if (history_count > 0 && strcasecmp(history[history_count - 1], cmd) == 0) return;
    if (history_count < HISTORY_SIZE) { strncpy(history[history_count], cmd, MAX_CMD_LEN); history_count++; }
    else {
        for (int i = 0; i < HISTORY_SIZE - 1; i++) strcpy(history[i], history[i + 1]);
        strncpy(history[HISTORY_SIZE - 1], cmd, MAX_CMD_LEN);
    }
}
static void autocomplete(char* cmd_buf, int* cmd_pos, uint8_t text_fg) {
    if (*cmd_pos == 0) return;
    int first_space = -1;
    for (int i = 0; i < *cmd_pos; i++) if (cmd_buf[i] == ' ') { first_space = i; break; }
    if (first_space != -1) return;
    const char* match = NULL; int mc = 0;
    for (int i = 0; cmd_list[i]; i++) {
        int ok = 1;
        for (int j = 0; j < *cmd_pos; j++)
            if (to_lower(cmd_list[i][j]) != to_lower(cmd_buf[j])) { ok = 0; break; }
        if (ok) { match = cmd_list[i]; mc++; if (mc > 1) break; }
    }
    if (mc == 1 && match) {
        int len = strlen(match);
        for (int i = 0; i < *cmd_pos; i++) {
            vga_putchar_at('\b', text_fg);
            vga_putchar_at(' ', text_fg);
            vga_putchar_at('\b', text_fg);
        }
        for (int i = 0; i < len; i++) { cmd_buf[i] = match[i]; vga_putchar_at(match[i], text_fg); }
        cmd_buf[len] = 0;
        *cmd_pos = len;
    }
}

static int fs_read(const char* name, char* buf, int max) {
    if (fat12_is_mounted()) { int n = fat12_read_file(name, buf, max - 1); if (n >= 0) { buf[n] = 0; return n; } }
    int fd = ramdisk_get_fd(name);
    if (fd < 0) return -1;
    int sz = ramdisk_read(fd, buf, max - 1);
    if (sz >= 0) buf[sz] = 0;
    return sz;
}
static int fs_write(const char* name, const char* data, int size) {
    if (fat12_is_mounted()) { if (fat12_write_file(name, data, size) == 0) return size; }
    int fd = ramdisk_create(name);
    if (fd < 0) return -1;
    return ramdisk_write(fd, data, size);
}
static int fs_delete(const char* name) {
    if (fat12_is_mounted()) { if (fat12_delete_file(name) == 0) return 0; }
    return ramdisk_delete(name);
}
static int fs_list(char* buffer, int max_size) {
    if (fat12_is_mounted()) {
        fat12_entry_t entries[128];
        int n = fat12_list(entries, 128);
        int pos = 0;
        for (int i = 0; i < n; i++) {
            const char* nm = entries[i].name;
            while (*nm && pos < max_size - 1) buffer[pos++] = *nm++;
            if (pos < max_size - 20) {
                buffer[pos++] = ' '; buffer[pos++] = '(';
                char tmp[16]; int tp = 0;
                uint32_t sz = entries[i].size;
                if (sz == 0) buffer[pos++] = '0';
                else { while (sz > 0) { tmp[tp++] = (char)('0' + (sz % 10)); sz /= 10; } while (tp > 0) buffer[pos++] = tmp[--tp]; }
                buffer[pos++] = 'B'; buffer[pos++] = ')';
            }
            if (pos < max_size - 1) buffer[pos++] = '\n';
        }
        if (pos > 0 && buffer[pos-1] == '\n') pos--;
        buffer[pos] = 0;
        return pos;
    }
    return ramdisk_list(buffer, max_size);
}

static void out_ok(const char* m)    { vga_print_at(m, vga_make_color(VGA_LIGHT_GREEN, VGA_BLACK)); }
static void out_err(const char* m)   { vga_print_at(m, vga_make_color(VGA_LIGHT_RED, VGA_BLACK)); }
static void out_txt(const char* m)   { vga_print_at(m, vga_make_color(VGA_LIGHT_GREY, VGA_BLACK)); }
static void out_title(const char* m) { vga_print_at(m, vga_make_color(VGA_YELLOW, VGA_BLACK)); }

static int require_root(void) {
    config_t* cfg = config_get();
    if (cfg->su_password[0] == 0) return 1;
    uint8_t prompt_fg = vga_make_color(VGA_LIGHT_RED, VGA_BLACK);
    uint8_t input_fg  = vga_make_color(VGA_WHITE, VGA_BLACK);
    vga_print_at("Root password: ", prompt_fg);
    char buf[32]; int pos = 0;
    while (1) {
        int k = keyboard_getchar();
        if (k == '\n') { buf[pos] = 0; break; }
        if (k == -KEY_ESC) { buf[0] = 0; break; }
        if (k == '\b' && pos > 0) {
            pos--;
            vga_putchar_at('\b', input_fg); vga_putchar_at(' ', input_fg); vga_putchar_at('\b', input_fg);
        } else if (k > 0 && k < 128 && pos < 31) {
            buf[pos++] = (char)k;
            vga_putchar_at('*', input_fg);
        }
    }
    vga_putchar_at('\n', input_fg);
    if (strcmp(buf, cfg->su_password) != 0) { out_err("Access denied.\n"); return 0; }
    return 1;
}

static void cmd_dir(void) {
    char list[2048]; fs_list(list, sizeof(list));
    out_title(fat12_is_mounted() ? "=== Disk (FAT12) ===\n" : "=== Ramdisk ===\n");
    if (list[0]) { out_txt(list); vga_putchar_at('\n', vga_make_color(VGA_LIGHT_GREY, VGA_BLACK)); }
    else out_txt("(empty)\n");
}
static void cmd_cat(int argc, char** argv) {
    if (argc < 2) { out_err("Usage: CAT name\n"); return; }
    char buf[8192];
    int n = fs_read(argv[1], buf, sizeof(buf));
    if (n < 0) { out_err("Not found.\n"); return; }
    out_txt(buf);
    if (n > 0 && buf[n-1] != '\n') vga_putchar_at('\n', vga_make_color(VGA_LIGHT_GREY, VGA_BLACK));
}
static void cmd_create(int argc, char** argv) {
    if (argc < 3) { out_err("Usage: CREATE name \"content\"\n"); return; }
    char content[256]; int pos = 0;
    for (int i = 2; i < argc && pos < 250; i++) {
        if (i > 2) content[pos++] = ' ';
        const char* s = argv[i];
        while (*s && pos < 250) content[pos++] = *s++;
    }
    content[pos] = 0;
    int n = fs_write(argv[1], content, pos);
    if (n < 0) out_err("Write failed.\n"); else out_ok("Created.\n");
}
static void cmd_delete(int argc, char** argv) {
    if (argc < 2) { out_err("Usage: DEL name\n"); return; }
    if (!require_root()) return;
    if (fs_delete(argv[1]) == 0) out_ok("Deleted.\n"); else out_err("Not found.\n");
}
static void cmd_echo(int argc, char** argv) {
    uint8_t fg = vga_make_color(VGA_LIGHT_GREY, VGA_BLACK);
    for (int i = 1; i < argc; i++) {
        if (i > 1) vga_putchar_at(' ', fg);
        vga_print_at(argv[i], fg);
    }
    vga_putchar_at('\n', fg);
}
static void cmd_head(int argc, char** argv) {
    if (argc < 2) { out_err("Usage: HEAD name [lines]\n"); return; }
    int max_lines = argc >= 3 ? atoi(argv[2]) : 10;
    if (max_lines < 1) max_lines = 10;
    char buf[8192];
    int n = fs_read(argv[1], buf, sizeof(buf));
    if (n < 0) { out_err("Not found.\n"); return; }
    int line = 0;
    uint8_t fg = vga_make_color(VGA_LIGHT_GREY, VGA_BLACK);
    for (int i = 0; i < n && line < max_lines; i++) {
        if (buf[i] == '\n') { line++; vga_putchar_at('\n', fg); }
        else vga_putchar_at(buf[i], fg);
    }
    if (line < max_lines) vga_putchar_at('\n', fg);
}
static void cmd_tail(int argc, char** argv) {
    if (argc < 2) { out_err("Usage: TAIL name [lines]\n"); return; }
    int max_lines = argc >= 3 ? atoi(argv[2]) : 10;
    if (max_lines < 1) max_lines = 10;
    char buf[8192];
    int n = fs_read(argv[1], buf, sizeof(buf));
    if (n < 0) { out_err("Not found.\n"); return; }
    int total = 1;
    for (int i = 0; i < n; i++) if (buf[i] == '\n') total++;
    int start = total - max_lines; if (start < 0) start = 0;
    int line = 0;
    uint8_t fg = vga_make_color(VGA_LIGHT_GREY, VGA_BLACK);
    for (int i = 0; i < n; i++) {
        if (line >= start) {
            if (buf[i] == '\n') vga_putchar_at('\n', fg);
            else vga_putchar_at(buf[i], fg);
        }
        if (buf[i] == '\n') line++;
    }
    vga_putchar_at('\n', fg);
}
static void cmd_grep(int argc, char** argv) {
    if (argc < 3) { out_err("Usage: GREP pattern file\n"); return; }
    char buf[8192];
    int n = fs_read(argv[2], buf, sizeof(buf));
    if (n < 0) { out_err("Not found.\n"); return; }
    int line_start = 0, line_num = 1, found = 0;
    for (int i = 0; i <= n; i++) {
        if (i == n || buf[i] == '\n') {
            int len = i - line_start;
            if (len > 0) {
                int match = -1;
                int plen = strlen(argv[1]);
                for (int s = 0; s <= len - plen; s++) {
                    int ok = 1;
                    for (int p = 0; p < plen; p++)
                        if (to_lower(buf[line_start + s + p]) != to_lower(argv[1][p])) { ok = 0; break; }
                    if (ok) { match = s; break; }
                }
                if (match >= 0) {
                    found = 1;
                    char num[8]; itoa(line_num, num, 10);
                    vga_print_at(num, vga_make_color(VGA_LIGHT_CYAN, VGA_BLACK));
                    vga_print_at(": ", vga_make_color(VGA_LIGHT_CYAN, VGA_BLACK));
                    for (int j = 0; j < len; j++) {
                        if (j >= match && j < match + plen)
                            vga_putchar_at(buf[line_start + j], vga_make_color(VGA_LIGHT_RED, VGA_BLACK));
                        else vga_putchar_at(buf[line_start + j], vga_make_color(VGA_LIGHT_GREY, VGA_BLACK));
                    }
                    vga_putchar_at('\n', vga_make_color(VGA_LIGHT_GREY, VGA_BLACK));
                }
            }
            line_start = i + 1;
            line_num++;
        }
    }
    if (!found) out_txt("No matches.\n");
}
static void cmd_tree(void) {
    if (!fat12_is_mounted()) {
        out_txt("Tree requires mounted disk.\n");
        char list[2048]; ramdisk_list(list, sizeof(list));
        out_txt("/\n"); out_txt(list);
        vga_putchar_at('\n', vga_make_color(VGA_LIGHT_GREY, VGA_BLACK));
        return;
    }
    out_title("/\n");
    fat12_entry_t entries[128];
    int n = fat12_list(entries, 128);
    for (int i = 0; i < n; i++) {
        if (i == n - 1) vga_print_at("`-- ", vga_make_color(VGA_DARK_GREY, VGA_BLACK));
        else vga_print_at("|-- ", vga_make_color(VGA_DARK_GREY, VGA_BLACK));
        uint8_t fg = entries[i].is_dir ? vga_make_color(VGA_LIGHT_CYAN, VGA_BLACK) : vga_make_color(VGA_LIGHT_GREY, VGA_BLACK);
        vga_print_at(entries[i].name, fg);
        vga_putchar_at('\n', fg);
    }
}
static void cmd_cd(int argc, char** argv) {
    if (argc < 2) { out_txt("Current dir: /\n"); return; }
    if (strcmp(argv[1], "/") == 0 || strcmp(argv[1], "..") == 0) out_ok("Already at root.\n");
    else out_txt("Subdirectories not supported yet.\n");
}
static void cmd_mkdir(int argc, char** argv) {
    if (argc < 2) { out_err("Usage: MKDIR name\n"); return; }
    if (!fat12_is_mounted()) { out_err("No disk mounted.\n"); return; }
    if (fat12_mkdir(argv[1]) == 0) out_ok("Directory created.\n"); else out_err("Failed.\n");
}
static void cmd_save(int argc, char** argv) {
    if (!fat12_is_mounted()) { out_err("No disk mounted.\n"); return; }
    if (argc < 2) { out_err("Usage: SAVE name\n"); return; }
    int fd = ramdisk_get_fd(argv[1]);
    if (fd < 0) { out_err("Not in ramdisk.\n"); return; }
    char buf[RAMDISK_MAX_FILESIZE];
    int sz = ramdisk_read(fd, buf, sizeof(buf));
    if (sz < 0) { out_err("Read error.\n"); return; }
    if (fs_write(argv[1], buf, sz) == sz) out_ok("Saved to disk.\n"); else out_err("Write error.\n");
}
static void cmd_load(int argc, char** argv) {
    if (!fat12_is_mounted()) { out_err("No disk mounted.\n"); return; }
    if (argc < 2) { out_err("Usage: LOAD name\n"); return; }
    char buf[8192];
    int sz = fs_read(argv[1], buf, sizeof(buf));
    if (sz < 0) { out_err("Not on disk.\n"); return; }
    int fd = ramdisk_create(argv[1]);
    if (fd < 0) { out_err("Ramdisk full.\n"); return; }
    ramdisk_write(fd, buf, sz);
    out_ok("Loaded to ramdisk.\n");
}
static void cmd_disk(void) {
    config_t* cfg = config_get();
    out_title("=== Disk info ===\n");
    if (ata_is_ready()) {
        out_ok("ATA primary master: READY\n");
        if (fat12_is_mounted()) out_ok("FAT12: mounted\n");
        else out_err("FAT12: not mounted\n");
    } else {
        out_err("ATA: not detected\n");
        out_txt("Attach disk.img via run.sh\n");
    }
    char tzb[8];
    out_txt("Timezone offset: UTC");
    itoa(cfg->tz_offset, tzb, 10);
    out_txt(tzb);
    out_txt(" (");
    out_txt(cfg->tz_name);
    out_txt(")\n");
}
static void cmd_df(void) {
    out_title("Filesystem   Size    Used   Avail   Mounted on\n");
    {
        int n = ramdisk_count();
        int used = 0;
        for (int i = 0; i < n; i++) {
            const ramdisk_file_t* e = ramdisk_get_entry(i);
            if (e) used += e->size;
        }
        char line[80]; int p = 0;
        const char* nm = "ramdisk "; while (*nm) line[p++] = *nm++;
        while (p < 12) line[p++] = ' ';
        char b[16];
        itoa(RAMDISK_MAX_FILES * RAMDISK_MAX_FILESIZE / 1024, b, 10);
        for (int i = 0; b[i]; i++) line[p++] = b[i];
        line[p++] = 'K'; while (p < 20) line[p++] = ' ';
        itoa(used / 1024, b, 10);
        for (int i = 0; b[i]; i++) line[p++] = b[i];
        line[p++] = 'K'; while (p < 28) line[p++] = ' ';
        itoa((RAMDISK_MAX_FILES * RAMDISK_MAX_FILESIZE - used) / 1024, b, 10);
        for (int i = 0; b[i]; i++) line[p++] = b[i];
        line[p++] = 'K'; while (p < 38) line[p++] = ' ';
        const char* mnt = "/"; while (*mnt) line[p++] = *mnt++;
        line[p] = 0;
        out_txt(line); out_txt("\n");
    }
    if (fat12_is_mounted()) {
        uint32_t total, freeb, used;
        fat12_usage(&total, &freeb, &used);
        char line[80]; int p = 0;
        const char* nm = "A:      "; while (*nm) line[p++] = *nm++;
        while (p < 12) line[p++] = ' ';
        char b[16];
        itoa((int)(total / 1024), b, 10);
        for (int i = 0; b[i]; i++) line[p++] = b[i];
        line[p++] = 'K'; while (p < 20) line[p++] = ' ';
        itoa((int)(used / 1024), b, 10);
        for (int i = 0; b[i]; i++) line[p++] = b[i];
        line[p++] = 'K'; while (p < 28) line[p++] = ' ';
        itoa((int)(freeb / 1024), b, 10);
        for (int i = 0; b[i]; i++) line[p++] = b[i];
        line[p++] = 'K'; while (p < 38) line[p++] = ' ';
        const char* mnt = "/mnt/disk"; while (*mnt) line[p++] = *mnt++;
        line[p] = 0;
        out_txt(line); out_txt("\n");
    }
}
static void cmd_format(int argc, char** argv) {
    if (argc < 2) { out_err("Usage: format X:\n"); return; }
    char d = argv[1][0];
    if (d != 'a' && d != 'A') { out_err("Only A: supported.\n"); return; }
    if (!require_root()) return;
    if (!fat12_is_mounted()) { out_err("Disk not mounted.\n"); return; }
    out_txt("Formatting A: ...\n");
    if (fat12_format() == 0) out_ok("Done.\n"); else out_err("Failed.\n");
}
static void cmd_tz(int argc, char** argv) {
    config_t* cfg = config_get();
    if (argc < 2) {
        out_txt("Timezone: ");
        out_txt(cfg->tz_name);
        char tzb[8]; tz_format_offset(cfg->tz_offset, tzb, sizeof(tzb));
        out_txt(" (");
        out_txt(tzb);
        out_txt(")\n");
        return;
    }
    int idx = tz_find_index(argv[1]);
    if (idx < 0) { out_err("Unknown timezone. Use INSTALL or SETTINGS.\n"); return; }
    cfg->tz_offset = tz_get(idx)->offset;
    strncpy(cfg->tz_name, tz_get(idx)->name, sizeof(cfg->tz_name) - 1);
    config_save_timezone();
    out_ok("Timezone updated.\n");
}
static void cmd_logon(void) {
    config_t* cfg = config_get();
    vga_clear(vga_make_color(VGA_LIGHT_GREY, VGA_BLACK));
    uint8_t title_fg = vga_make_color(VGA_LIGHT_CYAN, VGA_BLACK);
    uint8_t label_fg = vga_make_color(VGA_LIGHT_BLUE, VGA_BLACK);
    uint8_t input_fg = vga_make_color(VGA_WHITE, VGA_BLACK);
    uint8_t err_fg   = vga_make_color(VGA_LIGHT_RED, VGA_BLACK);
    for (;;) {
        vga_draw_box(20, 8, 40, 9, vga_make_color(VGA_BLUE, VGA_BLACK));
        vga_print("=== NeutrinoOS Login ===", title_fg, 26, 10);
        vga_print("Username: ", label_fg, 22, 12);
        vga_set_cursor(32, 12);
        char user[32]; int up = 0;
        while (1) {
            int k = keyboard_getchar();
            if (k == '\n') { user[up] = 0; break; }
            if (k == -KEY_ESC) return;
            if (k == '\b' && up > 0) { up--; vga_putchar_at('\b', input_fg); vga_putchar_at(' ', input_fg); vga_putchar_at('\b', input_fg); }
            else if (k > 0 && k < 128 && up < 31) { user[up++] = (char)k; vga_putchar_at((char)k, input_fg); }
        }
        vga_print("Password: ", label_fg, 22, 14);
        vga_set_cursor(32, 14);
        char pass[32]; int pp = 0;
        while (1) {
            int k = keyboard_getchar();
            if (k == '\n') { pass[pp] = 0; break; }
            if (k == -KEY_ESC) return;
            if (k == '\b' && pp > 0) { pp--; vga_putchar_at('\b', input_fg); vga_putchar_at(' ', input_fg); vga_putchar_at('\b', input_fg); }
            else if (k > 0 && k < 128 && pp < 31) { pass[pp++] = (char)k; vga_putchar_at('*', input_fg); }
        }
        if (strcmp(user, cfg->username) == 0 && strcmp(pass, cfg->password) == 0) {
            vga_clear(vga_make_color(VGA_LIGHT_GREY, VGA_BLACK));
            return;
        }
        vga_print("Login failed. Try again.", err_fg, 26, 17);
        for (volatile int d = 0; d < 5000000; d++) { }
        vga_clear(vga_make_color(VGA_LIGHT_GREY, VGA_BLACK));
    }
}
static void cmd_about(void) {
    uint8_t c = vga_make_color(VGA_LIGHT_MAGENTA, VGA_BLACK);
    vga_draw_box(15, 8, 50, 8, vga_make_color(VGA_MAGENTA, VGA_BLACK));
    vga_print("         NeutrinoOS v0.9.2", c, 20, 10);
    vga_print("    Self-written kernel in C + ASM", c, 18, 11);
    vga_print("   Games, themes, GUI, ATA+FAT12", c, 19, 12);
    vga_print("    Mikelsoft Corporation INC.", c, 18, 13);
    vga_print("        Press any key...", c, 20, 14);
    keyboard_getchar();
    vga_clear(vga_make_color(VGA_LIGHT_GREY, VGA_BLACK));
}
static void cmd_help(void) {
    uint8_t b = vga_make_color(VGA_BLUE, VGA_BLACK);
    uint8_t t = vga_make_color(VGA_YELLOW, VGA_BLACK);
    uint8_t d = vga_make_color(VGA_LIGHT_GREY, VGA_BLACK);
    vga_draw_box(2, 1, 76, 22, b);
    vga_print("=== NeutrinoOS v0.9.2 commands ===", t, 4, 2);
    const char* lines[] = {
        "FILES     DIR LS CAT CREATE READ DEL RM HEAD TAIL GREP TREE",
        "EDITORS   EDIT FTE WRD",
        "DISK      DISK DF SAVE LOAD FORMAT",
        "SYS       CLEAR CLS ECHO TIME DATE FETCH CPU INSTALL INFO",
        "GRAPHICS  PAINT THEME MANDEL GFXTEST",
        "CLOCKS    TIME CLOCK CLOCKA DATE",
        "GAMES     SNAKE TETRIS PONG MINE HANGMAN",
        "APPS      CALC CALENDAR CLOCK EDIT GUI CHART SHEET",
        "CONFIG    SETTINGS TZ BANNER",
        "SCREENS   SAVER starfield|matrix|bounce|pipes",
        "SOUND     BEEP MELODY [tetris|nokia]",
        "SESSION   LOGON REBOOT [/D] SHUTDOWN",
        "OTHER     AUTOEXEC MOTD PANIC ABOUT HELP",
        "REBOOT /D  restarts in debug mode",
        NULL
    };
    int ly = 4;
    for (int i = 0; lines[i]; i++) vga_print(lines[i], d, 4, ly + i);
    vga_print("Press any key...", vga_make_color(VGA_DARK_GREY, VGA_BLACK), 4, 23);
    keyboard_getchar();
    vga_clear(vga_make_color(VGA_LIGHT_GREY, VGA_BLACK));
}
static void cmd_info(void) {
    config_t* cfg = config_get();
    out_title("=== System Information ===\n");
    out_txt("OS       : NeutrinoOS v0.9.2\n");
    out_txt("Vendor   : Mikelsoft Corporation INC.\n");
    out_txt("Kernel   : C + ASM, protected mode, no IRQs\n");
    out_txt("User     : "); out_txt(cfg->username); out_txt("\n");
    out_txt("Timezone : "); out_txt(cfg->tz_name); out_txt("\n");
    out_txt("Disk     : ");
    out_txt(fat12_is_mounted() ? "FAT12 mounted\n" : "ramdisk\n");
    out_txt("Slow boot: ");
    out_txt(cfg->slowboot ? "on\n" : "off\n");
    out_txt("RAM disk : "); char b[16]; itoa(ramdisk_count(), b, 10); out_txt(b); out_txt(" files\n");
}
static void cmd_panic(int argc, char** argv) {
    if (argc < 2) bsod("PANIC", "Manual kernel panic requested.");
    else bsod(argv[1], "Manual kernel panic requested.");
}
static void cmd_banner(int argc, char** argv) {
    if (argc < 2) {
        out_txt("Banner list:\n");
        for (int i = 0; i < palette_theme_count(); i++) {
            out_txt("  ");
            out_txt(palette_theme_name(i));
            out_txt("\n");
        }
        out_txt("Usage: BANNER <name>\n");
        return;
    }
    int id = palette_find_theme(argv[1]);
    if (id < 0) { out_err("Unknown banner.\n"); return; }
    config_t* cfg = config_get();
    cfg->theme_id = id;
    palette_apply_theme(id);
    config_save_theme();
    out_ok("Banner changed.\n");
}

void shell_execute_line(const char* line) {
    char buf[MAX_CMD_LEN];
    strncpy(buf, line, MAX_CMD_LEN);
    char* argv[8]; int argc = 0;
    char* t = buf;
    while (*t == ' ') t++;
    if (*t == 0) return;
    while (*t && argc < 8) {
        argv[argc++] = t;
        while (*t && *t != ' ') t++;
        if (*t) { *t = 0; t++; }
        while (*t == ' ') t++;
    }
    uint8_t err_fg = vga_make_color(VGA_LIGHT_RED, VGA_BLACK);

    if      (strcasecmp(argv[0], "DIR")==0 || strcasecmp(argv[0], "LS")==0) cmd_dir();
    else if (strcasecmp(argv[0], "CD")==0) cmd_cd(argc, argv);
    else if (strcasecmp(argv[0], "MKDIR")==0) cmd_mkdir(argc, argv);
    else if (strcasecmp(argv[0], "RMDIR")==0) out_err("Not implemented.\n");
    else if (strcasecmp(argv[0], "CAT")==0 || strcasecmp(argv[0], "READ")==0) cmd_cat(argc, argv);
    else if (strcasecmp(argv[0], "HEAD")==0) cmd_head(argc, argv);
    else if (strcasecmp(argv[0], "TAIL")==0) cmd_tail(argc, argv);
    else if (strcasecmp(argv[0], "GREP")==0) cmd_grep(argc, argv);
    else if (strcasecmp(argv[0], "TREE")==0) cmd_tree();
    else if (strcasecmp(argv[0], "CREATE")==0) cmd_create(argc, argv);
    else if (strcasecmp(argv[0], "DEL")==0 || strcasecmp(argv[0], "RM")==0) cmd_delete(argc, argv);
    else if (strcasecmp(argv[0], "ECHO")==0) cmd_echo(argc, argv);
    else if (strcasecmp(argv[0], "CLEAR")==0 || strcasecmp(argv[0], "CLS")==0) vga_clear(vga_make_color(VGA_LIGHT_GREY, VGA_BLACK));
    else if (strcasecmp(argv[0], "TIME")==0) time_show();
    else if (strcasecmp(argv[0], "DATE")==0) date_show();
    else if (strcasecmp(argv[0], "THEME")==0) theme_run();
    else if (strcasecmp(argv[0], "PAINT")==0) paint_run();
    else if (strcasecmp(argv[0], "INSTALL")==0) installer_run();
    else if (strcasecmp(argv[0], "FETCH")==0) fetch_show();
    else if (strcasecmp(argv[0], "CPU")==0) cpu_show();
    else if (strcasecmp(argv[0], "SAVE")==0) cmd_save(argc, argv);
    else if (strcasecmp(argv[0], "LOAD")==0) cmd_load(argc, argv);
    else if (strcasecmp(argv[0], "DISK")==0) cmd_disk();
    else if (strcasecmp(argv[0], "DF")==0) cmd_df();
    else if (strcasecmp(argv[0], "FORMAT")==0) cmd_format(argc, argv);
    else if (strcasecmp(argv[0], "TZ")==0) cmd_tz(argc, argv);
    else if (strcasecmp(argv[0], "LOGON")==0) cmd_logon();
    else if (strcasecmp(argv[0], "REBOOT")==0) {
        if (argc >= 2 && strcasecmp(argv[1], "/D") == 0) {
            if (fat12_is_mounted()) {
                fat12_write_file("DEBUG.FLG", "1\n", 2);
            } else {
                int fd = ramdisk_create("DEBUG.FLG");
                if (fd >= 0) ramdisk_write(fd, "1\n", 2);
            }
            out_txt("Rebooting into debug mode...\n");
        } else {
            out_txt("Rebooting...\n");
            if (fat12_is_mounted()) fat12_delete_file("DEBUG.FLG");
        }
        power_reboot();
    }
    else if (strcasecmp(argv[0], "SHUTDOWN")==0) { out_txt("Shutting down...\n"); power_shutdown(); }
    else if (strcasecmp(argv[0], "ABOUT")==0) cmd_about();
    else if (strcasecmp(argv[0], "INFO")==0) cmd_info();
    else if (strcasecmp(argv[0], "HELP")==0) cmd_help();
    else if (strcasecmp(argv[0], "CALC")==0) calc_run();
    else if (strcasecmp(argv[0], "CALENDAR")==0) calendar_run();
    else if (strcasecmp(argv[0], "CLOCK")==0) clock_run();
    else if (strcasecmp(argv[0], "CLOCKA")==0) clocka_run();
    else if (strcasecmp(argv[0], "MANDEL")==0) mandel_run();
    else if (strcasecmp(argv[0], "GUI")==0) gui_run();
    else if (strcasecmp(argv[0], "EDIT")==0) {
        if (argc < 2) out_err("Usage: EDIT filename\n");
        else editor_run(argv[1]);
    }
    else if (strcasecmp(argv[0], "FTE")==0) {
        if (argc < 2) fte_run("UNTITLED.TXT");
        else fte_run(argv[1]);
    }
    else if (strcasecmp(argv[0], "WRD")==0) {
        if (argc < 2) wrd_run("DOC1.TXT");
        else wrd_run(argv[1]);
    }
    else if (strcasecmp(argv[0], "SNAKE")==0) game_snake();
    else if (strcasecmp(argv[0], "TETRIS")==0) game_tetris();
    else if (strcasecmp(argv[0], "PONG")==0) game_pong();
    else if (strcasecmp(argv[0], "MINE")==0) game_mine();
    else if (strcasecmp(argv[0], "HANGMAN")==0) game_hangman();
    else if (strcasecmp(argv[0], "SAVER")==0) {
        const char* which = argc >= 2 ? argv[1] : "starfield";
        if (strcasecmp(which, "matrix")==0) saver_matrix();
        else if (strcasecmp(which, "bounce")==0) saver_bounce();
        else if (strcasecmp(which, "pipes")==0) saver_pipes();
        else saver_starfield();
    }
    else if (strcasecmp(argv[0], "BEEP")==0) pcspk_click();
    else if (strcasecmp(argv[0], "MELODY")==0) {
        const char* which = argc >= 2 ? argv[1] : "tetris";
        if (strcasecmp(which, "nokia")==0) pcspk_nokia_theme();
        else pcspk_tetris_theme();
    }
    else if (strcasecmp(argv[0], "AUTOEXEC")==0) {
        if (argc >= 2 && strcasecmp(argv[1], "/ed")==0) editor_run("AUTOEXEC.NE");
        else autoexec_run("AUTOEXEC.NE");
    }
    else if (strcasecmp(argv[0], "MOTD")==0) motd_show();
    else if (strcasecmp(argv[0], "BANNER")==0) cmd_banner(argc, argv);
    else if (strcasecmp(argv[0], "CHART")==0) chart_run();
    else if (strcasecmp(argv[0], "SHEET")==0) sheet_run();
    else if (strcasecmp(argv[0], "SETTINGS")==0) settings_run();
    else if (strcasecmp(argv[0], "GFXTEST")==0) gfxtest_run();
    else if (strcasecmp(argv[0], "PANIC")==0) cmd_panic(argc, argv);
    else {
        vga_print_at("Unknown: ", err_fg);
        vga_print_at(argv[0], err_fg);
        vga_print_at(" (try HELP)\n", err_fg);
    }
}

void shell_run(void) {
    config_t* cfg = config_get();
    uint8_t prompt_fg = vga_make_color(VGA_LIGHT_GREEN, VGA_BLACK);
    uint8_t text_fg   = vga_make_color(VGA_LIGHT_GREY, VGA_BLACK);
    uint8_t dim_fg    = vga_make_color(VGA_DARK_GREY, VGA_BLACK);
    uint8_t ok_fg     = vga_make_color(VGA_LIGHT_GREEN, VGA_BLACK);

    vga_clear(vga_make_color(VGA_LIGHT_GREY, VGA_BLACK));
    vga_print("NeutrinoOS v0.9.2", ok_fg, 0, 0);
    vga_print("  Type HELP. Type GUI for Win95 desktop.", dim_fg, 18, 0);
    vga_putchar_at('\n', text_fg);
    vga_putchar_at('\n', text_fg);
    if (fat12_is_mounted()) vga_print("Disk: FAT12 mounted", ok_fg, 0, 3);
    else vga_print("Disk: not detected (ramdisk)", dim_fg, 0, 3);
    vga_putchar_at('\n', text_fg);

    char cmd_buf[MAX_CMD_LEN];

    while (1) {
        char prompt[80]; int p = 0;
        const char* tmpl = cfg->prompt;
        while (*tmpl && p < 78) {
            if (tmpl[0] == '%' && tmpl[1] == 'u') { const char* u = cfg->username; while (*u && p < 78) prompt[p++] = *u++; tmpl += 2; }
            else if (tmpl[0] == '%' && tmpl[1] == 'h') { const char* h = "neutrino"; while (*h && p < 78) prompt[p++] = *h++; tmpl += 2; }
            else if (tmpl[0] == '%' && tmpl[1] == 't') { const char* h = cfg->tz_name; while (*h && p < 78) prompt[p++] = *h++; tmpl += 2; }
            else prompt[p++] = *tmpl++;
        }
        prompt[p] = 0;
        vga_print_at(prompt, prompt_fg);

        int cmd_pos_local = 0;
        int hpos = history_count;
        int menu_requested = 0;
        while (1) {
            int key = keyboard_getchar();
            if (key == KEY_ALT_DEL) { menu_requested = 1; break; }
            if (key == '\n') { vga_putchar_at('\n', text_fg); cmd_buf[cmd_pos_local] = 0; break; }
            else if (key == '\b') {
                if (cmd_pos_local > 0) {
                    cmd_pos_local--;
                    vga_putchar_at('\b', text_fg); vga_putchar_at(' ', text_fg); vga_putchar_at('\b', text_fg);
                }
            }
            else if (key == KEY_TAB_CODE || key == KEY_CTRL_U) autocomplete(cmd_buf, &cmd_pos_local, text_fg);
            else if (key == KEY_CTRL_BKSP) {
                while (cmd_pos_local > 0 && cmd_buf[cmd_pos_local - 1] == ' ') {
                    cmd_pos_local--;
                    vga_putchar_at('\b', text_fg); vga_putchar_at(' ', text_fg); vga_putchar_at('\b', text_fg);
                }
                while (cmd_pos_local > 0 && cmd_buf[cmd_pos_local - 1] != ' ') {
                    cmd_pos_local--;
                    vga_putchar_at('\b', text_fg); vga_putchar_at(' ', text_fg); vga_putchar_at('\b', text_fg);
                }
            }
            else if (key == -KEY_UP) {
                if (hpos > 0) {
                    hpos--;
                    for (int i = 0; i < cmd_pos_local; i++) { vga_putchar_at('\b', text_fg); vga_putchar_at(' ', text_fg); vga_putchar_at('\b', text_fg); }
                    strncpy(cmd_buf, history[hpos], MAX_CMD_LEN);
                    cmd_pos_local = strlen(cmd_buf);
                    for (int i = 0; i < cmd_pos_local; i++) vga_putchar_at(cmd_buf[i], text_fg);
                }
            }
            else if (key == -KEY_DOWN) {
                if (hpos < history_count) {
                    hpos++;
                    for (int i = 0; i < cmd_pos_local; i++) { vga_putchar_at('\b', text_fg); vga_putchar_at(' ', text_fg); vga_putchar_at('\b', text_fg); }
                    if (hpos == history_count) cmd_pos_local = 0;
                    else {
                        strncpy(cmd_buf, history[hpos], MAX_CMD_LEN);
                        cmd_pos_local = strlen(cmd_buf);
                        for (int i = 0; i < cmd_pos_local; i++) vga_putchar_at(cmd_buf[i], text_fg);
                    }
                }
            }
            else if (key > 0 && key < 128 && cmd_pos_local < MAX_CMD_LEN - 1) {
                cmd_buf[cmd_pos_local++] = (char)key;
                vga_putchar_at((char)key, text_fg);
            }
        }
        if (menu_requested) { sysmenu_run(); continue; }
        if (cmd_pos_local == 0) continue;
        history_push(cmd_buf);
        shell_execute_line(cmd_buf);
    }
}
