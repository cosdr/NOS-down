#include "fetch.h"
#include "vga.h"
#include "keyboard.h"
#include "cpu.h"
#include "config.h"
#include "fat12.h"
#include "utils.h"

static int  total_ram_mb = 0;
static char version[32] = "v0.9.2";

void fetch_set_ram(int mb) { total_ram_mb = mb; }
void fetch_set_version(const char* ver) {
    int i;
    for (i = 0; ver[i] && i < 31; i++) version[i] = ver[i];
    version[i] = 0;
}
void fetch_show(void) {
    uint8_t logo_fg    = vga_make_color(VGA_LIGHT_CYAN, VGA_BLACK);
    uint8_t label_fg   = vga_make_color(VGA_LIGHT_BLUE, VGA_BLACK);
    uint8_t value_fg   = vga_make_color(VGA_WHITE, VGA_BLACK);
    uint8_t title_fg   = vga_make_color(VGA_LIGHT_GREEN, VGA_BLACK);
    uint8_t accent_fg  = vga_make_color(VGA_LIGHT_MAGENTA, VGA_BLACK);
    uint8_t dim_fg     = vga_make_color(VGA_DARK_GREY, VGA_BLACK);
    config_t* cfg = config_get();
    const char* logo[] = {
        "   _   _      _        _ _             ___  ___ ",
        "  | \\ | | ___| |_ _ __(_) |_ _____   _/ _ \\/ ___|",
        "  |  \\| |/ _ \\ __| '__| | __|_  / | | | | | \\___ \\",
        "  | |\\  |  __/ |_| |  | | |_ / /| |_| | |_| |___) |",
        "  |_| \\_|\\___|\\__|_|  |_|\\__/___|\\__,_|\\___/|____/",
        NULL
    };
    vga_clear(vga_make_color(VGA_BLACK, VGA_BLACK));
    for (int i = 0; logo[i]; i++) vga_print(logo[i], logo_fg, 2, 1 + i);
    for (int y = 1; y < 23; y++) vga_putchar(179, logo_fg, 42, y);
    vga_print("NeutrinoOS", title_fg, 45, 2);
    for (int x = 45; x < 75; x++) vga_putchar(196, accent_fg, x, 3);
    int line = 5;
    char buf[64];
    vga_print("User", label_fg, 45, line); vga_print(": ", value_fg, 56, line); vga_print(cfg->username, value_fg, 58, line); line++;
    vga_print("Version", label_fg, 45, line); vga_print(": ", value_fg, 56, line); vga_print(version, value_fg, 58, line); line++;
    char brand[64];
    if (cpu_get_brand(brand, sizeof(brand)) > 0) {
        if (strlen(brand) > 24) brand[24] = 0;
        vga_print("CPU", label_fg, 45, line); vga_print(": ", value_fg, 56, line); vga_print(brand, value_fg, 58, line); line++;
    }
    vga_print("Timezone", label_fg, 45, line); vga_print(": ", value_fg, 56, line); vga_print(cfg->tz_name, value_fg, 58, line); line++;
    vga_print("Video", label_fg, 45, line); vga_print(": ", value_fg, 56, line);
    const char* vm[] = { "VGA AmTREND 16", "VGA NVID 256", "VGA MikSoft 128" };
    vga_print(vm[cfg->videomode >= 0 && cfg->videomode < 3 ? cfg->videomode : 0], value_fg, 58, line); line++;
    vga_print("RAM", label_fg, 45, line); vga_print(": ", value_fg, 56, line);
    if (total_ram_mb > 0) { itoa(total_ram_mb, buf, 10); vga_print(buf, value_fg, 58, line); vga_print(" MB", value_fg, 58 + strlen(buf), line); }
    else vga_print("Unknown", value_fg, 58, line);
    line++;
    vga_print("Disk", label_fg, 45, line); vga_print(": ", value_fg, 56, line);
    vga_print(fat12_is_mounted() ? "FAT12 mounted" : "not detected",
              fat12_is_mounted() ? vga_make_color(VGA_LIGHT_GREEN, VGA_BLACK) : dim_fg, 58, line);
    line++;
    vga_print("FS", label_fg, 45, line); vga_print(": ramdisk + FAT12", value_fg, 56, line); line++;
    vga_print("Arch", label_fg, 45, line); vga_print(": i386", value_fg, 56, line); line += 2;
    vga_print("Colours:", label_fg, 45, line); line++;
    const char* cn[] = { "BLK","BLU","GRN","CYN","RED","MAG","BRN","LGY","DGY","LBL","LGR","LCY","LRD","LMG","YEL","WHT" };
    for (int i = 0; i < 16; i++) { uint8_t c = vga_make_color((uint8_t)i, VGA_BLACK); vga_print(cn[i], c, 45 + i * 3, line); }
    line++;
    for (int i = 0; i < 16; i++) { uint8_t c = vga_make_color(VGA_BLACK, (uint8_t)i); vga_print("   ", c, 45 + i * 3, line); }
    line++;
    for (int i = 0; i < 16; i++) { uint8_t c = vga_make_color((uint8_t)i, (uint8_t)i); vga_print("###", c, 45 + i * 3, line); }
    line += 2;
    vga_print("\"Light as a neutrino,", dim_fg, 45, line);
    vga_print("   fast as light.\"",    dim_fg, 45, line + 1);
    vga_print("Press any key...", dim_fg, 2, 24);
    keyboard_getchar();
    vga_clear(vga_make_color(VGA_LIGHT_GREY, VGA_BLACK));
}
