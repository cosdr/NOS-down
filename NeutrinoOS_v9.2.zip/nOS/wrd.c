#include "wrd.h"
#include "vga.h"
#include "keyboard.h"
#include "fat12.h"
#include "ramdisk.h"
#include "utils.h"

#define WRD_MAX_LINES 300
#define WRD_WIDTH     78
#define WRD_MAX_LINE  200

static char lines[WRD_MAX_LINES][WRD_MAX_LINE + 1];
static int  line_count = 1;
static int  cx = 0, cy = 0, scroll = 0, dirty = 0;
static char doc_name[64];

static int word_count(void) {
    int words = 0;
    for (int i = 0; i < line_count; i++) {
        const char* s = lines[i];
        int in_word = 0;
        while (*s) {
            int is_space = (*s == ' ' || *s == '\t' || *s == '\n');
            if (!is_space && !in_word) { in_word = 1; words++; }
            else if (is_space) in_word = 0;
            s++;
        }
    }
    return words;
}

static int wrd_load(const char* name) {
    static char tmp[16384];
    int n = -1;
    if (fat12_is_mounted()) n = fat12_read_file(name, tmp, sizeof(tmp) - 1);
    if (n < 0) {
        int fd = ramdisk_get_fd(name);
        if (fd >= 0) n = ramdisk_read(fd, tmp, sizeof(tmp) - 1);
    }
    if (n < 0) return -1;
    tmp[n] = 0;

    line_count = 1;
    for (int i = 0; i < WRD_MAX_LINES; i++) lines[i][0] = 0;
    int pos = 0, lc = 0, lp = 0;
    while (tmp[pos] && lc < WRD_MAX_LINES) {
        if (tmp[pos] == '\n') { lines[lc][lp] = 0; lc++; lp = 0; }
        else if (lp < WRD_MAX_LINE) lines[lc][lp++] = tmp[pos];
        pos++;
    }
    if (lp > 0) lines[lc][lp] = 0;
    line_count = lc + 1;
    if (line_count < 1) line_count = 1;
    return 0;
}

static void wrd_save(const char* name) {
    static char out[16384];
    int pos = 0;
    for (int i = 0; i < line_count; i++) {
        int j = 0;
        while (lines[i][j] && pos < 16383) out[pos++] = lines[i][j++];
        if (pos < 16383) out[pos++] = '\n';
    }
    out[pos] = 0;
    if (fat12_is_mounted()) fat12_write_file(name, out, pos);
    int fd = ramdisk_create(name);
    if (fd >= 0) ramdisk_write(fd, out, pos);
    dirty = 0;
}

static void draw_styled_line(const char* s, int x0, int y) {
    int x = x0;
    int bold = 0, italic = 0;
    while (*s) {
        if (s[0] == '*' && s[1] == '*') { bold = !bold; s += 2; continue; }
        if (s[0] == '_' && s[1] == '_') { italic = !italic; s += 2; continue; }
        uint8_t fg = VGA_LIGHT_GREY;
        uint8_t bg = VGA_BLACK;
        if (bold)   fg = VGA_WHITE;
        if (italic) fg = VGA_LIGHT_CYAN;
        vga_putcell(x, y, *s, fg, bg);
        x++;
        s++;
    }
}

static void wrd_draw(void) {
    uint8_t title_fg = vga_make_color(VGA_BLACK, VGA_LIGHT_GREY);
    uint8_t border   = vga_make_color(VGA_LIGHT_CYAN, VGA_BLACK);
    uint8_t status_fg = vga_make_color(VGA_BLACK, VGA_LIGHT_GREY);

    vga_clear(vga_make_color(VGA_LIGHT_GREY, VGA_BLACK));
    for (int i = 0; i < 80; i++) vga_putcell(i, 0, ' ', title_fg, VGA_LIGHT_GREY);
    vga_print("WRD", title_fg, 2, 0);
    vga_print(doc_name, title_fg, 7, 0);
    if (dirty) vga_print("[modified]", title_fg, 65, 0);

    for (int i = 0; i < 22; i++) {
        int li = scroll + i;
        if (li >= line_count) break;
        draw_styled_line(lines[li], 2, 1 + i);
    }
    for (int x = 1; x < 79; x++) {
        vga_putcell(x, 1, 196, border, VGA_BLACK);
        vga_putcell(x, 22, 196, border, VGA_BLACK);
    }
    for (int y = 1; y < 23; y++) {
        vga_putcell(1, y, 179, border, VGA_BLACK);
        vga_putcell(78, y, 179, border, VGA_BLACK);
    }

    for (int x = 0; x < 80; x++) vga_putcell(x, 24, ' ', status_fg, VGA_LIGHT_GREY);
    char sb[64]; int p = 0;
    const char* h = "F1 Save  F5 Center  ESC Quit  Words: ";
    while (*h) sb[p++] = *h++;
    char num[8]; itoa(word_count(), num, 10);
    for (int i = 0; num[i]; i++) sb[p++] = num[i];
    sb[p] = 0;
    vga_print(sb, status_fg, 0, 24);

    int sy = 1 + (cy - scroll);
    if (sy >= 1 && sy < 23) vga_set_cursor(2 + cx, sy);
}

static void centre_paragraph(void) {
    int start = cy;
    while (start > 0 && lines[start - 1][0] != 0) start--;
    int end = cy;
    while (end < line_count - 1 && lines[end + 1][0] != 0) end++;

    static char merged[WRD_MAX_LINE + 1];
    int mp = 0;
    for (int i = start; i <= end; i++) {
        if (mp > 0 && mp < WRD_MAX_LINE) merged[mp++] = ' ';
        int j = 0;
        while (lines[i][j] && mp < WRD_MAX_LINE) merged[mp++] = lines[i][j++];
    }
    merged[mp] = 0;

    int len = mp;
    int pad = (WRD_WIDTH - len) / 2;
    if (pad < 0) pad = 0;

    for (int i = start; i <= end; i++) lines[i][0] = 0;
    int j = 0;
    for (int i = 0; i < pad; i++) lines[start][j++] = ' ';
    int k = 0;
    while (merged[k] && j < WRD_MAX_LINE) lines[start][j++] = merged[k++];
    lines[start][j] = 0;
    cy = start;
    dirty = 1;
}

void wrd_run(const char* filename) {
    for (int i = 0; i < WRD_MAX_LINES; i++) lines[i][0] = 0;
    strncpy(doc_name, filename, sizeof(doc_name) - 1);
    doc_name[sizeof(doc_name) - 1] = 0;

    if (wrd_load(doc_name) < 0) { line_count = 1; dirty = 0; }
    cx = 0; cy = 0; scroll = 0;

    int running = 1;
    while (running) {
        wrd_draw();
        int key = keyboard_getchar();
        if (key == -KEY_ESC) {
            if (dirty) {
                wrd_save(doc_name);
            }
            running = 0;
        }
        else if (key == -KEY_F1) { wrd_save(doc_name); }
        else if (key == -KEY_F5) { centre_paragraph(); }
        else if (key == -KEY_UP && cy > 0) {
            cy--;
            if (cx > (int)strlen(lines[cy])) cx = (int)strlen(lines[cy]);
        }
        else if (key == -KEY_DOWN) {
            if (cy < line_count - 1) cy++;
            else if (line_count < WRD_MAX_LINES) { line_count++; lines[cy + 1][0] = 0; cy++; }
        }
        else if (key == -KEY_LEFT && cx > 0) cx--;
        else if (key == -KEY_RIGHT && cx < (int)strlen(lines[cy])) cx++;
        else if (key == '\b' && cx > 0) {
            int len = (int)strlen(lines[cy]);
            for (int i = cx - 1; i < len; i++) lines[cy][i] = lines[cy][i + 1];
            cx--; dirty = 1;
        }
        else if (key == '\n') {
            if (line_count < WRD_MAX_LINES) {
                for (int i = line_count; i > cy + 1; i--) strcpy(lines[i], lines[i - 1]);
                int len = (int)strlen(lines[cy]);
                int j = 0;
                for (int i = cx; i <= len; i++) lines[cy + 1][j++] = lines[cy][i];
                lines[cy][cx] = 0;
                line_count++; cy++; cx = 0; dirty = 1;
            }
        }
        else if (key > 0 && key < 128) {
            int len = (int)strlen(lines[cy]);
            if (len < WRD_MAX_LINE) {
                for (int i = len; i >= cx; i--) lines[cy][i + 1] = lines[cy][i];
                lines[cy][cx] = (char)key;
                cx++; dirty = 1;
            }
        }
        if (cy < scroll) scroll = cy;
        if (cy >= scroll + 21) scroll = cy - 20;
    }
    vga_set_cursor(0, 0);
    vga_clear(vga_make_color(VGA_LIGHT_GREY, VGA_BLACK));
}
