#ifndef PCSPK_H
#define PCSPK_H

void pcspk_beep(int freq, int duration_ms);
void pcspk_stop(void);
void pcspk_boot(void);
void pcspk_error(void);
void pcspk_click(void);
void pcspk_tetris_theme(void);
void pcspk_nokia_theme(void);
void pcspk_play_melody(const int* notes, const int* durations, int count);

#endif
