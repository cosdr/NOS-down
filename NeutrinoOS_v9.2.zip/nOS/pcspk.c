#include "pcspk.h"
#include "utils.h"
#include "keyboard.h"

#define PIT_FREQ 1193180

void pcspk_stop(void) { uint8_t tmp = inb(0x61); outb(0x61, tmp & 0xFC); }
void pcspk_beep(int freq, int duration_ms) {
    if (freq <= 0) { pcspk_stop(); delay(duration_ms * 100); return; }
    uint32_t div = PIT_FREQ / freq;
    outb(0x43, 0xB6);
    outb(0x42, (uint8_t)(div & 0xFF));
    outb(0x42, (uint8_t)((div >> 8) & 0xFF));
    uint8_t tmp = inb(0x61);
    outb(0x61, tmp | 3);
    for (volatile int i = 0; i < duration_ms * 500; i++)
        for (volatile int j = 0; j < 100; j++) { }
    pcspk_stop();
}
void pcspk_boot(void) { pcspk_beep(523, 120); pcspk_beep(659, 120); pcspk_beep(784, 200); }
void pcspk_error(void) { pcspk_beep(220, 250); }
void pcspk_click(void) { uint8_t tmp = inb(0x61); outb(0x61, tmp | 3); for (volatile int i = 0; i < 2000; i++) { } pcspk_stop(); }
void pcspk_tetris_theme(void) {
    int n[] = { 659, 494, 523, 587, 523, 494, 440, 440, 523, 659, 587, 523, 494, 494, 523, 587, 659, 523, 440, 440 };
    int d[] = { 200, 100, 100, 200, 100, 100, 200, 100, 100, 200, 100, 100, 200, 100, 100, 200, 100, 200, 100, 400 };
    for (int i = 0; i < 20; i++) pcspk_beep(n[i], d[i]);
}
void pcspk_nokia_theme(void) {
    int n[] = { 659, 587, 369, 415, 554, 494, 369, 415, 587, 659, 739, 831 };
    int d[] = { 150, 150, 300, 300, 150, 150, 300, 300, 150, 150, 300, 500 };
    for (int i = 0; i < 12; i++) pcspk_beep(n[i], d[i]);
}
void pcspk_play_melody(const int* n, const int* d, int c) { for (int i = 0; i < c; i++) pcspk_beep(n[i], d[i]); }
