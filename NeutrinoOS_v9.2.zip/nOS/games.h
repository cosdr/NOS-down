#ifndef GAMES_H
#define GAMES_H

void game_snake(void);
void game_tetris(void);
void game_pong(void);
void game_mine(void);
void game_hangman(void);

#endif
