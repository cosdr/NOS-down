#include "calendar.h"
#include "vga.h"
#include "keyboard.h"
#include "rtc.h"
#include "config.h"
#include "utils.h"

static int days_in_month(int m, int y) {
    int dim[] = {31,28,31,30,31,30,31,31,30,31,30,31};
    if (m == 2 && ((y % 4 == 0 && y % 100 != 0) || (y % 400 == 0))) return 29;
    return dim[m - 1];
}
static int day_of_week(int d, int m, int y) {
    if (m < 3) { m += 12; y--; }
    int k = y % 100, j = y / 100;
    return (d + 13*(m+1)/5 + k + k/4 + j/4 + 5*j) % 7;
}
void calendar_run(void) {
    config_t* cfg = config_get();
    rtc_time_t t;
    rtc_get_local(&t, cfg->tz_offset);
    int year = t.year, month = t.month;
    uint8_t border  = vga_make_color(VGA_BLUE, VGA_BLACK);
    uint8_t title   = vga_make_color(VGA_LIGHT_CYAN, VGA_BLACK);
    uint8_t header  = vga_make_color(VGA_YELLOW, VGA_BLACK);
    uint8_t normal  = vga_make_color(VGA_LIGHT_GREY, VGA_BLACK);
    uint8_t today_c = vga_make_color(VGA_BLACK, VGA_LIGHT_GREEN);
    uint8_t hint    = vga_make_color(VGA_DARK_GREY, VGA_BLACK);
    const char* months[] = {"January","February","March","April","May","June",
                            "July","August","September","October","November","December"};
    while (1) {
        vga_clear(vga_make_color(VGA_LIGHT_GREY, VGA_BLACK));
        vga_draw_box(20, 2, 40, 20, border);
        char title_buf[40];
        int p = 0;
        const char* mn = months[month - 1];
        while (*mn) title_buf[p++] = *mn++;
        title_buf[p++] = ' ';
        char yb[8]; itoa(year, yb, 10);
        for (int i = 0; yb[i]; i++) title_buf[p++] = yb[i];
        title_buf[p] = 0;
        vga_print(title_buf, title, 34, 4);
        vga_print("Mo Tu We Th Fr Sa Su", header, 22, 6);
        int first_dow = day_of_week(1, month, year);
        int mon_first = (first_dow + 5) % 7;
        int total_days = days_in_month(month, year);
        int row = 8, col = 22 + mon_first * 3;
        for (int d = 1; d <= total_days; d++) {
            char db[4]; itoa(d, db, 10);
            int is_today = (d == t.day && month == t.month && year == t.year);
            if (is_today) {
                vga_print(db, today_c, col, row);
                if (db[1] == 0) vga_putchar(' ', today_c, col + 1, row);
            } else {
                if (db[1] == 0) { vga_putchar(' ', normal, col, row); vga_print(db, normal, col + 1, row); }
                else vga_print(db, normal, col, row);
            }
            col += 3;
            if (col > 40) { col = 22; row++; if (row > 20) break; }
        }
        vga_print("LEFT/RIGHT = month, UP/DOWN = year, ESC = exit", hint, 12, 23);
        int key = keyboard_getchar();
        if (key == -KEY_ESC) break;
        else if (key == -KEY_LEFT)  { if (--month < 1)  { month = 12; year--; } }
        else if (key == -KEY_RIGHT) { if (++month > 12) { month = 1;  year++; } }
        else if (key == -KEY_DOWN)  year--;
        else if (key == -KEY_UP)    year++;
    }
    vga_clear(vga_make_color(VGA_LIGHT_GREY, VGA_BLACK));
}
