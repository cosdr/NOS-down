#ifndef BSOD_H
#define BSOD_H

void bsod(const char* title, const char* message);

#endif
