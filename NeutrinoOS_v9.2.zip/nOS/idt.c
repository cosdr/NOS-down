#include "idt.h"
#include "vga.h"
#include "keyboard.h"
#include "bsod.h"
#include "utils.h"

typedef struct {
    uint16_t offset_low;
    uint16_t selector;
    uint8_t  zero;
    uint8_t  type_attr;
    uint16_t offset_high;
} __attribute__((packed)) idt_entry_t;

typedef struct {
    uint16_t limit;
    uint32_t base;
} __attribute__((packed)) idt_ptr_t;

static idt_entry_t idt[256];
static idt_ptr_t   idtp;

extern void isr0(void);
extern void isr1(void);
extern void isr6(void);
extern void isr8(void);
extern void isr13(void);
extern void isr14(void);
extern void idt_load(uint32_t idtp_addr);

static void idt_set_gate(int n, uint32_t handler, uint16_t sel, uint8_t flags) {
    idt[n].offset_low  = (uint16_t)(handler & 0xFFFF);
    idt[n].offset_high = (uint16_t)((handler >> 16) & 0xFFFF);
    idt[n].selector    = sel;
    idt[n].zero        = 0;
    idt[n].type_attr   = flags;
}

void idt_init(void) {
    idtp.limit = (uint16_t)(sizeof(idt_entry_t) * 256 - 1);
    idtp.base  = (uint32_t)&idt;

    for (int i = 0; i < 256; i++) idt_set_gate(i, 0, 0, 0);

    idt_set_gate(0,  (uint32_t)isr0,  0x08, 0x8E);
    idt_set_gate(1,  (uint32_t)isr1,  0x08, 0x8E);
    idt_set_gate(6,  (uint32_t)isr6,  0x08, 0x8E);
    idt_set_gate(8,  (uint32_t)isr8,  0x08, 0x8E);
    idt_set_gate(13, (uint32_t)isr13, 0x08, 0x8E);
    idt_set_gate(14, (uint32_t)isr14, 0x08, 0x8E);

    idt_load((uint32_t)&idtp);
}

void isr_handler(uint32_t int_no, uint32_t err_code) {
    (void)err_code;
    __asm__ volatile("cli");
    char num[8]; itoa((int)int_no, num, 10);
    switch (int_no) {
        case 0:  bsod("Exception 0x00", "Divide Error (#DE)"); break;
        case 1:  bsod("Exception 0x01", "Debug (#DB)"); break;
        case 6:  bsod("Exception 0x06", "Invalid Opcode (#UD)"); break;
        case 8:  bsod("Exception 0x08", "Double Fault (#DF)"); break;
        case 13: bsod("Exception 0x0D", "General Protection Fault (#GP)"); break;
        case 14: bsod("Exception 0x0E", "Page Fault (#PF)"); break;
        default: bsod("Exception", num); break;
    }
}
