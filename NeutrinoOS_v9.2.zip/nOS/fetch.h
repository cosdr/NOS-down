#ifndef FETCH_H
#define FETCH_H

void fetch_show(void);
void fetch_set_ram(int mb);
void fetch_set_version(const char* ver);

#endif
