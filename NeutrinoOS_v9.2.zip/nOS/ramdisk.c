#include "ramdisk.h"
#include "utils.h"

static ramdisk_file_t files[RAMDISK_MAX_FILES];

void ramdisk_init(void) {
    for (int i = 0; i < RAMDISK_MAX_FILES; i++) { files[i].used = 0; files[i].size = 0; files[i].name[0] = 0; }
}
int ramdisk_create(const char* name) {
    for (int i = 0; i < RAMDISK_MAX_FILES; i++)
        if (files[i].used && strcasecmp(files[i].name, name) == 0) { files[i].size = 0; return i; }
    for (int i = 0; i < RAMDISK_MAX_FILES; i++) {
        if (!files[i].used) {
            files[i].used = 1; files[i].size = 0;
            strncpy(files[i].name, name, RAMDISK_MAX_FILENAME);
            return i;
        }
    }
    return -1;
}
int ramdisk_write(int fd, const char* data, int size) {
    if (fd < 0 || fd >= RAMDISK_MAX_FILES || !files[fd].used) return -1;
    if (size > RAMDISK_MAX_FILESIZE) size = RAMDISK_MAX_FILESIZE;
    for (int i = 0; i < size; i++) files[fd].data[i] = data[i];
    files[fd].size = size;
    return size;
}
int ramdisk_read(int fd, char* buffer, int max_size) {
    if (fd < 0 || fd >= RAMDISK_MAX_FILES || !files[fd].used) return -1;
    int size = files[fd].size;
    if (size > max_size) size = max_size;
    for (int i = 0; i < size; i++) buffer[i] = files[fd].data[i];
    return size;
}
int ramdisk_list(char* buffer, int max_size) {
    int pos = 0;
    for (int i = 0; i < RAMDISK_MAX_FILES; i++) {
        if (files[i].used) {
            int j = 0;
            while (files[i].name[j] && pos < max_size - 1) buffer[pos++] = files[i].name[j++];
            if (pos < max_size - 15) {
                buffer[pos++] = ' '; buffer[pos++] = '(';
                int sz = files[i].size;
                if (sz == 0) buffer[pos++] = '0';
                else {
                    char tmp[10]; int tp = 0;
                    while (sz > 0) { tmp[tp++] = (char)('0' + (sz % 10)); sz /= 10; }
                    while (tp > 0) buffer[pos++] = tmp[--tp];
                }
                buffer[pos++] = 'B'; buffer[pos++] = ')';
            }
            if (pos < max_size - 1) buffer[pos++] = '\n';
        }
    }
    if (pos > 0 && buffer[pos-1] == '\n') pos--;
    buffer[pos] = 0;
    return pos;
}
int ramdisk_delete(const char* name) {
    for (int i = 0; i < RAMDISK_MAX_FILES; i++)
        if (files[i].used && strcasecmp(files[i].name, name) == 0) { files[i].used = 0; return 0; }
    return -1;
}
int ramdisk_exists(const char* name) {
    for (int i = 0; i < RAMDISK_MAX_FILES; i++)
        if (files[i].used && strcasecmp(files[i].name, name) == 0) return 1;
    return 0;
}
int ramdisk_get_fd(const char* name) {
    for (int i = 0; i < RAMDISK_MAX_FILES; i++)
        if (files[i].used && strcasecmp(files[i].name, name) == 0) return i;
    return -1;
}
int ramdisk_count(void) { int c = 0; for (int i = 0; i < RAMDISK_MAX_FILES; i++) if (files[i].used) c++; return c; }
const ramdisk_file_t* ramdisk_get_entry(int index) {
    int c = 0;
    for (int i = 0; i < RAMDISK_MAX_FILES; i++)
        if (files[i].used) { if (c == index) return &files[i]; c++; }
    return NULL;
}
const char* ramdisk_get_name(int index) {
    const ramdisk_file_t* e = ramdisk_get_entry(index);
    return e ? e->name : NULL;
}
