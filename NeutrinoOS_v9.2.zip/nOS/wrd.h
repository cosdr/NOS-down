#ifndef WRD_H
#define WRD_H

void wrd_run(const char* filename);

#endif
