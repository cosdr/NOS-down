# NeutrinoOS v0.9.2

**Mikelsoft Corporation INC.** — *Light as a neutrino, fast as light*

Self-written 32-bit x86 OS. Protected mode, polling I/O (no IRQs), custom kernel in C + NASM. GRUB multiboot.

## What's new in v0.9.2

- **Win95-style GUI** with overlapping windows, taskbar, Start menu, submenus, dialogs
- **Pseudo-mouse** — control a visible cursor with arrow keys, click with `[` (LKM) and `]` (PKM)
- **Window manager** (`wm.c/h`) — z-order, focus, close buttons, save/restore via full redraw
- **Mouse driver** (`mouse.c/h`) — cursor position, click events, glyph rendering
- Rewritten `build.sh` with `--clean`, `--run`, `--test` flags and better diagnostics
- All v0.9.1 features retained (working Shift, Alt+Del, GUI navigation, `REBOOT /D`, `SLOWBOOT`)

## Controls in GUI

| Key | Action |
|---|---|
| Arrows | Move cursor |
| `[` | Left click at cursor |
| `]` | Right click at cursor |
| `Alt+Del` | Toggle Start menu |
| `Tab` | Cycle window focus |
| `Esc` | Close menu / close focused window |
| Type digits | Type into focused Calculator |

## Build

```bash
sudo apt install gcc-multilib nasm xorriso mtools dosfstools grub-pc-bin grub-common qemu-system-x86
./build.sh              # full build: kernel + disk.img + neutrino.iso
./build.sh --clean      # clean build artifacts only
./build.sh --run        # build + launch QEMU
./build.sh --test       # build + headless QEMU smoke test (5s)
```

## Run

```
./run.sh
```

QEMU with 32 MB RAM, bootable ISO, persistent `disk.img` (8 MB FAT12).

## Project layout

- **Boot**: `boot.asm`, `linker.ld`
- **Kernel**: `kernel.c`, `idt.c`, `idt_asm.asm`, `bsod.c`
- **Drivers**: `vga.c` (text + Mode 13h), `keyboard.c`, `rtc.c`, `ata.c`, `pcspk.c`, `cpu.c`, `mouse.c`
- **Filesystem**: `fat12.c`, `ramdisk.c`
- **Config**: `config.c` (persistent files on disk)
- **GUI**: `gui.c` (Win95 desktop), `wm.c` (window manager), `mouse.c` (pseudo-mouse)
- **Apps**: `shell.c`, `fte.c`, `wrd.c`, `calc.c`, `calendar.c`, `clock.c`, `chart.c`, `sheet.c`, `settings.c`, `paint.c`, `mandel.c`, `games.c`, `screensaver.c`, `gfxtest.c`
- **Installer**: `installer.c`, `login.c`, `sysmenu.c`
- **Data files** on disk: `FIRST_B.CFG`, `THEME.CFG`, `TIMEZONE.CFG`, `USER.CFG`, `PASSWORD.CFG`, `SUPASS.CFG`, `AUTOLOGIN.CFG`, `VIDEOMODE.CFG`, `SCREENSAVER.CFG`, `SLOWBOOT.CFG`, `PROMPT.CFG`, `AUTOEXEC.NE`, `MOTD.TXT`

## Known limitations

- No real PS/2 mouse (pseudo-mouse only — arrows + `[` / `]`)
- No IRQs — everything is polling
- No paging, ring 0 only, single address space
- FAT12 (no subdirectories, no LFN yet — planned for v0.11)
- No network, no USB, no audio beyond PC speaker
- BIOS/legacy only (no UEFI)

## License

MIT

</BDS:create_file>

<BDS:create_file fileName="nOS/build.sh">

```bash
#!/bin/bash
# NeutrinoOS v0.9.2 — build script
# Mikelsoft Corporation INC.
set -e

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m';  BOLD='\033[1m';   NC='\033[0m'

info()  { echo -e "${CYAN}[ INFO ]${NC} $1"; }
ok()    { echo -e "${GREEN}[  OK  ]${NC} $1"; }
warn()  { echo -e "${YELLOW}[ WARN ]${NC} $1"; }
fail()  { echo -e "${RED}[ FAIL ]${NC} $1"; exit 1; }
banner(){ echo -e "${BOLD}${GREEN}=== $1 ===${NC}"; }

VERSION="0.9.2"
KERNEL="kernel.bin"
ISO="neutrino.iso"
DISK="disk.img"
DISK_MB=8

DO_CLEAN=0
DO_RUN=0
DO_TEST=0

for arg in "$@"; do
    case "$arg" in
        --clean)  DO_CLEAN=1 ;;
        --run)    DO_RUN=1 ;;
        --test)   DO_TEST=1 ;;
        -h|--help)
            echo "Usage: $0 [--clean] [--run] [--test]"
            echo "  --clean   remove build artifacts and exit"
            echo "  --run     build then launch QEMU"
            echo "  --test    build then run headless QEMU smoke test (5s)"
            exit 0
            ;;
        *) warn "Unknown option: $arg" ;;
    esac
done

cd "$(dirname "$0")"

# --clean early exit
if [ "$DO_CLEAN" = "1" ]; then
    banner "Cleaning"
    rm -rf iso/
    rm -f  *.o "$KERNEL" "$ISO" "$DISK" DEBUG.FLG
    ok "Cleaned"
    exit 0
fi

# ---------------------------------------------------------------
banner "Checking toolchain"
MISSING=""
for tool in gcc nasm ld make dd mkfs.fat mcopy mmd grub-mkrescue; do
    if ! command -v "$tool" >/dev/null 2>&1; then
        MISSING="$MISSING $tool"
    fi
done
if [ -n "$MISSING" ]; then
    fail "Missing tools:$MISSING"
    echo "  Debian/Ubuntu: sudo apt install gcc-multilib nasm xorriso mtools dosfstools grub-pc-bin grub-common"
    echo "  Arch:          sudo pacman -S gcc nasm xorriso mtools dosfstools grub"
    echo "  Fedora:        sudo dnf install gcc nasm xorriso mtools dosfstools grub2-tools"
    exit 1
fi
ok "All tools present"

# ---------------------------------------------------------------
banner "Compiling kernel"
make clean >/dev/null 2>&1 || true
if ! make 2>&1 | tee /tmp/nOS_build.log; then
    fail "Compilation failed — see /tmp/nOS_build.log"
fi
[ -f "$KERNEL" ] || fail "$KERNEL not built"
ok "Kernel compiled ($(stat -c%s "$KERNEL") bytes)"

# ---------------------------------------------------------------
banner "Preparing ISO tree"
rm -rf iso
mkdir -p iso/boot/grub
cp "$KERNEL" iso/boot/kernel.bin
cat > iso/boot/grub/grub.cfg <<EOF
set timeout=0
set default=0
menuentry "NeutrinoOS v${VERSION}" {
    multiboot /boot/kernel.bin
    boot
}
EOF
ok "ISO tree ready"

# ---------------------------------------------------------------
banner "Building ISO"
rm -f "$ISO"
if ! grub-mkrescue -o "$ISO" iso >/dev/null 2>&1; then
    fail "grub-mkrescue failed"
fi
ok "$ISO built ($(stat -c%s "$ISO") bytes)"

# ---------------------------------------------------------------
banner "Creating $DISK (${DISK_MB} MB FAT12)"
rm -f "$DISK"
dd if=/dev/zero of="$DISK" bs=1M count="$DISK_MB" status=none
if ! mkfs.fat -F 12 -s 16 -r 512 -n "NEUTRINO" "$DISK" >/dev/null 2>&1; then
    mkfs.fat -n "NEUTRINO" "$DISK" >/dev/null 2>&1 || fail "mkfs.fat failed"
fi
[ -s "$DISK" ] || fail "$DISK creation failed"
ok "$DISK created"

# ---------------------------------------------------------------
banner "Prepopulating disk"
mkdir -p disk_content

cat > disk_content/README.TXT <<'EOF'
NeutrinoOS v0.9.2 persistent disk.
Files here survive reboots. Use SAVE / LOAD commands.
EOF

cat > disk_content/THEME.CFG <<'EOF'
0
EOF

cat > disk_content/TIMEZONE.CFG <<'EOF'
3
Europe/Moscow
EOF

cat > disk_content/USER.CFG <<'EOF'
user
EOF

cat > disk_content/PASSWORD.CFG <<'EOF'
1234
EOF

cat > disk_content/SUPASS.CFG <<'EOF'
root
EOF

cat > disk_content/FIRST_B.CFG <<'EOF'
0
EOF

cat > disk_content/AUTOLOGIN.CFG <<'EOF'
1
EOF

cat > disk_content/VIDEOMODE.CFG <<'EOF'
0
EOF

cat > disk_content/SCREENSAVER.CFG <<'EOF'
0
EOF

cat > disk_content/SLOWBOOT.CFG <<'EOF'
0
EOF

cat > disk_content/AUTOEXEC.NE <<'EOF'
# NeutrinoOS startup script
ECHO Hello, $username!
ECHO Current timezone: UTC$timezone
EOF

cat > disk_content/MOTD.TXT <<'EOF'
Welcome to NeutrinoOS!;Light as a neutrino, fast as light.;Type HELP for commands.;Mikelsoft Corporation INC.
EOF

for f in README.TXT THEME.CFG TIMEZONE.CFG USER.CFG PASSWORD.CFG SUPASS.CFG \
         FIRST_B.CFG AUTOLOGIN.CFG VIDEOMODE.CFG SCREENSAVER.CFG SLOWBOOT.CFG \
         AUTOEXEC.NE MOTD.TXT; do
    mcopy -o -i "$DISK" "disk_content/$f" ::/ 2>/dev/null \
        || warn "Copy $f failed (continuing)"
done

mmd -i "$DISK" ::/DOCS 2>/dev/null || true
mmd -i "$DISK" ::/APPS 2>/dev/null || true
ok "Prepopulated disk"

# ---------------------------------------------------------------
banner "Build complete"
SIZE_ISO=$(stat -c%s "$ISO")
SIZE_DISK=$(stat -c%s "$DISK")
SIZE_KERNEL=$(stat -c%s "$KERNEL")
echo -e "  ${BOLD}Version:${NC} v${VERSION}"
echo -e "  ${BOLD}Kernel:${NC}  $KERNEL ($((SIZE_KERNEL/1024)) KiB)"
echo -e "  ${BOLD}ISO:${NC}     $ISO ($((SIZE_ISO/1024)) KiB)"
echo -e "  ${BOLD}Disk:${NC}    $DISK ($((SIZE_DISK/1024)) KiB, FAT12)"
echo ""
echo -e "  Run:  ${CYAN}./run.sh${NC}   or   ${CYAN}./build.sh --run${NC}"
echo ""

# ---------------------------------------------------------------
if [ "$DO_RUN" = "1" ]; then
    banner "Launching QEMU"
    exec ./run.sh
fi

if [ "$DO_TEST" = "1" ]; then
    banner "Headless smoke test (5s)"
    if ! command -v qemu-system-i386 >/dev/null 2>&1; then
        fail "qemu-system-i386 not installed"
    fi
    timeout 5 qemu-system-i386 \
        -cdrom "$ISO" \
        -drive "file=$DISK,format=raw,if=ide,index=0,media=disk" \
        -m 32M -boot d -nographic -serial null -monitor none \
        -no-reboot >/dev/null 2>&1 || true
    ok "Smoke test completed (no crash detected in 5s)"
fi

