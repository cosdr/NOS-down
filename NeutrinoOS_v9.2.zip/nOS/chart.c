#include "chart.h"
#include "vga.h"
#include "keyboard.h"
#include "utils.h"

#define MAXV 64

void chart_run(void) {
    int vals[MAXV];
    int n = 0;
    char buf[256];

    uint8_t title_fg = vga_make_color(VGA_LIGHT_CYAN, VGA_BLACK);
    uint8_t hint_fg  = vga_make_color(VGA_DARK_GREY, VGA_BLACK);
    uint8_t input_fg = vga_make_color(VGA_WHITE, VGA_BLACK);
    uint8_t bar_fg   = vga_make_color(VGA_LIGHT_GREEN, VGA_BLACK);
    uint8_t bar_top  = vga_make_color(VGA_LIGHT_RED, VGA_BLACK);
    uint8_t axis_fg  = vga_make_color(VGA_LIGHT_GREY, VGA_BLACK);
    uint8_t label_fg = vga_make_color(VGA_YELLOW, VGA_BLACK);

    while (1) {
        vga_clear(vga_make_color(VGA_BLACK, VGA_BLACK));
        vga_draw_box(2, 2, 76, 20, vga_make_color(VGA_BLUE, VGA_BLACK));
        vga_print("=== CHART ===", title_fg, 35, 4);
        vga_print("Enter numbers separated by spaces (max 64).", hint_fg, 6, 6);
        vga_print("Press ENTER to draw, ESC to quit.", hint_fg, 6, 7);
        vga_print("> ", title_fg, 6, 10);
        vga_set_cursor(8, 10);

        int pos = 0;
        while (1) {
            int k = keyboard_getchar();
            if (k == '\n') { buf[pos] = 0; break; }
            if (k == -KEY_ESC) { vga_clear(vga_make_color(VGA_LIGHT_GREY, VGA_BLACK)); return; }
            if (k == '\b' && pos > 0) {
                pos--;
                vga_putchar_at('\b', input_fg);
                vga_putchar_at(' ', input_fg);
                vga_putchar_at('\b', input_fg);
            } else if (k > 0 && k < 128 && pos < 255) {
                buf[pos++] = (char)k;
                vga_putchar_at((char)k, input_fg);
            }
        }
        if (pos == 0) continue;

        n = 0;
        int i = 0;
        while (buf[i] && n < MAXV) {
            while (buf[i] == ' ') i++;
            if (!buf[i]) break;
            int neg = 0;
            if (buf[i] == '-') { neg = 1; i++; }
            int v = 0;
            while (buf[i] >= '0' && buf[i] <= '9') { v = v * 10 + (buf[i] - '0'); i++; }
            if (neg) v = -v;
            vals[n++] = v;
        }
        if (n == 0) continue;

        int vmax = 1;
        for (int j = 0; j < n; j++) if (vals[j] > vmax) vmax = vals[j];

        vga_clear(vga_make_color(VGA_BLACK, VGA_BLACK));
        vga_print("=== CHART ===", title_fg, 35, 0);

        int chart_top = 2;
        int chart_bot = 20;
        int chart_h   = chart_bot - chart_top;

        for (int y = chart_top; y <= chart_bot; y++) vga_putcell(4, y, 179, axis_fg, VGA_BLACK);
        for (int x = 4; x < 78; x++) vga_putcell(x, chart_bot + 1, 196, axis_fg, VGA_BLACK);

        char lb[8];
        itoa(vmax, lb, 10);
        vga_print(lb, label_fg, 4 - strlen(lb), chart_top);
        itoa(vmax / 2, lb, 10);
        vga_print(lb, label_fg, 4 - strlen(lb), chart_top + chart_h / 2);
        vga_print("0", label_fg, 3, chart_bot);

        int avail = 78 - 6;
        int step = avail / n;
        if (step < 2) step = 2;
        int bar_w = step - 1;
        if (bar_w < 1) bar_w = 1;

        for (int j = 0; j < n; j++) {
            int h = (vals[j] * chart_h) / vmax;
            if (vals[j] > 0 && h == 0) h = 1;
            int x0 = 6 + j * step;
            for (int b = 0; b < bar_w && x0 + b < 78; b++) {
                for (int r = 0; r < h; r++) {
                    int y = chart_bot - r;
                    uint8_t c = (r == h - 1) ? bar_top : bar_fg;
                    vga_putcell(x0 + b, y, CH_FULL_BLOCK, c, VGA_BLACK);
                }
            }
            char vb[8]; itoa(vals[j], vb, 10);
            int lx = x0;
            if (lx + (int)strlen(vb) >= 78) lx = 78 - strlen(vb) - 1;
            vga_print(vb, label_fg, lx, chart_bot + 2);
        }

        vga_print("Press any key to enter new data, ESC to quit.", hint_fg, 6, 24);
        int k = keyboard_getchar();
        if (k == -KEY_ESC) break;
    }
    vga_clear(vga_make_color(VGA_LIGHT_GREY, VGA_BLACK));
}
