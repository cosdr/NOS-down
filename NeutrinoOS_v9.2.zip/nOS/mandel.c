#include "mandel.h"
#include "vga.h"
#include "keyboard.h"
#include "utils.h"

static const char* ramp = " .,:;+*#@";

void mandel_run(void) {
    double center_x = -0.5, center_y = 0.0;
    double zoom = 2.5;
    int max_iter = 60;
    int running = 1;
    while (running) {
        vga_clear(vga_make_color(VGA_BLACK, VGA_BLACK));
        vga_draw_box(0, 0, 80, 25, vga_make_color(VGA_BLUE, VGA_BLACK));
        for (int y = 1; y < 24; y++) {
            for (int x = 1; x < 79; x++) {
                double cr = center_x + ((double)(x - 40) / 40.0) * zoom;
                double ci = center_y + ((double)(y - 12) / 12.0) * zoom * 0.6;
                double zr = 0, zi = 0;
                int iter = 0;
                while (zr*zr + zi*zi < 4.0 && iter < max_iter) {
                    double t = zr*zr - zi*zi + cr;
                    zi = 2*zr*zi + ci;
                    zr = t;
                    iter++;
                }
                char c = iter == max_iter ? ' ' : ramp[iter % 8];
                uint8_t color = (iter == max_iter) ? VGA_BLACK : (uint8_t)((iter % 15) + 1);
                vga_putcell(x, y, c, color, VGA_BLACK);
            }
        }
        vga_print("Arrows=move +/-=zoom R=reset ESC=exit",
                  vga_make_color(VGA_LIGHT_CYAN, VGA_BLACK), 15, 24);
        int key = keyboard_getchar();
        if (key == -KEY_ESC) running = 0;
        else if (key == -KEY_UP)    center_y -= zoom * 0.1;
        else if (key == -KEY_DOWN)  center_y += zoom * 0.1;
        else if (key == -KEY_LEFT)  center_x -= zoom * 0.1;
        else if (key == -KEY_RIGHT) center_x += zoom * 0.1;
        else if (key == '+' || key == '=') zoom *= 0.7;
        else if (key == '-') zoom *= 1.4;
        else if (key == 'r' || key == 'R') { center_x = -0.5; center_y = 0; zoom = 2.5; }
    }
    vga_clear(vga_make_color(VGA_LIGHT_GREY, VGA_BLACK));
}
