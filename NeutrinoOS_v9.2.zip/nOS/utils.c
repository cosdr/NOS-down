#include "utils.h"

void* memset(void* ptr, int value, int num) {
    unsigned char* p = (unsigned char*)ptr;
    for (int i = 0; i < num; i++) p[i] = (unsigned char)value;
    return ptr;
}
void* memcpy(void* dest, const void* src, int num) {
    unsigned char* d = (unsigned char*)dest;
    const unsigned char* s = (const unsigned char*)src;
    for (int i = 0; i < num; i++) d[i] = s[i];
    return dest;
}
int strlen(const char* str) { int len = 0; while (str[len]) len++; return len; }
int strcmp(const char* a, const char* b) {
    while (*a && *b && *a == *b) { a++; b++; }
    return (unsigned char)*a - (unsigned char)*b;
}
int strncmp(const char* a, const char* b, int n) {
    while (n > 0 && *a && *b && *a == *b) { a++; b++; n--; }
    if (n == 0) return 0;
    return (unsigned char)*a - (unsigned char)*b;
}
char to_lower(char c) { if (c >= 'A' && c <= 'Z') return c + 32; return c; }
char to_upper(char c) { if (c >= 'a' && c <= 'z') return c - 32; return c; }
int  is_digit(char c) { return c >= '0' && c <= '9'; }
int strcasecmp(const char* a, const char* b) {
    while (*a && *b) {
        char la = to_lower(*a), lb = to_lower(*b);
        if (la != lb) return (unsigned char)la - (unsigned char)lb;
        a++; b++;
    }
    return (unsigned char)to_lower(*a) - (unsigned char)to_lower(*b);
}
int strncasecmp(const char* a, const char* b, int n) {
    while (n > 0 && *a && *b) {
        char la = to_lower(*a), lb = to_lower(*b);
        if (la != lb) return (unsigned char)la - (unsigned char)lb;
        a++; b++; n--;
    }
    if (n == 0) return 0;
    return (unsigned char)to_lower(*a) - (unsigned char)to_lower(*b);
}
void strcpy(char* dest, const char* src) { while (*src) { *dest = *src; dest++; src++; } *dest = 0; }
void strncpy(char* dest, const char* src, int n) {
    int i = 0;
    while (i < n - 1 && src[i]) { dest[i] = src[i]; i++; }
    dest[i] = 0;
}
void strcat(char* dest, const char* src) { while (*dest) dest++; while (*src) { *dest = *src; dest++; src++; } *dest = 0; }
int atoi(const char* str) {
    int result = 0, sign = 1;
    if (*str == '-') { sign = -1; str++; }
    while (*str >= '0' && *str <= '9') { result = result * 10 + (*str - '0'); str++; }
    return result * sign;
}
void itoa(int value, char* str, int base) {
    if (value == 0) { str[0] = '0'; str[1] = 0; return; }
    int neg = 0;
    if (value < 0 && base == 10) { neg = 1; value = -value; }
    char tmp[32]; int pos = 0;
    while (value > 0) {
        int digit = value % base;
        tmp[pos++] = (digit < 10) ? (char)('0' + digit) : (char)('A' + digit - 10);
        value /= base;
    }
    if (neg) tmp[pos++] = '-';
    int i = 0;
    while (pos > 0) str[i++] = tmp[--pos];
    str[i] = 0;
}
void itoa_pad(int value, char* str, int width) {
    char tmp[32]; itoa(value, tmp, 10);
    int len = strlen(tmp), pad = width - len, i = 0;
    while (pad-- > 0) str[i++] = '0';
    int j = 0;
    while (tmp[j]) str[i++] = tmp[j++];
    str[i] = 0;
}
void delay(int cycles) { for (volatile int i = 0; i < cycles; i++) for (volatile int j = 0; j < 1000; j++) { } }
int strstr_idx(const char* haystack, const char* needle) {
    if (!*needle) return 0;
    for (int i = 0; haystack[i]; i++) {
        int match = 1;
        for (int j = 0; needle[j]; j++) {
            if (!haystack[i + j] || to_lower(haystack[i + j]) != to_lower(needle[j])) { match = 0; break; }
        }
        if (match) return i;
    }
    return -1;
}

static uint32_t rng_state = 0xDEADBEEF;
uint32_t rng_next(void) {
    rng_state = rng_state * 1103515245u + 12345u;
    return (rng_state >> 16) & 0x7FFF;
}

void     outb(uint16_t port, uint8_t  data) { __asm__ volatile("outb %0, %1" :: "a"(data), "Nd"(port)); }
uint8_t  inb (uint16_t port) { uint8_t  r; __asm__ volatile("inb  %1, %0" : "=a"(r) : "Nd"(port)); return r; }
void     outw(uint16_t port, uint16_t data) { __asm__ volatile("outw %0, %1" :: "a"(data), "Nd"(port)); }
uint16_t inw (uint16_t port) { uint16_t r; __asm__ volatile("inw  %1, %0" : "=a"(r) : "Nd"(port)); return r; }
void     outl(uint16_t port, uint32_t data) { __asm__ volatile("outl %0, %1" :: "a"(data), "Nd"(port)); }
uint32_t inl (uint16_t port) { uint32_t r; __asm__ volatile("inl  %1, %0" : "=a"(r) : "Nd"(port)); return r; }
