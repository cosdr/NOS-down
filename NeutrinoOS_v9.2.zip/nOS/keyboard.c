#include "keyboard.h"
#include "stdint.h"
#include "utils.h"

#define KBD_DATA_PORT   0x60
#define KBD_STATUS_PORT 0x64
#define KBD_BUFFER_SIZE 256

#define SCANCODE_TAB    0x0F
#define SCANCODE_U      0x16
#define SCANCODE_BKSP   0x0E

static volatile int kbd_buffer[KBD_BUFFER_SIZE];
static volatile int kbd_head = 0, kbd_tail = 0;

static const char scancode_map[128] = {
    0, 0, '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '-', '=', 0,
    0, 'q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p', '[', ']', 0,
    0, 'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', ';', '\'', '`',
    0, '\\', 'z', 'x', 'c', 'v', 'b', 'n', 'm', ',', '.', '/', 0,
    '*', 0, ' ', 0
};

static const char scancode_map_shift[128] = {
    0, 0, '!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '_', '+', 0,
    0, 'Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P', '{', '}', 0,
    0, 'A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', ':', '"', '~',
    0, '|', 'Z', 'X', 'C', 'V', 'B', 'N', 'M', '<', '>', '?', 0,
    '*', 0, ' ', 0
};

static volatile int shift_pressed = 0;
static volatile int caps_on = 0;
static volatile int ctrl_pressed = 0;
static volatile int alt_pressed = 0;
static volatile int e0_pending = 0;

void keyboard_init(void) {
    shift_pressed = 0; caps_on = 0; ctrl_pressed = 0; alt_pressed = 0; e0_pending = 0;
    kbd_head = 0; kbd_tail = 0;
    for (int i = 0; i < KBD_BUFFER_SIZE; i++) kbd_buffer[i] = 0;
    while (inb(KBD_STATUS_PORT) & 0x01) inb(KBD_DATA_PORT);
}
int keyboard_is_ctrl(void)  { return ctrl_pressed; }
int keyboard_is_shift(void) { return shift_pressed; }
int keyboard_is_alt(void)   { return alt_pressed; }
int keyboard_has_pending(void) { return kbd_head != kbd_tail; }

static void push_key(int sc) {
    int next = (kbd_tail + 1) % KBD_BUFFER_SIZE;
    if (next != kbd_head) { kbd_buffer[kbd_tail] = sc; kbd_tail = next; }
}

static void process_scancode(uint8_t sc) {
    if (sc == 0xE0) { e0_pending = 1; return; }
    if (sc == 0xE1) return;

    int is_break = (sc & 0x80) != 0;
    uint8_t code = sc & 0x7F;

    if (e0_pending) {
        e0_pending = 0;
        if (is_break) {
            if (code == KEY_ALT)  alt_pressed  = 0;
            if (code == KEY_CTRL) ctrl_pressed = 0;
            return;
        }
        if (code == KEY_ALT)   { alt_pressed  = 1; return; }
        if (code == KEY_CTRL)  { ctrl_pressed = 1; return; }
        if (code == 0x53) {
            if (alt_pressed) push_key(KEY_ALT_DEL);
            else             push_key(KEY_DELETE);
            return;
        }
        if (code == 0x49) { push_key(KEY_PGUP);   return; }
        if (code == 0x51) { push_key(KEY_PGDN);   return; }
        if (code == 0x47) { push_key(KEY_HOME);   return; }
        if (code == 0x4F) { push_key(KEY_END);    return; }
        if (code == 0x48) { push_key(KEY_UP);     return; }
        if (code == 0x50) { push_key(KEY_DOWN);   return; }
        if (code == 0x4B) { push_key(KEY_LEFT);   return; }
        if (code == 0x4D) { push_key(KEY_RIGHT);  return; }
        return;
    }

    if (is_break) {
        if (code == KEY_LSHIFT || code == KEY_RSHIFT) shift_pressed = 0;
        else if (code == KEY_CTRL) ctrl_pressed = 0;
        else if (code == KEY_ALT)  alt_pressed  = 0;
        return;
    }

    if (code == KEY_LSHIFT || code == KEY_RSHIFT) { shift_pressed = 1; return; }
    if (code == KEY_CTRL)  { ctrl_pressed = 1; return; }
    if (code == KEY_ALT)   { alt_pressed  = 1; return; }
    if (code == KEY_CAPS)  { caps_on = !caps_on; return; }

    if (code == SCANCODE_TAB) {
        push_key(shift_pressed ? KEY_SHIFT_TAB : KEY_TAB_CODE);
        return;
    }
    if (ctrl_pressed && code == SCANCODE_U)    { push_key(KEY_CTRL_U);    return; }
    if (ctrl_pressed && code == SCANCODE_BKSP) { push_key(KEY_CTRL_BKSP); return; }

    push_key(code);
}

static void poll_hw(void) {
    uint8_t status = inb(KBD_STATUS_PORT);
    if (!(status & 0x01)) return;
    uint8_t sc = inb(KBD_DATA_PORT);
    process_scancode(sc);
}

static int translate(int sc) {
    if (sc == KEY_TAB_CODE)  return KEY_TAB_CODE;
    if (sc == KEY_CTRL_U)    return KEY_CTRL_U;
    if (sc == KEY_CTRL_BKSP) return KEY_CTRL_BKSP;
    if (sc == KEY_SHIFT_TAB) return KEY_SHIFT_TAB;
    if (sc == KEY_ALT_DEL)   return KEY_ALT_DEL;
    if (sc == KEY_PGUP)      return KEY_PGUP;
    if (sc == KEY_PGDN)      return KEY_PGDN;
    if (sc == KEY_HOME)      return KEY_HOME;
    if (sc == KEY_END)       return KEY_END;
    if (sc == KEY_DELETE)    return KEY_DELETE;

    if (sc == KEY_ENTER)     return '\n';
    if (sc == KEY_BACKSPACE) return '\b';
    if (sc == KEY_UP)    return -KEY_UP;
    if (sc == KEY_DOWN)  return -KEY_DOWN;
    if (sc == KEY_LEFT)  return -KEY_LEFT;
    if (sc == KEY_RIGHT) return -KEY_RIGHT;
    if (sc == KEY_ESC)   return -KEY_ESC;
    if (sc == KEY_F1)  return -KEY_F1;
    if (sc == KEY_F2)  return -KEY_F2;
    if (sc == KEY_F3)  return -KEY_F3;
    if (sc == KEY_F4)  return -KEY_F4;
    if (sc == KEY_F5)  return -KEY_F5;
    if (sc == KEY_F6)  return -KEY_F6;
    if (sc == KEY_F7)  return -KEY_F7;
    if (sc == KEY_F8)  return -KEY_F8;
    if (sc == KEY_F9)  return -KEY_F9;
    if (sc == KEY_F10) return -KEY_F10;

    if (sc <= 0 || sc >= 128) return 0;

    char base = scancode_map[sc];
    char shifted = scancode_map_shift[sc];

    int is_letter = (base >= 'a' && base <= 'z');
    if (is_letter) {
        if (shift_pressed ^ caps_on) return shifted;
        return base;
    }
    if (shift_pressed) return shifted;
    return base;
}

int keyboard_getchar(void) {
    while (kbd_head == kbd_tail) poll_hw();
    int sc = kbd_buffer[kbd_head];
    kbd_head = (kbd_head + 1) % KBD_BUFFER_SIZE;
    return translate(sc);
}
int keyboard_poll(void) {
    poll_hw();
    if (kbd_head == kbd_tail) return -1;
    int sc = kbd_buffer[kbd_head];
    kbd_head = (kbd_head + 1) % KBD_BUFFER_SIZE;
    int t = translate(sc);
    return (t == 0) ? -1 : t;
}
