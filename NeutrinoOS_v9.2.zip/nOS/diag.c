#include "diag.h"
#include "vga.h"
#include "fat12.h"
#include "utils.h"

static const char* required[] = {
    "README.TXT", "THEME.CFG", "TIMEZONE.CFG",
    "USER.CFG", "PASSWORD.CFG", "SUPASS.CFG",
    "FIRST_B.CFG", "AUTOEXEC.NE", "MOTD.TXT"
};
#define N_REQ ((int)(sizeof(required)/sizeof(required[0])))

static void red_warning_box(const char** missing, int count) {
    int w = 60, h = 12;
    int x = (80 - w) / 2;
    int y = (25 - h) / 2;
    vga_fill_bg(x, y, w, h, ' ', VGA_WHITE, VGA_RED);
    uint8_t white = vga_make_color(VGA_WHITE, VGA_RED);
    for (int i = 0; i < w; i++) { vga_putchar(205, white, x + i, y); vga_putchar(205, white, x + i, y + h - 1); }
    for (int i = 0; i < h; i++) { vga_putchar(186, white, x, y + i); vga_putchar(186, white, x + w - 1, y + i); }
    vga_putchar(201, white, x, y);
    vga_putchar(187, white, x + w - 1, y);
    vga_putchar(200, white, x, y + h - 1);
    vga_putchar(188, white, x + w - 1, y + h - 1);
    vga_print("Warning! System image corrupted!", white, x + 4, y + 2);
    for (int i = 0; i < count && i < 5; i++) {
        vga_print("Missing file(s) = ", white, x + 4, y + 4 + i);
        vga_print(missing[i], white, x + 22, y + 4 + i);
    }
    for (int s = 5; s > 0; s--) {
        char sb[4]; itoa(s, sb, 10);
        vga_print("Skipping in... ", white, x + 4, y + h - 3);
        vga_print(sb, white, x + 19, y + h - 3);
        vga_print("s ", white, x + 20, y + h - 3);
        for (volatile int d = 0; d < 40000; d++)
            for (volatile int e = 0; e < 500; e++) { }
    }
}
void diag_check_files(void) {
    if (!fat12_is_mounted()) return;
    const char* missing[N_REQ];
    int missing_count = 0;
    for (int i = 0; i < N_REQ; i++)
        if (fat12_find(required[i]) < 0) missing[missing_count++] = required[i];
    if (missing_count > 0) {
        red_warning_box(missing, missing_count);
        vga_clear(vga_make_color(VGA_LIGHT_GREY, VGA_BLACK));
    }
}
