#ifndef CLOCKA_H
#define CLOCKA_H

void clocka_run(void);

#endif
