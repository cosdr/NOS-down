#ifndef WM_H
#define WM_H

#include "stdint.h"

#define WM_MAX_WINDOWS  8
#define WM_MAX_TITLE    32

typedef void (*wm_draw_fn)(int id, int x, int y, int w, int h);

typedef struct {
    int        used;
    int        x, y, w, h;
    int        z;
    int        minimized;
    char       title[WM_MAX_TITLE];
    wm_draw_fn draw_content;
} wm_window_t;

void         wm_init(void);
int          wm_create(int x, int y, int w, int h, const char* title, wm_draw_fn draw);
void         wm_destroy(int id);
void         wm_focus(int id);
int          wm_focused(void);
int          wm_hit(int x, int y);
void         wm_draw_all(void);
wm_window_t* wm_get(int id);

#endif
