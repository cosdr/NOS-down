#include "screensaver.h"
#include "vga.h"
#include "keyboard.h"
#include "utils.h"

static uint32_t rng_state = 12345;
static uint32_t rnd(void) {
    rng_state = rng_state * 1103515245 + 12345;
    return (rng_state >> 16) & 0x7FFF;
}

void saver_starfield(void) {
    #define STARS 100
    struct { int x, y, speed; } stars[STARS];
    for (int i = 0; i < STARS; i++) {
        stars[i].x = rnd() % VGA_WIDTH;
        stars[i].y = rnd() % VGA_HEIGHT;
        stars[i].speed = 1 + (rnd() % 3);
    }
    vga_clear(vga_make_color(VGA_BLACK, VGA_BLACK));
    while (1) {
        int k = keyboard_poll();
        if (k != -1) break;
        for (int i = 0; i < STARS; i++) {
            if (stars[i].y > 0)
                vga_putcell(stars[i].x, stars[i].y, ' ', VGA_BLACK, VGA_BLACK);
            stars[i].y += stars[i].speed;
            if (stars[i].y >= VGA_HEIGHT) {
                stars[i].y = 0;
                stars[i].x = rnd() % VGA_WIDTH;
                stars[i].speed = 1 + (rnd() % 3);
            }
            uint8_t color = stars[i].speed == 1 ? VGA_DARK_GREY :
                           (stars[i].speed == 2 ? VGA_LIGHT_GREY : VGA_WHITE);
            vga_putcell(stars[i].x, stars[i].y, '.', color, VGA_BLACK);
        }
        for (volatile int d = 0; d < 200; d++)
            for (volatile int e = 0; e < 100; e++) { }
    }
    vga_clear(vga_make_color(VGA_LIGHT_GREY, VGA_BLACK));
}

void saver_matrix(void) {
    int drops[VGA_WIDTH];
    for (int i = 0; i < VGA_WIDTH; i++) drops[i] = rnd() % VGA_HEIGHT;
    vga_clear(vga_make_color(VGA_BLACK, VGA_BLACK));
    while (1) {
        int k = keyboard_poll();
        if (k != -1) break;
        for (int x = 0; x < VGA_WIDTH; x++) {
            char c = (char)(33 + (rnd() % 90));
            vga_putcell(x, drops[x], c, VGA_LIGHT_GREEN, VGA_BLACK);
            if (drops[x] > 0) {
                int ty = drops[x] - 1;
                char tc = vga_getcell(x, ty);
                if (tc != ' ') vga_putcell(x, ty, tc, VGA_GREEN, VGA_BLACK);
            }
            if (drops[x] > 3)
                vga_putcell(x, drops[x] - 3, ' ', VGA_BLACK, VGA_BLACK);
            drops[x]++;
            if (drops[x] > VGA_HEIGHT + 5) drops[x] = 0;
        }
        for (volatile int d = 0; d < 100; d++)
            for (volatile int e = 0; e < 500; e++) { }
    }
    vga_clear(vga_make_color(VGA_LIGHT_GREY, VGA_BLACK));
}

void saver_bounce(void) {
    int x = 10, y = 5, dx = 1, dy = 1;
    const char* txt = "* NeutrinoOS *";
    vga_clear(vga_make_color(VGA_BLACK, VGA_BLACK));
    while (1) {
        int k = keyboard_poll();
        if (k != -1) break;
        vga_print("              ", VGA_BLACK, x, y);
        x += dx; y += dy;
        int len = strlen(txt);
        if (x <= 0 || x + len >= VGA_WIDTH) dx = -dx;
        if (y <= 0 || y >= VGA_HEIGHT - 1)  dy = -dy;
        if (x < 0) x = 0;
        if (y < 0) y = 0;
        if (x + len >= VGA_WIDTH) x = VGA_WIDTH - len - 1;
        if (y >= VGA_HEIGHT) y = VGA_HEIGHT - 1;
        uint8_t colors[] = { VGA_LIGHT_CYAN, VGA_LIGHT_GREEN, VGA_YELLOW, VGA_LIGHT_MAGENTA, VGA_LIGHT_RED };
        uint8_t c = colors[(x + y) % 5];
        vga_print(txt, c, x, y);
        for (volatile int d = 0; d < 200; d++)
            for (volatile int e = 0; e < 500; e++) { }
    }
    vga_clear(vga_make_color(VGA_LIGHT_GREY, VGA_BLACK));
}

void saver_pipes(void) {
    vga_clear(vga_make_color(VGA_BLACK, VGA_BLACK));
    int x = VGA_WIDTH / 2, y = VGA_HEIGHT / 2;
    int dx = 1, dy = 0;
    uint8_t c = VGA_LIGHT_CYAN;
    while (1) {
        int k = keyboard_poll();
        if (k != -1) break;
        char glyph;
        if (dx && dy) glyph = (dx * dy > 0) ? '\\' : '/';
        else if (dx) glyph = '-';
        else glyph = '|';
        vga_putcell(x, y, glyph, c, VGA_BLACK);
        if (rnd() % 8 == 0) {
            if (dx) { dy = (rnd() & 1) ? 1 : -1; dx = 0; }
            else    { dx = (rnd() & 1) ? 1 : -1; dy = 0; }
            c = (uint8_t)(1 + (rnd() % 15));
        }
        x += dx; y += dy;
        if (x < 0) x = VGA_WIDTH - 1;
        if (x >= VGA_WIDTH) x = 0;
        if (y < 0) y = VGA_HEIGHT - 1;
        if (y >= VGA_HEIGHT) y = 0;
        for (volatile int d = 0; d < 100; d++)
            for (volatile int e = 0; e < 500; e++) { }
    }
    vga_clear(vga_make_color(VGA_LIGHT_GREY, VGA_BLACK));
}

void saver_run_by_id(int id) {
    if (id == 1) saver_starfield();
    else if (id == 2) saver_matrix();
    else if (id == 3) saver_bounce();
    else if (id == 4) saver_pipes();
}
