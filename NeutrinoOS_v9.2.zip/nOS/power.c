#include "power.h"
#include "vga.h"
#include "utils.h"

void power_reboot(void) {
    while (inb(0x64) & 0x02) { }
    outb(0x64, 0xFE);
    for (;;) __asm__ volatile("hlt");
}

void power_shutdown(void) {
    outw(0x604,  0x2000);
    outw(0xB004, 0x2000);
    outw(0x8900, 0xDEAD);
    vga_clear(vga_make_color(VGA_BLACK, VGA_BLACK));
    uint8_t orange = vga_make_color(VGA_YELLOW, VGA_BLACK);
    vga_print("Now you can safe disable your PC.", orange, 22, 12);
    for (;;) __asm__ volatile("hlt");
}
