#include "games.h"
#include "vga.h"
#include "keyboard.h"
#include "pcspk.h"
#include "rtc.h"
#include "utils.h"

void game_snake(void) {
    #define SNAKE_W 40
    #define SNAKE_H 20
    #define SNAKE_MAX 100
    int snake_x[SNAKE_MAX], snake_y[SNAKE_MAX];
    int len = 5, dir = 0, food_x, food_y, score = 0, running = 1;
    for (int i = 0; i < len; i++) { snake_x[i] = 20 - i; snake_y[i] = 10; }
    food_x = 25; food_y = 10;
    vga_clear(vga_make_color(VGA_BLACK, VGA_BLACK));
    vga_draw_box(19, 1, SNAKE_W + 2, SNAKE_H + 2, vga_make_color(VGA_GREEN, VGA_BLACK));
    vga_print("SNAKE", vga_make_color(VGA_LIGHT_GREEN, VGA_BLACK), 35, 0);
    vga_print("Arrows to move, ESC to quit", vga_make_color(VGA_DARK_GREY, VGA_BLACK), 25, 24);
    while (running) {
        vga_putcell(20 + food_x, 2 + food_y, '@', VGA_LIGHT_RED, VGA_BLACK);
        for (int tick = 0; tick < 8; tick++) {
            int key = keyboard_poll();
            if (key == -KEY_ESC) { running = 0; break; }
            else if (key == -KEY_UP    && dir != 1) dir = 3;
            else if (key == -KEY_DOWN  && dir != 3) dir = 1;
            else if (key == -KEY_LEFT  && dir != 0) dir = 2;
            else if (key == -KEY_RIGHT && dir != 2) dir = 0;
            for (volatile int d = 0; d < 80; d++)
                for (volatile int e = 0; e < 100; e++) { }
        }
        if (!running) break;
        int nx = snake_x[0], ny = snake_y[0];
        if      (dir == 0) nx++;
        else if (dir == 1) ny++;
        else if (dir == 2) nx--;
        else ny--;
        if (nx < 0 || nx >= SNAKE_W || ny < 0 || ny >= SNAKE_H) { pcspk_error(); running = 0; break; }
        for (int i = 0; i < len; i++)
            if (snake_x[i] == nx && snake_y[i] == ny) { pcspk_error(); running = 0; break; }
        if (!running) break;
        for (int i = len - 1; i > 0; i--) { snake_x[i] = snake_x[i - 1]; snake_y[i] = snake_y[i - 1]; }
        snake_x[0] = nx; snake_y[0] = ny;
        if (nx == food_x && ny == food_y) {
            score += 10; pcspk_click();
            if (len < SNAKE_MAX) len++;
            food_x = 1 + (score * 7 + 3) % (SNAKE_W - 2);
            food_y = 1 + (score * 13 + 5) % (SNAKE_H - 2);
        }
        vga_fill(20, 2, SNAKE_W, SNAKE_H, ' ', vga_make_color(VGA_BLACK, VGA_BLACK));
        for (int i = 0; i < len; i++) {
            uint8_t c = i == 0 ? VGA_LIGHT_GREEN : VGA_GREEN;
            vga_putcell(20 + snake_x[i], 2 + snake_y[i], i == 0 ? 'O' : 'o', c, VGA_BLACK);
        }
        char sb[16] = "Score: ";
        char num[8]; itoa(score, num, 10);
        int p = 7;
        for (int i = 0; num[i]; i++) sb[p++] = num[i];
        sb[p] = 0;
        vga_print(sb, vga_make_color(VGA_YELLOW, VGA_BLACK), 2, 23);
    }
    vga_clear(vga_make_color(VGA_LIGHT_GREY, VGA_BLACK));
}

#define TET_W 10
#define TET_H 18
static const int tetrominoes[7][4][4][2] = {
    {{{0,0},{1,0},{2,0},{3,0}}, {{0,0},{0,1},{0,2},{0,3}}, {{0,0},{1,0},{2,0},{3,0}}, {{0,0},{0,1},{0,2},{0,3}}},
    {{{0,0},{1,0},{0,1},{1,1}}, {{0,0},{1,0},{0,1},{1,1}}, {{0,0},{1,0},{0,1},{1,1}}, {{0,0},{1,0},{0,1},{1,1}}},
    {{{1,0},{0,1},{1,1},{2,1}}, {{1,0},{1,1},{2,1},{1,2}}, {{0,1},{1,1},{2,1},{1,2}}, {{1,0},{0,1},{1,1},{1,2}}},
    {{{0,1},{1,1},{1,0},{2,0}}, {{1,0},{1,1},{2,1},{2,2}}, {{0,1},{1,1},{1,0},{2,0}}, {{1,0},{1,1},{2,1},{2,2}}},
    {{{0,0},{1,0},{1,1},{2,1}}, {{2,0},{1,1},{2,1},{1,2}}, {{0,0},{1,0},{1,1},{2,1}}, {{2,0},{1,1},{2,1},{1,2}}},
    {{{0,0},{0,1},{1,1},{2,1}}, {{1,0},{2,0},{1,1},{1,2}}, {{0,1},{1,1},{2,1},{2,2}}, {{1,0},{1,1},{0,2},{1,2}}},
    {{{2,0},{0,1},{1,1},{2,1}}, {{1,0},{1,1},{1,2},{2,2}}, {{0,1},{1,1},{2,1},{0,2}}, {{0,0},{1,0},{1,1},{1,2}}},
};

void game_tetris(void) {
    int board[TET_H][TET_W];
    for (int y = 0; y < TET_H; y++) for (int x = 0; x < TET_W; x++) board[y][x] = 0;
    int piece = 0, rot = 0, px = 3, py = 0;
    int score = 0, running = 1, speed = 20;
    vga_clear(vga_make_color(VGA_BLACK, VGA_BLACK));
    vga_draw_box(28, 1, TET_W + 2, TET_H + 2, vga_make_color(VGA_LIGHT_CYAN, VGA_BLACK));
    vga_print("TETRIS", vga_make_color(VGA_LIGHT_CYAN, VGA_BLACK), 48, 3);
    vga_print("Score:", vga_make_color(VGA_YELLOW, VGA_BLACK), 45, 6);
    vga_print("Left/Right=Move  Up=Rotate  Down=Drop", vga_make_color(VGA_DARK_GREY, VGA_BLACK), 20, 24);
    vga_print("ESC=exit", vga_make_color(VGA_DARK_GREY, VGA_BLACK), 34, 23);
    int frame = 0;
    while (running) {
        int key = keyboard_poll();
        if (key == -KEY_ESC) running = 0;
        else if (key == -KEY_LEFT) {
            int can = 1;
            for (int i = 0; i < 4; i++) {
                int bx = px + tetrominoes[piece][rot][i][0] - 1;
                int by = py + tetrominoes[piece][rot][i][1];
                if (bx < 0 || (by >= 0 && by < TET_H && board[by][bx])) can = 0;
            }
            if (can) px--;
        }
        else if (key == -KEY_RIGHT) {
            int can = 1;
            for (int i = 0; i < 4; i++) {
                int bx = px + tetrominoes[piece][rot][i][0] + 1;
                int by = py + tetrominoes[piece][rot][i][1];
                if (bx >= TET_W || (by >= 0 && by < TET_H && board[by][bx])) can = 0;
            }
            if (can) px++;
        }
        else if (key == -KEY_DOWN) py++;
        else if (key == -KEY_UP) {
            int nr = (rot + 1) % 4;
            int can = 1;
            for (int i = 0; i < 4; i++) {
                int bx = px + tetrominoes[piece][nr][i][0];
                int by = py + tetrominoes[piece][nr][i][1];
                if (bx < 0 || bx >= TET_W || by >= TET_H || (by >= 0 && board[by][bx])) can = 0;
            }
            if (can) { rot = nr; pcspk_click(); }
        }
        frame++;
        if (frame >= speed) {
            frame = 0;
            int can_move = 1;
            for (int i = 0; i < 4; i++) {
                int bx = px + tetrominoes[piece][rot][i][0];
                int by = py + tetrominoes[piece][rot][i][1] + 1;
                if (by >= TET_H || (by >= 0 && board[by][bx])) { can_move = 0; break; }
            }
            if (can_move) py++;
            else {
                for (int i = 0; i < 4; i++) {
                    int bx = px + tetrominoes[piece][rot][i][0];
                    int by = py + tetrominoes[piece][rot][i][1];
                    if (by >= 0 && by < TET_H && bx >= 0 && bx < TET_W) board[by][bx] = piece + 1;
                }
                for (int y = TET_H - 1; y >= 0; y--) {
                    int full = 1;
                    for (int x = 0; x < TET_W; x++) if (!board[y][x]) { full = 0; break; }
                    if (full) {
                        score += 100; pcspk_click();
                        for (int yy = y; yy > 0; yy--)
                            for (int x = 0; x < TET_W; x++) board[yy][x] = board[yy-1][x];
                        for (int x = 0; x < TET_W; x++) board[0][x] = 0;
                        y++;
                    }
                }
                rtc_time_t t; rtc_read(&t);
                piece = (piece + 1 + (t.second % 7)) % 7;
                rot = 0; px = 3; py = 0;
                int dead = 0;
                for (int i = 0; i < 4; i++) {
                    int bx = px + tetrominoes[piece][rot][i][0];
                    int by = py + tetrominoes[piece][rot][i][1];
                    if (board[by][bx]) { dead = 1; break; }
                }
                if (dead) { pcspk_error(); running = 0; }
            }
        }
        vga_fill(29, 2, TET_W, TET_H, ' ', vga_make_color(VGA_BLACK, VGA_BLACK));
        for (int y = 0; y < TET_H; y++)
            for (int x = 0; x < TET_W; x++)
                if (board[y][x]) {
                    uint8_t c = (uint8_t)((board[y][x] - 1) + 9);
                    vga_putcell(29 + x, 2 + y, CH_FULL_BLOCK, c, VGA_BLACK);
                }
        for (int i = 0; i < 4; i++) {
            int bx = px + tetrominoes[piece][rot][i][0];
            int by = py + tetrominoes[piece][rot][i][1];
            if (by >= 0 && by < TET_H && bx >= 0 && bx < TET_W)
                vga_putcell(29 + bx, 2 + by, CH_FULL_BLOCK, VGA_LIGHT_CYAN, VGA_BLACK);
        }
        char sb[16]; itoa(score, sb, 10);
        vga_print("       ", vga_make_color(VGA_YELLOW, VGA_BLACK), 51, 6);
        vga_print(sb,       vga_make_color(VGA_YELLOW, VGA_BLACK), 51, 6);
        for (volatile int d = 0; d < 60; d++)
            for (volatile int e = 0; e < 300; e++) { }
    }
    vga_clear(vga_make_color(VGA_LIGHT_GREY, VGA_BLACK));
}

void game_pong(void) {
    int px = 5, py = 10;
    int bx = 40, by = 12, bdx = 1, bdy = 1;
    int ai_y = 12;
    int score_player = 0, score_ai = 0, running = 1;
    vga_clear(vga_make_color(VGA_BLACK, VGA_BLACK));
    while (running) {
        int key = keyboard_poll();
        if (key == -KEY_ESC) running = 0;
        else if (key == -KEY_UP   && py > 1)  py--;
        else if (key == -KEY_DOWN && py < 21) py++;
        if (by < ai_y && ai_y > 1) ai_y--;
        else if (by > ai_y && ai_y < 21) ai_y++;
        bx += bdx; by += bdy;
        if (by <= 1 || by >= 23) { bdy = -bdy; pcspk_click(); }
        if (bx <= px + 1 && by >= py && by <= py + 4 && bdx < 0) { bdx = -bdx; bx = px + 2; pcspk_click(); }
        if (bx >= 76 && by >= ai_y && by <= ai_y + 4 && bdx > 0) { bdx = -bdx; bx = 75; pcspk_click(); }
        if (bx < 1)  { score_ai++;     bx = 40; by = 12; bdx = 1;  bdy = 1; }
        if (bx > 79) { score_player++; bx = 40; by = 12; bdx = -1; bdy = 1; }
        vga_clear(vga_make_color(VGA_BLACK, VGA_BLACK));
        vga_draw_box(0, 0, 80, 25, vga_make_color(VGA_BLUE, VGA_BLACK));
        for (int y = 1; y < 24; y += 2) vga_putcell(40, y, '|', VGA_DARK_GREY, VGA_BLACK);
        for (int i = 0; i < 5; i++) {
            vga_putcell(px,  py + i,   CH_FULL_BLOCK, VGA_LIGHT_GREEN, VGA_BLACK);
            vga_putcell(76,  ai_y + i, CH_FULL_BLOCK, VGA_LIGHT_RED,   VGA_BLACK);
        }
        vga_putcell(bx, by, 'O', VGA_WHITE, VGA_BLACK);
        char sb[8];
        itoa(score_player, sb, 10); vga_print(sb, vga_make_color(VGA_LIGHT_GREEN, VGA_BLACK), 35, 1);
        itoa(score_ai, sb, 10);     vga_print(sb, vga_make_color(VGA_LIGHT_RED,   VGA_BLACK), 44, 1);
        for (volatile int d = 0; d < 80; d++)
            for (volatile int e = 0; e < 800; e++) { }
    }
    vga_clear(vga_make_color(VGA_LIGHT_GREY, VGA_BLACK));
}

void game_mine(void) {
    #define MINE_W 16
    #define MINE_H 12
    int board[MINE_H][MINE_W];
    int revealed[MINE_H][MINE_W];
    int flagged[MINE_H][MINE_W];
    int cur_x = 0, cur_y = 0, running = 1;
    int total_mines = 20;
    int lost = 0, won = 0;
    int total_revealed = 0;
    for (int y = 0; y < MINE_H; y++)
        for (int x = 0; x < MINE_W; x++) { board[y][x] = 0; revealed[y][x] = 0; flagged[y][x] = 0; }
    for (int i = 0; i < total_mines; i++) {
        int mx = (i * 7 + 3) % MINE_W;
        int my = (i * 5 + 1) % MINE_H;
        board[my][mx] = -1;
    }
    vga_clear(vga_make_color(VGA_BLACK, VGA_BLACK));
    vga_print("MINESWEEPER - arrows move, SPACE reveal, F flag, ESC exit",
              vga_make_color(VGA_LIGHT_CYAN, VGA_BLACK), 8, 0);
    while (running) {
        for (int y = 0; y < MINE_H; y++) {
            for (int x = 0; x < MINE_W; x++) {
                int sx = 5 + x * 3, sy = 3 + y;
                uint8_t c; char ch;
                if (revealed[y][x]) {
                    if      (board[y][x] == -1) { ch = '*'; c = VGA_LIGHT_RED; }
                    else if (board[y][x] == 0)  { ch = ' '; c = VGA_DARK_GREY; }
                    else { ch = (char)('0' + board[y][x]); c = VGA_LIGHT_BLUE; }
                } else if (flagged[y][x]) { ch = 'F'; c = VGA_LIGHT_RED; }
                else { ch = CH_MED_SHADE; c = VGA_LIGHT_GREY; }
                if (x == cur_x && y == cur_y) c = VGA_YELLOW;
                vga_putcell(sx, sy, ch, c, VGA_BLACK);
                vga_putcell(sx + 1, sy, ' ', c, VGA_BLACK);
            }
        }
        if (lost) vga_print("BOOM! You hit a mine. Press ESC.", vga_make_color(VGA_LIGHT_RED, VGA_BLACK), 22, 17);
        else if (won) vga_print("YOU WIN! Press ESC.", vga_make_color(VGA_LIGHT_GREEN, VGA_BLACK), 28, 17);
        else {
            char sb[40] = "Mines: 20  Revealed: ";
            char num[8]; itoa(total_revealed, num, 10);
            int p = 20;
            for (int i = 0; num[i]; i++) sb[p++] = num[i];
            sb[p] = 0;
            vga_print(sb, vga_make_color(VGA_LIGHT_GREY, VGA_BLACK), 20, 17);
        }
        if (lost || won) { int k = keyboard_getchar(); if (k == -KEY_ESC) running = 0; continue; }
        int key = keyboard_getchar();
        if (key == -KEY_ESC) running = 0;
        else if (key == -KEY_UP    && cur_y > 0)        cur_y--;
        else if (key == -KEY_DOWN  && cur_y < MINE_H-1) cur_y++;
        else if (key == -KEY_LEFT  && cur_x > 0)        cur_x--;
        else if (key == -KEY_RIGHT && cur_x < MINE_W-1) cur_x++;
        else if (key == 'f' || key == 'F') { if (!revealed[cur_y][cur_x]) flagged[cur_y][cur_x] = !flagged[cur_y][cur_x]; }
        else if (key == ' ') {
            if (board[cur_y][cur_x] == -1) { lost = 1; pcspk_error(); }
            else if (!revealed[cur_y][cur_x] && !flagged[cur_y][cur_x]) {
                revealed[cur_y][cur_x] = 1;
                total_revealed++;
                if (total_revealed >= MINE_W * MINE_H - total_mines) won = 1;
            }
        }
    }
    vga_clear(vga_make_color(VGA_LIGHT_GREY, VGA_BLACK));
}

void game_hangman(void) {
    const char* words[] = { "NEUTRINO", "KERNEL", "DISK", "BOOT", "PROTECTED",
                            "MEMORY", "SCREEN", "BINARY", "SYSTEM", "SOFTWARE" };
    const int num_words = 10;
    rtc_time_t t; rtc_read(&t);
    int word_idx = (t.second + t.minute) % num_words;
    const char* word = words[word_idx];
    int len = strlen(word);
    int guessed[26] = {0};
    int wrong = 0, max_wrong = 6, running = 1;
    while (running) {
        vga_clear(vga_make_color(VGA_BLACK, VGA_BLACK));
        vga_print("HANGMAN", vga_make_color(VGA_LIGHT_CYAN, VGA_BLACK), 35, 2);
        vga_print("Guess a letter (A-Z), ESC to quit",
                  vga_make_color(VGA_DARK_GREY, VGA_BLACK), 20, 4);
        int hx = 10, hy = 6;
        vga_print("  +---+", vga_make_color(VGA_LIGHT_GREY, VGA_BLACK), hx, hy);
        vga_print("  |   |", vga_make_color(VGA_LIGHT_GREY, VGA_BLACK), hx, hy + 1);
        vga_print("      |", vga_make_color(VGA_LIGHT_GREY, VGA_BLACK), hx, hy + 2);
        vga_print("      |", vga_make_color(VGA_LIGHT_GREY, VGA_BLACK), hx, hy + 3);
        vga_print("      |", vga_make_color(VGA_LIGHT_GREY, VGA_BLACK), hx, hy + 4);
        vga_print("      |", vga_make_color(VGA_LIGHT_GREY, VGA_BLACK), hx, hy + 5);
        vga_print("=========", vga_make_color(VGA_LIGHT_GREY, VGA_BLACK), hx, hy + 6);
        if (wrong >= 1) vga_print("  O",    vga_make_color(VGA_LIGHT_RED, VGA_BLACK), hx, hy + 1);
        if (wrong >= 2) vga_print("  |",    vga_make_color(VGA_LIGHT_RED, VGA_BLACK), hx, hy + 2);
        if (wrong >= 3) vga_print(" /|",    vga_make_color(VGA_LIGHT_RED, VGA_BLACK), hx, hy + 2);
        if (wrong >= 4) vga_print(" /|\\",  vga_make_color(VGA_LIGHT_RED, VGA_BLACK), hx, hy + 2);
        if (wrong >= 5) vga_print(" /",     vga_make_color(VGA_LIGHT_RED, VGA_BLACK), hx, hy + 3);
        if (wrong >= 6) vga_print(" / \\",  vga_make_color(VGA_LIGHT_RED, VGA_BLACK), hx, hy + 3);
        int all_revealed = 1;
        for (int i = 0; i < len; i++) {
            char ch;
            if (guessed[word[i] - 'A']) ch = word[i];
            else { ch = '_'; all_revealed = 0; }
            vga_putcell(40 + i * 2, 12, ch, VGA_WHITE, VGA_BLACK);
        }
        char wb[16];
        itoa(wrong, wb, 10);
        vga_print("Wrong: ", vga_make_color(VGA_LIGHT_GREY, VGA_BLACK), 40, 15);
        vga_print(wb,       vga_make_color(VGA_LIGHT_RED, VGA_BLACK), 47, 15);
        vga_print("/6",     vga_make_color(VGA_LIGHT_GREY, VGA_BLACK), 48 + strlen(wb), 15);
        vga_print("Guessed: ", vga_make_color(VGA_LIGHT_GREY, VGA_BLACK), 40, 17);
        int gx = 49;
        for (int i = 0; i < 26; i++) {
            if (guessed[i]) {
                char ch = (char)('A' + i);
                int in_word = 0;
                for (int j = 0; j < len; j++) if (word[j] == ch) in_word = 1;
                uint8_t c = in_word ? VGA_LIGHT_GREEN : VGA_LIGHT_RED;
                vga_putcell(gx, 17, ch, c, VGA_BLACK);
                gx++;
                if (gx > 75) gx = 40;
            }
        }
        if (all_revealed) {
            vga_print("YOU WIN! Press any key.", vga_make_color(VGA_LIGHT_GREEN, VGA_BLACK), 28, 21);
            keyboard_getchar(); running = 0; break;
        }
        if (wrong >= max_wrong) {
            vga_print("You lost. The word was: ", vga_make_color(VGA_LIGHT_RED, VGA_BLACK), 20, 21);
            vga_print(word, vga_make_color(VGA_YELLOW, VGA_BLACK), 46, 21);
            keyboard_getchar(); running = 0; break;
        }
        int key = keyboard_getchar();
        if (key == -KEY_ESC) running = 0;
        else if (key >= 'a' && key <= 'z') key = to_upper((char)key);
        if (key >= 'A' && key <= 'Z' && !guessed[key - 'A']) {
            guessed[key - 'A'] = 1;
            int in_word = 0;
            for (int j = 0; j < len; j++) if (word[j] == (char)key) in_word = 1;
            if (in_word) pcspk_click(); else { wrong++; pcspk_error(); }
        }
    }
    vga_clear(vga_make_color(VGA_LIGHT_GREY, VGA_BLACK));
}
