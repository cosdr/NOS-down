#include "ata.h"
#include "utils.h"

#define ATA_DATA 0x1F0
#define ATA_SECCOUNT 0x1F2
#define ATA_LBA_LO 0x1F3
#define ATA_LBA_MID 0x1F4
#define ATA_LBA_HI 0x1F5
#define ATA_DRIVE 0x1F6
#define ATA_STATUS 0x1F7
#define ATA_COMMAND 0x1F7
#define ATA_ALTSTAT 0x3F6

#define ATA_SR_BSY 0x80
#define ATA_SR_DRQ 0x08

#define ATA_CMD_READ_PIO 0x20
#define ATA_CMD_WRITE_PIO 0x30
#define ATA_CMD_IDENTIFY 0xEC
#define ATA_CMD_CACHE_FLUSH 0xE7

static int ata_ready = 0;

static int wait_bsy(void) {
    for (int i = 0; i < 1000000; i++) { if (!(inb(ATA_STATUS) & ATA_SR_BSY)) return 0; delay(1); }
    return -1;
}
static int wait_drq(void) {
    for (int i = 0; i < 1000000; i++) {
        uint8_t st = inb(ATA_STATUS);
        if (!(st & ATA_SR_BSY) && (st & ATA_SR_DRQ)) return 0;
        delay(1);
    }
    return -1;
}
static void delay400(void) { inb(ATA_ALTSTAT); inb(ATA_ALTSTAT); inb(ATA_ALTSTAT); inb(ATA_ALTSTAT); }

int ata_init(void) {
    outb(ATA_DRIVE, 0xA0); delay400();
    outb(ATA_SECCOUNT, 0); outb(ATA_LBA_LO, 0); outb(ATA_LBA_MID, 0); outb(ATA_LBA_HI, 0);
    outb(ATA_COMMAND, ATA_CMD_IDENTIFY); delay400();
    uint8_t st = inb(ATA_STATUS);
    if (st == 0) { ata_ready = 0; return 0; }
    if (wait_bsy() != 0) { ata_ready = 0; return 0; }
    if (inb(ATA_LBA_MID) != 0 || inb(ATA_LBA_HI) != 0) { ata_ready = 0; return 0; }
    if (wait_drq() != 0) { ata_ready = 0; return 0; }
    for (int i = 0; i < 256; i++) inw(ATA_DATA);
    ata_ready = 1;
    return 1;
}
int ata_is_ready(void) { return ata_ready; }

int ata_read_sectors(uint32_t lba, uint8_t count, uint8_t* buffer) {
    if (!ata_ready || count == 0) return count == 0 ? 0 : -1;
    if (wait_bsy() != 0) return -1;
    outb(ATA_DRIVE, (uint8_t)(0xE0 | ((lba >> 24) & 0x0F))); delay400();
    outb(ATA_SECCOUNT, count);
    outb(ATA_LBA_LO, (uint8_t)(lba & 0xFF));
    outb(ATA_LBA_MID, (uint8_t)((lba >> 8) & 0xFF));
    outb(ATA_LBA_HI, (uint8_t)((lba >> 16) & 0xFF));
    outb(ATA_COMMAND, ATA_CMD_READ_PIO);
    for (int s = 0; s < count; s++) {
        if (wait_drq() != 0) return -1;
        uint16_t* ptr = (uint16_t*)(buffer + s * 512);
        for (int i = 0; i < 256; i++) ptr[i] = inw(ATA_DATA);
    }
    return 0;
}
int ata_write_sectors(uint32_t lba, uint8_t count, const uint8_t* buffer) {
    if (!ata_ready || count == 0) return count == 0 ? 0 : -1;
    if (wait_bsy() != 0) return -1;
    outb(ATA_DRIVE, (uint8_t)(0xE0 | ((lba >> 24) & 0x0F))); delay400();
    outb(ATA_SECCOUNT, count);
    outb(ATA_LBA_LO, (uint8_t)(lba & 0xFF));
    outb(ATA_LBA_MID, (uint8_t)((lba >> 8) & 0xFF));
    outb(ATA_LBA_HI, (uint8_t)((lba >> 16) & 0xFF));
    outb(ATA_COMMAND, ATA_CMD_WRITE_PIO);
    for (int s = 0; s < count; s++) {
        if (wait_drq() != 0) return -1;
        const uint16_t* ptr = (const uint16_t*)(buffer + s * 512);
        for (int i = 0; i < 256; i++) outw(ATA_DATA, ptr[i]);
    }
    outb(ATA_COMMAND, ATA_CMD_CACHE_FLUSH);
    wait_bsy();
    return 0;
}
