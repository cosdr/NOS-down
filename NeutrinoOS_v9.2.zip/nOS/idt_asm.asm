BITS 32
section .text

extern isr_handler

global isr0
isr0:
    cli
    push dword 0
    push dword 0
    call isr_handler
    add esp, 8
    iret

global isr1
isr1:
    cli
    push dword 0
    push dword 1
    call isr_handler
    add esp, 8
    iret

global isr6
isr6:
    cli
    push dword 0
    push dword 6
    call isr_handler
    add esp, 8
    iret

global isr8
isr8:
    cli
    push dword 8
    call isr_handler
    add esp, 8
    iret

global isr13
isr13:
    cli
    push dword 13
    call isr_handler
    add esp, 8
    iret

global isr14
isr14:
    cli
    push dword 14
    call isr_handler
    add esp, 8
    iret

global idt_load
idt_load:
    mov eax, [esp + 4]
    lidt [eax]
    ret

section .note.GNU-stack noalloc noexec nowrite progbits
