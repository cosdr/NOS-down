#include "fat12.h"
#include "ata.h"
#include "utils.h"

#define SECTOR_SIZE 512
#define CLUSTER_BUF_SIZE 32768

typedef struct {
    uint8_t jmp[3];
    char oem[8];
    uint16_t bytes_per_sector;
    uint8_t sectors_per_cluster;
    uint16_t reserved_sectors;
    uint8_t num_fats;
    uint16_t root_entries;
    uint16_t total_sectors_16;
    uint8_t media;
    uint16_t fat_size_16;
    uint16_t sectors_per_track;
    uint16_t num_heads;
    uint32_t hidden_sectors;
    uint32_t total_sectors_32;
} __attribute__((packed)) bpb_t;

typedef struct {
    uint8_t name[8];
    uint8_t ext[3];
    uint8_t attr;
    uint8_t reserved[10];
    uint16_t time;
    uint16_t date;
    uint16_t first_cluster;
    uint32_t size;
} __attribute__((packed)) dir_entry_t;

#define ATTR_DIRECTORY 0x10
#define ATTR_VOLUME_ID 0x08
#define ATTR_LFN 0x0F

static bpb_t    bpb;
static uint32_t fat_start_lba = 0, root_start_lba = 0, data_start_lba = 0;
static uint32_t root_sectors = 0, fat_sectors = 0, cluster_size = 0;
static int      mounted = 0;
static uint8_t  sector_buf[SECTOR_SIZE];
static uint8_t  cluster_buf[CLUSTER_BUF_SIZE];

int fat12_is_mounted(void) { return mounted; }

static void to_83(const char* name, uint8_t* out) {
    for (int i = 0; i < 11; i++) out[i] = ' ';
    int i = 0, j = 0;
    while (name[i] && name[i] != '.' && j < 8) { out[j++] = (uint8_t)to_upper(name[i]); i++; }
    if (name[i] == '.') { i++; j = 8; while (name[i] && j < 11) { out[j++] = (uint8_t)to_upper(name[i]); i++; } }
}
static void from_83(const uint8_t* in, char* out) {
    int pos = 0;
    for (int i = 0; i < 8; i++) { if (in[i] == ' ') break; out[pos++] = (char)in[i]; }
    if (in[8] != ' ') {
        out[pos++] = '.';
        for (int i = 8; i < 11; i++) { if (in[i] == ' ') break; out[pos++] = (char)in[i]; }
    }
    out[pos] = 0;
}

int fat12_init(void) {
    if (!ata_init()) return -1;
    if (ata_read_sectors(0, 1, sector_buf) != 0) return -1;
    memcpy(&bpb, sector_buf, sizeof(bpb_t));
    if (bpb.bytes_per_sector != 512 || bpb.sectors_per_cluster == 0) return -1;
    fat_start_lba  = bpb.reserved_sectors;
    fat_sectors    = bpb.fat_size_16;
    root_start_lba = fat_start_lba + bpb.num_fats * fat_sectors;
    root_sectors   = (bpb.root_entries * 32 + SECTOR_SIZE - 1) / SECTOR_SIZE;
    data_start_lba = root_start_lba + root_sectors;
    cluster_size   = bpb.sectors_per_cluster * SECTOR_SIZE;
    if (cluster_size > CLUSTER_BUF_SIZE) return -1;
    mounted = 1;
    return 0;
}
static int read_cluster(uint32_t c, uint8_t* buf) {
    uint32_t lba = data_start_lba + (c - 2) * bpb.sectors_per_cluster;
    return ata_read_sectors(lba, bpb.sectors_per_cluster, buf);
}
static uint32_t fat_next(uint32_t c) {
    uint32_t off = c + c / 2;
    uint32_t sec = fat_start_lba + off / SECTOR_SIZE;
    uint32_t eoff = off % SECTOR_SIZE;
    uint8_t buf[SECTOR_SIZE];
    if (ata_read_sectors(sec, 1, buf) != 0) return 0xFFF;
    uint16_t v;
    if (c & 1) v = (uint16_t)((buf[eoff] >> 4) | (buf[eoff + 1] << 4));
    else       v = (uint16_t)(buf[eoff] | ((buf[eoff + 1] & 0x0F) << 8));
    return v & 0xFFF;
}
static int iter_root(dir_entry_t* out, int idx) {
    int eps = SECTOR_SIZE / 32;
    int total = root_sectors * eps;
    for (int i = idx; i < total; i++) {
        int sidx = i / eps, off = (i % eps) * 32;
        if (ata_read_sectors(root_start_lba + sidx, 1, sector_buf) != 0) return -1;
        dir_entry_t* e = (dir_entry_t*)(sector_buf + off);
        if (e->name[0] == 0x00) return -1;
        if (e->name[0] == 0xE5) continue;
        if (e->attr == ATTR_LFN) continue;
        if (e->attr & ATTR_VOLUME_ID) continue;
        memcpy(out, e, sizeof(dir_entry_t));
        return i + 1;
    }
    return -1;
}
int fat12_list(fat12_entry_t* out, int max_count) {
    if (!mounted) return 0;
    int idx = 0, count = 0;
    dir_entry_t e; int next;
    while ((next = iter_root(&e, idx)) > 0 && count < max_count) {
        idx = next;
        from_83(e.name, out[count].name);
        if (e.attr & ATTR_DIRECTORY) { int l = strlen(out[count].name); out[count].name[l] = '/'; out[count].name[l + 1] = 0; }
        out[count].first_cluster = e.first_cluster;
        out[count].size = e.size;
        out[count].is_dir = (e.attr & ATTR_DIRECTORY) ? 1 : 0;
        out[count].used = 1;
        count++;
    }
    return count;
}
int fat12_find(const char* name) {
    if (!mounted) return -1;
    uint8_t target[11]; to_83(name, target);
    int idx = 0, count = 0;
    dir_entry_t e; int next;
    while ((next = iter_root(&e, idx)) > 0) {
        idx = next;
        if (strncmp((char*)e.name, (char*)target, 11) == 0) return count;
        count++;
    }
    return -1;
}
int fat12_read_raw(const char* name, uint8_t* buffer, int max_size) {
    if (!mounted) return -1;
    uint8_t target[11]; to_83(name, target);
    int idx = 0, found = 0;
    dir_entry_t e; int next;
    while ((next = iter_root(&e, idx)) > 0) {
        idx = next;
        if (strncmp((char*)e.name, (char*)target, 11) == 0) { found = 1; break; }
    }
    if (!found || (e.attr & ATTR_DIRECTORY)) return -1;
    if (e.size > (uint32_t)max_size) return -1;
    uint32_t cluster = e.first_cluster, remaining = e.size, pos = 0;
    while (cluster >= 2 && cluster < 0xFF8 && remaining > 0) {
        if (read_cluster(cluster, cluster_buf) != 0) return -1;
        uint32_t to_copy = cluster_size < remaining ? cluster_size : remaining;
        if (pos + to_copy > (uint32_t)max_size) to_copy = max_size - pos;
        memcpy(buffer + pos, cluster_buf, to_copy);
        pos += to_copy; remaining -= to_copy;
        if (remaining == 0) break;
        cluster = fat_next(cluster);
    }
    return (int)pos;
}
int fat12_read_file(const char* name, char* buffer, int max_size) {
    return fat12_read_raw(name, (uint8_t*)buffer, max_size);
}
static int find_free_root_slot(void) {
    int eps = SECTOR_SIZE / 32;
    int total = root_sectors * eps;
    for (int i = 0; i < total; i++) {
        int sidx = i / eps, off = (i % eps) * 32;
        if (ata_read_sectors(root_start_lba + sidx, 1, sector_buf) != 0) return -1;
        dir_entry_t* e = (dir_entry_t*)(sector_buf + off);
        if (e->name[0] == 0x00 || e->name[0] == 0xE5) return i;
    }
    return -1;
}
static uint32_t find_free_cluster(void) {
    for (uint32_t c = 2; c < 0xFF0; c++) if (fat_next(c) == 0) return c;
    return 0;
}
static int fat_set(uint32_t c, uint32_t v) {
    uint32_t off = c + c / 2;
    uint32_t sec = fat_start_lba + off / SECTOR_SIZE;
    uint32_t eoff = off % SECTOR_SIZE;
    if (ata_read_sectors(sec, 1, sector_buf) != 0) return -1;
    if (c & 1) {
        sector_buf[eoff] = (uint8_t)((sector_buf[eoff] & 0x0F) | ((v << 4) & 0xF0));
        sector_buf[eoff + 1] = (uint8_t)((v >> 4) & 0xFF);
    } else {
        sector_buf[eoff] = (uint8_t)(v & 0xFF);
        sector_buf[eoff + 1] = (uint8_t)((sector_buf[eoff + 1] & 0xF0) | ((v >> 8) & 0x0F));
    }
    return ata_write_sectors(sec, 1, sector_buf);
}
static int write_cluster(uint32_t c, const uint8_t* data) {
    uint32_t lba = data_start_lba + (c - 2) * bpb.sectors_per_cluster;
    return ata_write_sectors(lba, bpb.sectors_per_cluster, data);
}
int fat12_write_raw(const char* name, const uint8_t* data, int size) {
    if (!mounted || size > FAT12_MAX_FILESIZE) return -1;
    fat12_delete_file(name);
    int slot = find_free_root_slot();
    if (slot < 0) return -1;
    int need = (size + cluster_size - 1) / cluster_size;
    uint32_t first = 0, prev = 0;
    int written = 0;
    for (int i = 0; i < need; i++) {
        uint32_t c = find_free_cluster();
        if (c == 0) return -1;
        if (i == 0) first = c;
        if (prev) fat_set(prev, c);
        fat_set(c, 0xFFF);
        prev = c;
        memset(cluster_buf, 0, cluster_size);
        int to_copy = size - written;
        if (to_copy > (int)cluster_size) to_copy = cluster_size;
        if (to_copy > 0) { memcpy(cluster_buf, data + written, to_copy); written += to_copy; }
        if (write_cluster(c, cluster_buf) != 0) return -1;
    }
    dir_entry_t de;
    memset(&de, 0, sizeof(de));
    to_83(name, de.name);
    de.attr = 0x20;
    de.first_cluster = (uint16_t)first;
    de.size = size;
    int eps = SECTOR_SIZE / 32;
    int sidx = slot / eps, off = (slot % eps) * 32;
    if (ata_read_sectors(root_start_lba + sidx, 1, sector_buf) != 0) return -1;
    memcpy(sector_buf + off, &de, 32);
    if (ata_write_sectors(root_start_lba + sidx, 1, sector_buf) != 0) return -1;
    return 0;
}
int fat12_write_file(const char* name, const char* data, int size) {
    return fat12_write_raw(name, (const uint8_t*)data, size);
}
int fat12_delete_file(const char* name) {
    if (!mounted) return -1;
    uint8_t target[11]; to_83(name, target);
    int eps = SECTOR_SIZE / 32;
    int total = root_sectors * eps;
    for (int i = 0; i < total; i++) {
        int sidx = i / eps, off = (i % eps) * 32;
        if (ata_read_sectors(root_start_lba + sidx, 1, sector_buf) != 0) return -1;
        dir_entry_t* e = (dir_entry_t*)(sector_buf + off);
        if (e->name[0] == 0x00) return -1;
        if (e->name[0] == 0xE5) continue;
        if (strncmp((char*)e->name, (char*)target, 11) == 0) {
            uint32_t c = e->first_cluster;
            while (c >= 2 && c < 0xFF8) { uint32_t n = fat_next(c); fat_set(c, 0); c = n; }
            e->name[0] = 0xE5;
            return ata_write_sectors(root_start_lba + sidx, 1, sector_buf);
        }
    }
    return -1;
}
int fat12_mkdir(const char* name) {
    if (!mounted) return -1;
    int slot = find_free_root_slot();
    if (slot < 0) return -1;
    uint32_t c = find_free_cluster();
    if (c == 0) return -1;
    memset(cluster_buf, 0, cluster_size);
    dir_entry_t dot, dotdot;
    memset(&dot, 0, sizeof(dot));
    memset(&dotdot, 0, sizeof(dotdot));
    for (int i = 0; i < 8; i++) { dot.name[i] = ' '; dotdot.name[i] = ' '; }
    for (int i = 0; i < 3; i++) { dot.ext[i]  = ' '; dotdot.ext[i]  = ' '; }
    dot.name[0] = '.';
    dot.attr = ATTR_DIRECTORY;
    dot.first_cluster = (uint16_t)c;
    dotdot.name[0] = '.'; dotdot.name[1] = '.';
    dotdot.attr = ATTR_DIRECTORY;
    memcpy(cluster_buf, &dot, 32);
    memcpy(cluster_buf + 32, &dotdot, 32);
    if (write_cluster(c, cluster_buf) != 0) return -1;
    fat_set(c, 0xFFF);
    dir_entry_t de;
    memset(&de, 0, sizeof(de));
    to_83(name, de.name);
    de.attr = ATTR_DIRECTORY;
    de.first_cluster = (uint16_t)c;
    int eps = SECTOR_SIZE / 32;
    int sidx = slot / eps, off = (slot % eps) * 32;
    if (ata_read_sectors(root_start_lba + sidx, 1, sector_buf) != 0) return -1;
    memcpy(sector_buf + off, &de, 32);
    if (ata_write_sectors(root_start_lba + sidx, 1, sector_buf) != 0) return -1;
    return 0;
}
int fat12_format(void) {
    if (!mounted) return -1;
    uint8_t fat_sec[SECTOR_SIZE];
    memset(fat_sec, 0, SECTOR_SIZE);
    fat_sec[0] = 0xF0; fat_sec[1] = 0xFF; fat_sec[2] = 0xFF;
    for (int f = 0; f < bpb.num_fats; f++) {
        uint32_t base = fat_start_lba + f * fat_sectors;
        if (ata_write_sectors(base, 1, fat_sec) != 0) return -1;
        memset(fat_sec, 0, SECTOR_SIZE);
        for (uint32_t s = 1; s < fat_sectors; s++)
            if (ata_write_sectors(base + s, 1, fat_sec) != 0) return -1;
    }
    memset(fat_sec, 0, SECTOR_SIZE);
    for (uint32_t s = 0; s < root_sectors; s++)
        if (ata_write_sectors(root_start_lba + s, 1, fat_sec) != 0) return -1;
    return 0;
}
void fat12_usage(uint32_t* total, uint32_t* freeb, uint32_t* used) {
    *total = 0; *freeb = 0; *used = 0;
    if (!mounted) return;
    uint32_t freec = 0;
    for (uint32_t c = 2; c < 0xFF0; c++) if (fat_next(c) == 0) freec++;
    *total = (0xFF0 - 2) * cluster_size;
    *freeb = freec * cluster_size;
    *used  = *total - *freeb;
}
