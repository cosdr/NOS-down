#ifndef THEME_H
#define THEME_H

#include "stdint.h"

void theme_run(void);
uint8_t theme_fg(int palette_idx);
uint8_t theme_bg(int palette_idx);

#endif
