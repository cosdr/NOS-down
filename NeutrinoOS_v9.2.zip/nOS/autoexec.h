#ifndef AUTOEXEC_H
#define AUTOEXEC_H

void autoexec_run(const char* filename);
void motd_show(void);

#endif
