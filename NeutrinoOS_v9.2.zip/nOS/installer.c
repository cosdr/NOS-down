#include "installer.h"
#include "vga.h"
#include "keyboard.h"
#include "config.h"
#include "pcspk.h"
#include "timezone.h"
#include "palette.h"
#include "utils.h"

static const uint8_t INSTALL_PALETTE[16][3] = {
    { 0,  0,  0}, { 8,  6, 22}, { 8, 30,  8}, { 8, 30, 30},
    {40,  6,  6}, {40,  6, 40}, {30, 15,  4}, {36, 36, 36},
    {20, 20, 20}, {28, 20, 50}, {40, 55, 40}, {30, 50, 55},
    {55, 22, 22}, {52, 20, 52}, {55, 48, 14}, {55, 55, 55},
};
static const uint8_t PURPLE_OVERRIDE[3] = { 42, 14, 48 };

static void installer_theme_start(void) {
    palette_load(INSTALL_PALETTE);
    palette_set_entry(VGA_LIGHT_MAGENTA, PURPLE_OVERRIDE[0], PURPLE_OVERRIDE[1], PURPLE_OVERRIDE[2]);
}
static void installer_theme_end(void) {
    config_t* cfg = config_get();
    palette_apply_theme(cfg->theme_id);
}
static void panel(int x, int y, int w, int h) {
    uint8_t shadow = vga_make_color(VGA_BLACK, VGA_LIGHT_MAGENTA);
    uint8_t bg     = vga_make_color(VGA_BLACK, VGA_LIGHT_GREY);
    for (int i = 0; i < w; i++) vga_putchar(219, shadow, x + i + 1, y + h);
    for (int i = 0; i < h; i++) vga_putchar(219, shadow, x + w, y + i + 1);
    for (int j = 0; j < h; j++)
        for (int i = 0; i < w; i++)
            vga_putchar(' ', bg, x + i, y + j);
    uint8_t b = vga_make_color(VGA_BLACK, VGA_LIGHT_GREY);
    for (int i = 0; i < w; i++) { vga_putchar(196, b, x + i, y); vga_putchar(196, b, x + i, y + h - 1); }
    for (int i = 0; i < h; i++) { vga_putchar(179, b, x, y + i); vga_putchar(179, b, x + w - 1, y + i); }
    vga_putchar(218, b, x, y);
    vga_putchar(191, b, x + w - 1, y);
    vga_putchar(192, b, x, y + h - 1);
    vga_putchar(217, b, x + w - 1, y + h - 1);
}
static int prompt_line(int x, int y, int max_w, char* out, int max, int mask) {
    uint8_t fg = vga_make_color(VGA_BLACK, VGA_LIGHT_GREY);
    for (int i = 0; i < max_w; i++) vga_putchar('_', fg, x + i, y);
    int pos = 0, cx = x;
    for (;;) {
        vga_putchar(219, fg, cx, y);
        int k = keyboard_getchar();
        vga_putchar('_', fg, cx, y);
        if (k == '\n') { out[pos] = 0; return pos; }
        if (k == -KEY_ESC) { out[0] = 0; return -1; }
        if (k == '\b' && pos > 0) { pos--; cx--; vga_putchar('_', fg, cx, y); }
        else if (k > 0 && k < 128 && pos < max - 1 && cx < x + max_w - 1) {
            out[pos++] = (char)k;
            vga_putchar(mask ? '*' : (char)k, fg, cx, y);
            cx++;
        }
    }
}
static void slow_pause(void) {
    for (volatile int d = 0; d < 8000000; d++) { }
}

static int numbered_menu(const char* title, const char* const* opts, int n, int cur) {
    int list_x = 3, list_y = 5, list_w = 74;
    panel(3, 1, 74, 3);
    vga_print(title, vga_make_color(VGA_BLACK, VGA_LIGHT_GREY), 6, 2);
    panel(list_x, list_y, list_w, n + 2);
    int sel = cur;
    int done = 0;
    while (!done) {
        for (int i = 0; i < n; i++) {
            int row = list_y + 1 + i;
            int is_sel = (i == sel);
            uint8_t fg = is_sel ? VGA_WHITE : VGA_BLACK;
            uint8_t bg = is_sel ? VGA_BLACK : VGA_LIGHT_GREY;
            for (int k = 1; k < list_w - 1; k++) vga_putcell(list_x + k, row, ' ', fg, bg);
            vga_putcell(list_x + 2, row, is_sel ? '>' : ' ', fg, bg);
            vga_print(opts[i], vga_make_color(fg, bg), list_x + 4, row);
        }
        vga_print("Up/Down  ENTER=confirm", vga_make_color(VGA_BLACK, VGA_LIGHT_GREY), 3, list_y + n + 2);
        int k = keyboard_getchar();
        if (k == -KEY_UP && sel > 0) sel--;
        else if (k == -KEY_DOWN && sel < n - 1) sel++;
        else if (k == '\n') done = 1;
    }
    slow_pause();
    return sel;
}

static void screen_welcome(void) {
    vga_clear(vga_make_color(VGA_BLACK, VGA_LIGHT_MAGENTA));
    panel(10, 6, 60, 12);
    vga_print("Welcome to NeutrinoOS v0.9.2", vga_make_color(VGA_BLACK, VGA_LIGHT_GREY), 20, 8);
    vga_print("Installer will guide you through several steps.", vga_make_color(VGA_BLACK, VGA_LIGHT_GREY), 12, 10);
    vga_print("Press any key to begin.", vga_make_color(VGA_BLACK, VGA_LIGHT_GREY), 24, 14);
    keyboard_getchar();
    slow_pause();
}

static void screen_timezone(config_t* cfg) {
    vga_clear(vga_make_color(VGA_BLACK, VGA_LIGHT_MAGENTA));
    panel(3, 1, 74, 3);
    vga_print("Select your timezone.", vga_make_color(VGA_BLACK, VGA_LIGHT_GREY), 6, 2);
    int list_x = 3, list_y = 5, list_w = 74, list_h = 18;
    panel(list_x, list_y, list_w, list_h);
    int n = tz_count();
    int visible = list_h - 2;
    int selected = tz_find_index(cfg->tz_name);
    if (selected < 0) selected = 0;
    int scroll = 0;
    if (selected >= visible) scroll = selected - visible + 1;
    int done = 0;
    while (!done) {
        if (selected < scroll) scroll = selected;
        if (selected >= scroll + visible) scroll = selected - visible + 1;
        for (int i = 0; i < visible; i++) {
            int idx = scroll + i;
            int row = list_y + 1 + i;
            int is_sel = (idx == selected);
            uint8_t fg = is_sel ? VGA_WHITE : VGA_BLACK;
            uint8_t bg = is_sel ? VGA_BLACK : VGA_LIGHT_GREY;
            for (int k = 1; k < list_w - 1; k++) vga_putcell(list_x + k, row, ' ', fg, bg);
            if (idx >= n) continue;
            vga_putcell(list_x + 2, row, is_sel ? '>' : ' ', fg, bg);
            vga_print(tz_get(idx)->name, vga_make_color(fg, bg), list_x + 4, row);
            char off[8]; tz_format_offset(tz_get(idx)->offset, off, sizeof(off));
            vga_print(off, vga_make_color(fg, bg), list_x + list_w - 10, row);
        }
        vga_print("Up/Down  PgUp/PgDn  ENTER=confirm  ESC=cancel",
                  vga_make_color(VGA_BLACK, VGA_LIGHT_GREY), 3, 24);
        int k = keyboard_getchar();
        if (k == -KEY_UP && selected > 0) selected--;
        else if (k == -KEY_DOWN && selected < n - 1) selected++;
        else if (k == KEY_PGUP) { selected -= 5; if (selected < 0) selected = 0; }
        else if (k == KEY_PGDN) { selected += 5; if (selected > n - 1) selected = n - 1; }
        else if (k == KEY_HOME) selected = 0;
        else if (k == KEY_END) selected = n - 1;
        else if (k == '\n') done = 1;
        else if (k == -KEY_ESC) { selected = -1; done = 1; }
    }
    if (selected >= 0) {
        cfg->tz_offset = tz_get(selected)->offset;
        strncpy(cfg->tz_name, tz_get(selected)->name, sizeof(cfg->tz_name) - 1);
    }
    slow_pause();
}

static void screen_videomode(config_t* cfg) {
    vga_clear(vga_make_color(VGA_BLACK, VGA_LIGHT_MAGENTA));
    const char* names[3] = {
        "VGA AmTREND (C) 16 colours",
        "VGA NVID (R) 256 colours",
        "VGA MikSoft (C) 128 colours",
    };
    cfg->videomode = numbered_menu("Select video mode", names, 3, cfg->videomode);
}
static void screen_credentials(config_t* cfg) {
    vga_clear(vga_make_color(VGA_BLACK, VGA_LIGHT_MAGENTA));
    panel(8, 3, 64, 5);
    vga_print("Please enter your username.",
              vga_make_color(VGA_BLACK, VGA_LIGHT_GREY), 11, 5);
    prompt_line(11, 7, 58, cfg->username, sizeof(cfg->username), 0);
    panel(8, 10, 64, 5);
    vga_print("Please enter your password.",
              vga_make_color(VGA_BLACK, VGA_LIGHT_GREY), 11, 12);
    prompt_line(11, 14, 58, cfg->password, sizeof(cfg->password), 1);
    slow_pause();
}
static void screen_root(config_t* cfg) {
    vga_clear(vga_make_color(VGA_BLACK, VGA_LIGHT_MAGENTA));
    panel(8, 5, 64, 7);
    vga_print("Superuser ($root) password.", vga_make_color(VGA_BLACK, VGA_LIGHT_GREY), 11, 7);
    vga_print("Required for FORMAT, DEL, RM.", vga_make_color(VGA_BLACK, VGA_LIGHT_GREY), 11, 8);
    vga_print("Enter root password :", vga_make_color(VGA_BLACK, VGA_LIGHT_GREY), 11, 10);
    prompt_line(33, 10, 34, cfg->su_password, sizeof(cfg->su_password), 1);
    slow_pause();
}
static void screen_autologin(config_t* cfg) {
    vga_clear(vga_make_color(VGA_BLACK, VGA_LIGHT_MAGENTA));
    const char* opts[2] = {
        "Autologin - skip password on each boot",
        "Require password on every boot",
    };
    int sel = numbered_menu("Login behaviour", opts, 2, cfg->autologin ? 0 : 1);
    cfg->autologin = (sel == 0) ? 1 : 0;
}
static void screen_screensaver(config_t* cfg) {
    vga_clear(vga_make_color(VGA_BLACK, VGA_LIGHT_MAGENTA));
    const char* opts[5] = { "0 = Off", "1 = Starfield", "2 = Matrix", "3 = Bounce", "4 = Pipes" };
    cfg->screensaver = numbered_menu("Screensaver", opts, 5, cfg->screensaver);
}
static void screen_theme(config_t* cfg) {
    vga_clear(vga_make_color(VGA_BLACK, VGA_LIGHT_MAGENTA));
    int n = palette_theme_count();
    const char* opts[6];
    for (int i = 0; i < n && i < 6; i++) opts[i] = palette_theme_name(i);
    cfg->theme_id = numbered_menu("Colour theme", opts, n, cfg->theme_id);
}
static void screen_prompt(config_t* cfg) {
    vga_clear(vga_make_color(VGA_BLACK, VGA_LIGHT_MAGENTA));
    panel(4, 3, 72, 5);
    vga_print("Shell prompt template.", vga_make_color(VGA_BLACK, VGA_LIGHT_GREY), 8, 5);
    vga_print("Use %u=user, %h=host, %t=timezone.", vga_make_color(VGA_BLACK, VGA_LIGHT_GREY), 8, 6);
    prompt_line(8, 8, 66, cfg->prompt, sizeof(cfg->prompt), 0);
    slow_pause();
}
static void screen_slowboot(config_t* cfg) {
    vga_clear(vga_make_color(VGA_BLACK, VGA_LIGHT_MAGENTA));
    const char* opts[2] = { "Fast boot", "Slow boot (for debugging)" };
    int sel = numbered_menu("Boot speed", opts, 2, cfg->slowboot ? 1 : 0);
    cfg->slowboot = sel;
}

static void screen_done(config_t* cfg) {
    vga_clear(vga_make_color(VGA_BLACK, VGA_LIGHT_MAGENTA));
    panel(10, 4, 60, 16);
    uint8_t lbl = vga_make_color(VGA_BLACK, VGA_LIGHT_GREY);
    vga_print("Installation complete.", lbl, 14, 6);
    vga_print("Username : ", lbl, 14, 8);
    vga_print(cfg->username, lbl, 26, 8);
    vga_print("Timezone : ", lbl, 14, 9);
    vga_print(cfg->tz_name, lbl, 26, 9);
    vga_print("Press any key to continue...", lbl, 14, 14);
    keyboard_getchar();
}

void installer_run(void) {
    config_t* cfg = config_get();
    installer_theme_start();
    screen_welcome();
    screen_timezone(cfg);
    screen_videomode(cfg);
    screen_credentials(cfg);
    screen_root(cfg);
    screen_autologin(cfg);
    screen_screensaver(cfg);
    screen_theme(cfg);
    screen_prompt(cfg);
    screen_slowboot(cfg);
    cfg->installed = 1;
    config_save();
    pcspk_boot();
    screen_done(cfg);
    installer_theme_end();
    vga_clear(vga_make_color(VGA_LIGHT_GREY, VGA_BLACK));
}
