#ifndef VGA_H
#define VGA_H

#include "stdint.h"

#define VGA_WIDTH  80
#define VGA_HEIGHT 25

#define VGA_BLACK         0
#define VGA_BLUE          1
#define VGA_GREEN         2
#define VGA_CYAN          3
#define VGA_RED           4
#define VGA_MAGENTA       5
#define VGA_BROWN         6
#define VGA_LIGHT_GREY    7
#define VGA_DARK_GREY     8
#define VGA_LIGHT_BLUE    9
#define VGA_LIGHT_GREEN   10
#define VGA_LIGHT_CYAN    11
#define VGA_LIGHT_RED     12
#define VGA_LIGHT_MAGENTA 13
#define VGA_YELLOW        14
#define VGA_WHITE         15

#define CH_FULL_BLOCK     219
#define CH_DARK_SHADE     178
#define CH_MED_SHADE      177
#define CH_LIGHT_SHADE    176
#define CH_UPPER_HALF     223
#define CH_LOWER_HALF     220
#define CH_LEFT_HALF      221
#define CH_RIGHT_HALF     222

void    vga_init(void);
void    vga_clear(uint8_t color);
void    vga_putchar(char c, uint8_t color, int x, int y);
void    vga_putchar_at(char c, uint8_t color);
void    vga_print(const char* str, uint8_t color, int x, int y);
void    vga_print_at(const char* str, uint8_t color);
void    vga_scroll(void);
void    vga_set_cursor(int x, int y);
void    vga_get_cursor(int* x, int* y);
int     vga_get_cursor_x(void);
int     vga_get_cursor_y(void);
void    vga_newline(void);
void    vga_draw_box(int x, int y, int w, int h, uint8_t color);
void    vga_draw_box_single(int x, int y, int w, int h, uint8_t color);
void    vga_draw_shadow(int x, int y, int w, int h, uint8_t color);
void    vga_fill(int x, int y, int w, int h, char ch, uint8_t color);
uint8_t vga_make_color(uint8_t fg, uint8_t bg);
void    vga_fill_bg(int x, int y, int w, int h, char ch, uint8_t fg, uint8_t bg);
void    vga_putcell(int x, int y, char c, uint8_t fg, uint8_t bg);
char    vga_getcell(int x, int y);
uint8_t vga_getcell_color(int x, int y);

int     gfx_enter_mode13(void);
void    gfx_leave_mode13(void);
void    gfx_putpixel(int x, int y, uint8_t color);
uint8_t gfx_getpixel(int x, int y);
void    gfx_clear(uint8_t color);
void    gfx_hline(int x, int y, int len, uint8_t color);
void    gfx_vline(int x, int y, int len, uint8_t color);
void    gfx_rect(int x, int y, int w, int h, uint8_t color);
void    gfx_fillrect(int x, int y, int w, int h, uint8_t color);
void    gfx_line(int x0, int y0, int x1, int y1, uint8_t color);
void    gfx_drawchar(int x, int y, char c, uint8_t color);
void    gfx_drawtext(int x, int y, const char* s, uint8_t color);
int     gfx_in_mode13(void);

#endif
