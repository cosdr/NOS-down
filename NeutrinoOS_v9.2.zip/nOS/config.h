#ifndef CONFIG_H
#define CONFIG_H

#include "stdint.h"

#define THEME_COLORS 16

typedef struct {
    int  installed;
    int  tz_offset;
    char tz_name[32];
    char username[32];
    char password[32];
    char su_password[32];
    int  theme_id;
    int  videomode;
    int  autologin;
    int  screensaver;
    int  saver_delay;
    int  slowboot;
    char prompt[64];
    uint8_t theme[THEME_COLORS];
} config_t;

void      config_load(void);
void      config_save(void);
void      config_save_theme(void);
void      config_save_timezone(void);
void      config_save_user(void);
void      config_save_first_boot(void);
void      config_save_videomode(void);
void      config_save_autologin(void);
void      config_save_screensaver(void);
void      config_save_slowboot(void);
void      config_save_prompt(void);
config_t* config_get(void);

#endif
