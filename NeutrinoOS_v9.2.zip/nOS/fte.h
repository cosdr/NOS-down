#ifndef FTE_H
#define FTE_H

void fte_run(const char* filename);

#endif
