#ifndef SCREENSAVER_H
#define SCREENSAVER_H

void saver_starfield(void);
void saver_matrix(void);
void saver_bounce(void);
void saver_pipes(void);
void saver_run_by_id(int id);

#endif
