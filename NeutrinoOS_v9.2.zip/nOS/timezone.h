#ifndef TIMEZONE_H
#define TIMEZONE_H

typedef struct {
    const char* name;
    int         offset;
} tz_entry_t;

int               tz_count(void);
const tz_entry_t* tz_get(int idx);
int               tz_find_index(const char* name);
const char*       tz_display(int idx);
void              tz_format_offset(int offset, char* out, int max);

#endif
