#ifndef RTC_H
#define RTC_H

#include "stdint.h"

typedef struct {
    int second, minute, hour;
    int day, month, year;
} rtc_time_t;

void rtc_read(rtc_time_t* t);
void rtc_write(rtc_time_t* t);
void rtc_get_local(rtc_time_t* t, int tz_offset);
void rtc_sleep_ms(int ms);

#endif
